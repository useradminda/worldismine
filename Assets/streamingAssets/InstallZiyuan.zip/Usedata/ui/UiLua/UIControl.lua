UIControl = {}

local UIControl = BasePanel:new()
local this = UIControl
UIControl.UIControlGob = nil

UIControl.UITT = nil
UIControl.AnchorCenter = nil

function UIControl:OpenUI(_PanelName , _LuaName)

    UIControl.UIControlGob = MainGameUI.FindPanel("UIControl")
    UIControl.UITT = UIControl.UIControlGob.transform:FindChild("Camera"):FindChild("UITT")
    UIControl.AnchorCenter = UIControl.UIControlGob.transform:FindChild("Camera"):FindChild("AnchorCenter")
end

function UIControl:UIHand(_LuaName , _Gob)
   if _Gob.name == "WorldButton" then
      this:OpenWorldMap()
   end
   if _Gob.name == "PveButton" then
      GameMain.EnterZQBattle()
   end
    if _Gob.name == "Login" then
		LoginData.LoginZQ()
		MainGameUI.OpenOnePanel("UILogin" , "UILogin" , "UILogin" , UIControl.AnchorCenter , nil , nil)
   end
   if _Gob.name == "CreatePlayer" then
      ClinetSys.CreatePlayer()
   end

   if _Gob.name=="BagBtn" then
		--���󱳰�����
		MainGameUI.OpenOnePanel("UIBag" , "UIBag" , "UIBag" , UIControl.AnchorCenter , nil , nil)

   end
end

function UIControl:OpenWorldMap()               --���������ͼ
   UIControl.UITT.gameObject:SetActive(false)
   WorldMapSys.CreateCityNodes()
   PlayerControl.InitSome()
   GameMain.SocketTestCase();
end

function UIControl:ReleasPanel()

    UIControl.UIControlGob = nil
    UIControl.UITT = nil
    UIControl.AnchorCenter = nil

end

return UIControl
