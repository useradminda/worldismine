UITeamMake = {}

local UITeamMake = BasePanel:new()     
local this = UITeamMake
UITeamMake.UITeamMakeGob = nil
UITeamMake.TeamMakeFather = nil

UITeamMake.UICamera = nil
UITeamMake.TeamCa = nil
UITeamMake.MoveTeamMaker = nil

UITeamMake.Models = {}
UITeamMake.UPHeros = {}

UITeamMake.NowTeamType = 1
function UITeamMake:OpenUI(_PanelName , _LuaName)
	
    UITeamMake.UITeamMakeGob = MainGameUI.FindPanel("UITeamMake")
    UITeamMake.TeamMakeFather = GameObject.Find("TeamMake")
    UITeamMake.UICamera = MainGameUI.FindPanel("UIControl").transform:FindChild("Camera").gameObject:GetComponent("Camera")
    UITeamMake.TeamCa = GameObject.Find("TeamMakeCa").gameObject:GetComponent("Camera")
    
    UITeamMake.NowTeamType = 1
    TeamSys.SetPvpTeamType(UITeamMake.NowTeamType)
    this:CreateHeros()
    this:CreateSoliders()
end

UITeamMake.HeroGrid = nil
UITeamMake.HeroList = {}
function UITeamMake:CreateHeros()
    if UITeamMake.HeroGrid == nil then
       UITeamMake.HeroGrid = UITeamMake.UITeamMakeGob.transform:FindChild("HeroList"):FindChild("Heros"):FindChild("HerosPanel"):FindChild("HeroGrid")
    end
 
    for i = 1 ,  #HeroPackageSys.Heros , 1 do
        local data = 
        {
            Index = i,
            HeroData = HeroPackageSys.Heros[i],
        }
        MainGameUI.CreateLittleItem("Hero_"..tostring(i) , "HeadPic" , UITeamMake.HeroGrid , data , this.CreateHerosCallBack  , "UITeamMake")
    end
end

function UITeamMake:CreateHerosCallBack(_Gob , _Info)
     
    UITeamMake.HeroList[_Info.Index] = 
    {
        HeroData = _Info.HeroData,
        HeroGob = _Gob,
    }

    if _Info.Index==#HeroPackageSys.Heros then
       UITeamMake.HeroGrid:GetComponent("UIGrid").enabled = true
       UITeamMake.HeroGrid:GetComponent("UIGrid"):Reposition()
    end
end

UITeamMake.SoldierGrid = nil
UITeamMake.SoldierList = {}
function UITeamMake:CreateSoliders()
    if UITeamMake.SoldierGrid == nil then
       UITeamMake.SoldierGrid = UITeamMake.UITeamMakeGob.transform:FindChild("SoldierList"):FindChild("Soldiers"):FindChild("SoldierPanel"):FindChild("SoldierGrid")
    end

    for i = 1 ,  #SoliderPackageSys.Soliders , 1 do
        local data = 
        {
            Index = i,
            SoldierData = SoliderPackageSys.Soliders[i],
        }
        MainGameUI.CreateLittleItem("Soldier_"..tostring(i) , "HeadPic" , UITeamMake.SoldierGrid , data , this.CreateSoldierCallBack  , "UITeamMake")
    end
end

function UITeamMake:CreateSoldierCallBack(_Gob , _Info)
     
    UITeamMake.SoldierList[_Info.Index] = 
    {
        SoldierData = _Info.SoldierData,
        SoldierGob = _Gob,
    }

    if _Info.Index==#SoliderPackageSys.Soliders then
       UITeamMake.SoldierGrid:GetComponent("UIGrid").enabled = true
       UITeamMake.SoldierGrid:GetComponent("UIGrid"):Reposition()
    end
end

function UITeamMake:Create3DHeroModel(_FbxName)
   if UITeamMake.MoveTeamMaker==nil then
      if UITeamMake.Models[_FbxName]==nil then
          local data = 
          {
            ModelName = _FbxName,
          }
          MainGameUI.CreateLittleItem("Model" , _FbxName , UITeamMake.TeamMakeFather  , data , this.Create3DHeroModelCallBack , "UITeamMake")
      else
          UITeamMake.MoveTeamMaker = UITeamMake.Models[_FbxName]
      end
   end
end

function UITeamMake:Create3DHeroModelCallBack(_Gob , _Info)
   if UITeamMake.MoveTeamMaker==nil then
      _Gob.transform.localScale = Vector3(1 , 1 , 1)
      _Gob.transform.localEulerAngles = Vector3(0 , 0 , 0)
      UITeamMake.Models[_Info.ModelName] = _Gob
      UITeamMake.MoveTeamMaker = _Gob
   end
end

function UITeamMake:Create3DSoldierModel(_FbxName) 
    local data = 
    {
       ModelName = _FbxName,
    }
    MainGameUI.CreateLittleItem("Model" , _FbxName , UITeamMake.TeamMakeFather  , data , this.Create3DSoldierModelCallBack , "UITeamMake")   
end

function UITeamMake:Create3DSoldierModelCallBack(_Gob , _Info)
   if UITeamMake.MoveTeamMaker==nil then    
      _Gob.transform.localScale = Vector3(1 , 1 , 1)
      _Gob.transform.localEulerAngles = Vector3(0 , 0 , 0)
      UITeamMake.MoveTeamMaker = _Gob
   end
end

function UITeamMake:Create3DHeroModelInit()
   
end

function UITeamMake:Create3DSoldierModelInit(_UpHeroInfo)
    local _SoldierData = SoliderPackageSys.GetOneSolider(_UpHeroInfo.SoldierId)
    local data = 
    {
       UpHeroInfo = _UpHeroInfo,
    }
    MainGameUI.CreateLittleItem("Model" , _SoldierData.roleData.FbxName , UITeamMake.TeamMakeFather  , data , this.Create3DSoldierModelInitCallBack , "UITeamMake")
end

function UITeamMake:Create3DSoldierModelInitCallBack(_Gob , _Info)
    local _UpHero = _Info.UpHeroInfo
    _Gob.transform.parent = _UpHero.HeroGob.transform
    _Gob.transform.localPosition = Vector3(0 , 0 , 0) 
    _Gob.transform.name = "SoldierModel"  
end

function UITeamMake:UIOnPress( _LuaName , _Gob , _isPress)
    Debug.LogError(_Gob)
    if _isPress==false then                                     --̧����¶���
       local NameList = GameMain.StringSplit(_Gob.name , "_")
       if #NameList==2 then
          if NameList[1]=="Hero" then
             this:PutDownHero()
          elseif NameList[1]=="Soldier" then
             UITeamMake.MoveTeamMaker.transform.position = Vector3(-10 , -10 , 0)
             --UITeamMake.MoveTeamMaker = nil
          end
       end
       if #NameList==3 then
          if NameList[1]=="TeamHero" then
             this:PutDownHero()
          end 
       end
    end
end

UITeamMake.TempHero = nil
UITeamMake.TempSoldier = nil
function UITeamMake:UIDragEvent( _LuaName , _Gob , _Detal)   
    if UITeamMake.MoveTeamMaker==nil then
       local NameList = GameMain.StringSplit(_Gob.name , "_")
       if #NameList==2 then
          if NameList[1]=="Hero" then
             local Index = tonumber(NameList[2])
             local HeroData = UITeamMake.HeroList[Index].HeroData
             local TempHero = this:FindHeroByUUID(HeroData.UUID)
             if TempHero~=nil then
                return
             end
             UITeamMake.TempHero = HeroData
             local FbxName = HeroData.roleData.FbxName
             this:Create3DHeroModel(FbxName)
          elseif NameList[1]=="Soldier" then
             local Index = tonumber(NameList[2])
             local SoldierData = UITeamMake.SoldierList[Index].SoldierData
             UITeamMake.TempSoldier = SoldierData
             local FbxName = SoldierData.roleData.FbxName
             this:Create3DSoldierModel(FbxName)
          end
       end 
       if #NameList==3 then
          if NameList[1]=="TeamHero" then        
             local PointInfo = GameMain.StringSplit(_Gob.name , "_")         
             local TempX = tonumber(PointInfo[2])
             local TempY = tonumber(PointInfo[3])
             TeamMakeSys.ClearPutPoint(TempX , TempY)             --ѡ��ǰ�ڷźõĶ��� �������ռ�õ�
             local TempHero = this:FindHeroByPos(TempX , TempY)
             if TempHero~=nil then
                UITeamMake.TempHero = TempHero
                --UITeamMake.UPHeros[UITeamMake.TempHero.UUID] = nil
             end
             UITeamMake.MoveTeamMaker = _Gob   
          end
       end
    end
   
    if UITeamMake.MoveTeamMaker~=nil then
       local ray = UITeamMake.TeamCa:ScreenPointToRay(Input.mousePosition)
       GameMain.GetHitRay(ray,1000,UITeamMake.LateUpdateRay)
    end 
end

function UITeamMake:UIDragUpEvent( _LuaName , _Gob , _UpGob , _DragGob)
   --Debug.LogError(_Gob)
   --Debug.LogError(_UpGob)
   --Debug.LogError(_DragGob)
   local Type = GameMain.StringSplit(_UpGob.name , "_")  
   if Type[1]=="Soldier" then
       local PointInfo = GameMain.StringSplit(_Gob.name , "_")  
       if PointInfo==nil then
          return
       end       
       local TempX = tonumber(PointInfo[2])
       local TempY = tonumber(PointInfo[3])
       Debug.LogError(TempX)
       Debug.LogError(TempY)
       this:PutDownSolider(TempX , TempY)
   end
end


function UITeamMake:UIHand(_LuaName , _Gob)
   if _Gob.name == "BackButton" then
      this:SaveHeroTeam()
   end
end

function UITeamMake.LateUpdateRay(terHit,hitInfo)
   if terHit==false then
      return
   end

   local pos = Vector3(hitInfo.point.x,hitInfo.point.y,hitInfo.point.z)
   this:SetTeamPos(UITeamMake.MoveTeamMaker , pos.x , pos.y)
end

UITeamMake.Point = nil
function UITeamMake:SetTeamPos(_Gob , _WorldX , _WorldY)
   local Point = TeamMakeSys.GetPoint(_WorldX , _WorldY)
   if Point==nil then
      return
   end
   if UITeamMake.Point ~= Point then
      UITeamMake.Point = Point
      _Gob.transform.position = Vector3(Point.PosX ,Point.PosY , 0)
      if TeamMakeSys.JudgePoint(UITeamMake.Point)==true then            --�Ƿ���λ�ñ�ռ

      else

      end
   end
end

function UITeamMake:PutDownHero()
   if TeamMakeSys.JudgePoint(UITeamMake.Point)==true then               --��ǰ35����û�б�ռ ����Ӣ��
      TeamMakeSys.PutDownTeamMake(UITeamMake.Point)  
      UITeamMake.MoveTeamMaker.transform.name = "TeamHero_"..tostring(UITeamMake.Point.X).."_"..tostring(UITeamMake.Point.Y)   
      this:SetTeamHero(UITeamMake.TempHero , UITeamMake.Point.X , UITeamMake.Point.Y , UITeamMake.MoveTeamMaker)   
   else
      UITeamMake.MoveTeamMaker.transform.position = Vector3(-10 , -10 , 0)
   end
   UITeamMake.MoveTeamMaker = nil
end

function UITeamMake:PutDownSolider(_X , _Y)                              --����ʿ�� ����ʿ����Ϣ������ϵͳ
   
   local TempHero = this:FindHeroByPos(_X , _Y)
   if TempHero~=nil then
      local _UUID = TempHero.UUID
      local _UpHero = UITeamMake.UPHeros[_UUID]
      if _UpHero~=nil then
         local _LastSoldierModel = _UpHero.HeroGob.transform:FindChild("SoldierModel")
         if _LastSoldierModel~=nil then
            Debug.LogError(_LastSoldierModel)
            GameObject.Destroy(_LastSoldierModel.gameObject)
         end
         UITeamMake.MoveTeamMaker.transform.parent = _UpHero.HeroGob.transform
         UITeamMake.MoveTeamMaker.transform.localPosition = Vector3(0 , 0 , 0) 
         UITeamMake.MoveTeamMaker.transform.name = "SoldierModel"     
         this:SetTeamSoldier(_UUID , UITeamMake.TempSoldier.Dbid)
         UITeamMake.MoveTeamMaker = nil
      end
   end
end

function UITeamMake:SetTeamHero(_Hero , _X , _Y , _HeroGob)             --��������Ӣ�۵����ݲ�
   if UITeamMake.UPHeros[_Hero.UUID]==nil then
      UITeamMake.UPHeros[_Hero.UUID] = 
      {
         X = _X,
         Y = _Y,
         HeroData = _Hero,
         HeroGob = _HeroGob,
         SoldierId = 50031,
      }
      this:Create3DSoldierModelInit(UITeamMake.UPHeros[_Hero.UUID])
   else
      UITeamMake.UPHeros[_Hero.UUID] = 
      {
         X = _X,
         Y = _Y,
         HeroData = _Hero,
         HeroGob = _HeroGob,
         SoldierId = UITeamMake.UPHeros[_Hero.UUID].SoldierId,
      }
   end
end

function UITeamMake:SetTeamSoldier(_HeroUUID , _SoldierId)           --��������ʿ�������ݲ�
   UITeamMake.UPHeros[_HeroUUID].SoldierId = _SoldierId
   --GameMain.Print(UITeamMake.UPHeros)
end

function UITeamMake:FindHeroByUUID(_UUID)
   if UITeamMake.UPHeros[_UUID]~=nil then
      return UITeamMake.UPHeros[_UUID].HeroData
   else
      return nil
   end
end

function UITeamMake:FindHeroByPos(_X , _Y)
   for key , value in pairs(UITeamMake.UPHeros) do
       if value.X==_X and value.Y==_Y then
          return value.HeroData
       end
   end
   return nil
end

function UITeamMake:SaveHeroTeam()
    TeamSys.SetPvpHeroInfo(UITeamMake.UPHeros , UITeamMake.NowTeamType)
end

function UITeamMake:ClearPutDownTeam()

end

function UITeamMake:ReleasPanel()
    

end

return UITeamMake