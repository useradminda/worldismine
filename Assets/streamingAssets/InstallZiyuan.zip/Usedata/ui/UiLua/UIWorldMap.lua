UIWorldMap = {}

local UIWorldMap = BasePanel:new()     
local this = UIWorldMap
UIWorldMap.UIWorldMapGob = nil
UIWorldMap.X = 0
UIWorldMap.Y = 0
UIWorldMap.EndX = 0
UIWorldMap.EndZ = 0


function UIWorldMap:OpenUI(_PanelName , _LuaName)
	
    UIWorldMap.UIWorldMapGob = MainGameUI.FindPanel("UIWorldMap") 
    
end

function UIWorldMap:UIHand(_LuaName , _Gob)
   if _Gob.name == "MoveButton" then
      this:MoveEvent()
   end
   if _Gob.name == "CityInfoPanel" then
      this:CloseCityInfoPanel()
   end
   if _Gob.name == "BackChose" then
      this:BackChose()
   end
   if _Gob.name == "MyPosition" then
      this:SetCameraPosition()
   end
end

function UIWorldMap:SetCameraPosition()
   if PlayerControl.TheMeCharacter~=nil then      
      PlayerControl.MainCameraTransform.localPosition = PlayerControl.TheMeCharacter.PlayerTrans.localPosition
   end
end

function UIWorldMap:BackChose()
   local UIControlTar = MainGameUI.FindPanelTarget("UIControl")
   UIControlTar.UITT.gameObject:SetActive(true)
end

function UIWorldMap:UIOnPress(_LuaName , _Gob , _ispress)
    --[[ Debug.LogError(_ispress)
     if _Gob.name == "BGBOX" then
        local t = Input.GetAxis("Vertical")
        Debug.LogError(t)
     end--]]
end

function UIWorldMap:UIDragEvent(_LuaName , _Gob , _Detal)
     if _Gob.name == "MoveBOX" then
        UIWorldMap.X = _Detal.x * 2
        UIWorldMap.Y = _Detal.y * 2
        UIWorldMap.EndX = PlayerControl.MainCameraTransform.localPosition.x - UIWorldMap.X
        UIWorldMap.EndZ = PlayerControl.MainCameraTransform.localPosition.z - UIWorldMap.Y

        if UIWorldMap.EndX <= 960 then
           UIWorldMap.EndX = 960
        elseif  UIWorldMap.EndX >= 5532 then
           UIWorldMap.EndX = 5532
        end

        if UIWorldMap.EndZ <= 593 then    
           UIWorldMap.EndZ = 593
        elseif UIWorldMap.EndZ >= 4504 then
           UIWorldMap.EndZ = 4504
        end
        PlayerControl.MainCameraTransform.localPosition = Vector3(UIWorldMap.EndX  , 500 , UIWorldMap.EndZ)
     end

     
end


UIWorldMap.ChoseCityNode = nil
UIWorldMap.CityInfoPanel = nil
UIWorldMap.CityOwnership = nil
UIWorldMap.DefencePeople = nil
UIWorldMap.AttackPeople = nil
function UIWorldMap:OpenCityInfoPanel(_CityGob)
    local NodeId = tonumber(_CityGob.name)
    local TempNode = WorldMapSys.CityNodes[NodeId]

    if TempNode.CityType==2 then
       return
    end

    if UIWorldMap.CityInfoPanel == nil then
       UIWorldMap.CityInfoPanel = UIWorldMap.UIWorldMapGob.transform:FindChild("CityInfoPanel")
    end
    if UIWorldMap.CityOwnership==nil then
       UIWorldMap.CityOwnership = UIWorldMap.CityInfoPanel:FindChild("CityType"):FindChild("CityType"):GetComponent("UILabel")
    end
    if UIWorldMap.DefencePeople==nil then
       UIWorldMap.DefencePeople = UIWorldMap.CityInfoPanel:FindChild("CityPeople"):FindChild("CityNum"):GetComponent("UILabel")
    end
    if UIWorldMap.AttackPeople==nil then
       UIWorldMap.AttackPeople = UIWorldMap.CityInfoPanel:FindChild("AttackPeople"):FindChild("AttackNum"):GetComponent("UILabel")
    end
    
    UIWorldMap.CityInfoPanel.gameObject:SetActive(true)    
    UIWorldMap.ChoseCityNode = TempNode

    UIWorldMap.CityOwnership.text = UIWorldMap.ChoseCityNode.OwnerShipNameNow
    UIWorldMap.DefencePeople.text = tostring(UIWorldMap.ChoseCityNode.DefenceNum)
    UIWorldMap.AttackPeople.text = tostring(UIWorldMap.ChoseCityNode.AttackNum)

end

function UIWorldMap:CloseCityInfoPanel()
   UIWorldMap.CityInfoPanel.gameObject:SetActive(false)
end

function UIWorldMap:MoveEvent()
   PlayerControl.TheMeCharacter:SetEndNode(UIWorldMap.ChoseCityNode)
   this:CloseCityInfoPanel()
end

function UIWorldMap:ReleasPanel()
    
    UIWorldMap.UIWorldMapGob = nil
    UIWorldMap.ChoseCityNode = nil
    UIWorldMap.CityInfoPanel = nil
    UIWorldMap.CityOwnership = nil
    UIWorldMap.DefencePeople = nil
    UIWorldMap.AttackPeople = nil
end

return UIWorldMap