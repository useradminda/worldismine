--"version :20150810   ser version 387 "


import "UnityEngine"
--import "DotNetClient"

GameMainState = {"null","bulletin","LoadUI","Login","CreatePlayer","mainscene","battle"} --游戏状态
function loadBoosCb(boos)
    local boss = GameObject.Instantiate(boos)
end
GameMain = {}
local MyGameMainState = "null"		--当前游戏状态
local this = GameMain
GameMain.isRolePropShowTest = false
GameMain.isSceneTest = false
GameMain.isSkillDamageTest = false	--技能伤害测试
GameMain.isPVPTest = false			--批量测试pvp匹配成功率
GameMain.UseAutoAttack = 0 --设置玩家托管   要读存档
--进入游戏初始化-

function GameMain.IniDB()
    --[[local AiLvlConflua = this.requireLuaFile("AiLvlConf")
    AiLvlConflua.IniSome()
    local EffectConfiglua =  this.requireLuaFile("EffectConfig")
    EffectConfiglua.IniSome()
    local BuffConfiglua = this.requireLuaFile("BuffConfig")
    BuffConfiglua.IniSome()
    local SkillDatalua = this.requireLuaFile("SkillData")
    SkillDatalua.IniSome()
    local RolePropConfiglua=  this.requireLuaFile("RolePropConfig")
    RolePropConfiglua.IniSome()
    local AmmoConfiglua = this.requireLuaFile("AmmoConfig")
    AmmoConfiglua.IniSome()
    local BSBuffConfiglua = this.requireLuaFile("BSBuffConfig")
    BSBuffConfiglua.IniSome()
    local CurverConfig = this.requireLuaFile("CurverConfig")
    CurverConfig.IniSome()
    local DB_RoleSkillMagConfig = this.requireLuaFile("DB_RoleSkillMag")
    DB_RoleSkillMagConfig.IniSome()
    local ItemDataConfig = this.requireLuaFile("ItemDataConfig")
    ItemDataConfig.IniSome()
    local ResourceDataConfig = this.requireLuaFile("ResourceDataConfig")
    ResourceDataConfig.IniSome()
    local UpLvlConfig = this.requireLuaFile("UpLvlConfig")
    UpLvlConfig.IniSome()
    local UpQualityConfig = this.requireLuaFile("UpQualityConfig")
    UpQualityConfig.IniSome()
    local UpStarConfig = this.requireLuaFile("UpStarConfig")
    UpStarConfig.IniSome()
    local EquipConfig = this.requireLuaFile("EquipDataConfig")
    EquipConfig.IniSome()
    local NeedExpConfig = this.requireLuaFile("UpEquipLvlNeedExpConfig")
    NeedExpConfig.IniSome()
    local EquipExp = this.requireLuaFile("UpEquipExpConfig")
    EquipExp.IniSome()
    local MapConfig = this.requireLuaFile("MapDataConfig")
    MapConfig.IniSome()
    local ChapterConfig = this.requireLuaFile("ChapterDataConfig")
    ChapterConfig.IniSome()
    local DebrisConfig = this.requireLuaFile("DebrisDataConfig")
    DebrisConfig.IniSome()
    local UpEquipQuality = this.requireLuaFile("UpEquipQualityConfig")
    UpEquipQuality.IniSome()
    local Max_Config = this.requireLuaFile("Max_ConfigData")
    Max_Config.IniSome()
    local RewardsConfig = this.requireLuaFile("RewardsContentConfig")
    RewardsConfig.IniSome()
    local SignRewardConfig = this.requireLuaFile("SignDailyRewardConfig")
    SignRewardConfig.IniSome()
    local SignLvlConfig = this.requireLuaFile("SignLvlRewardConfig")
    SignLvlConfig.IniSome()
    local SignOnlineConfig = this.requireLuaFile("SignOnlineRewardConfig")
    SignOnlineConfig.IniSome()
    local VipConfig = this.requireLuaFile("VipConfig")
    VipConfig.IniSome()
    local RoleSkillCoinConfig = this.requireLuaFile("RoleSkillCoinConfig")
    RoleSkillCoinConfig.IniSome()
    local MainRewardConfig = this.requireLuaFile("MainRewardConfig")
    MainRewardConfig.IniSome()
    local DailyRewardConfig = this.requireLuaFile("DailyRewardConfig")
    DailyRewardConfig.IniSome()
    local Role_MapExpConfig = this.requireLuaFile("Role_MapExpConfig")
    Role_MapExpConfig.IniSome()
    local MutLanguageConfig = this.requireLuaFile("MutLanguageConfig")
    MutLanguageConfig.IniSome()
    local NameConfig = this.requireLuaFile("NameConfig")
    NameConfig.IniSome()
    local RiskConfig = this.requireLuaFile("RiskConfig")
    RiskConfig.IniSome()
    local SoundConf = this.requireLuaFile("SoundConf")
    SoundConf.IniSome()
    local TipsConfig = this.requireLuaFile("TipsConfig")
    TipsConfig.IniSome()
    local GuideConfig = this.requireLuaFile("GuideConfig")
    GuideConfig.IniSome()
    local BroadcastConfig = this.requireLuaFile("BroadcastConfig")
    BroadcastConfig.IniSome()
    local TalkConfig = this.requireLuaFile("TalkConfig")
    TalkConfig.IniSome()--]]
    local WorldMapConfig = this.requireLuaFile("WorldMapConfig")
    WorldMapConfig.IniSome()
    local RoleDataConfig = this.requireLuaFile("RoleDataConfig")
    RoleDataConfig.IniSome()
    local RoleSkillConfig = this.requireLuaFile("RoleSkillConfig")
    RoleSkillConfig.IniSome()
    local AmmoConfig = this.requireLuaFile("AmmoConfig")
    AmmoConfig.IniSome()
	
	local BuffConfig = this.requireLuaFile("BuffConfig")
    BuffConfig.IniSome()
	
	local TxConfig = this.requireLuaFile("TxConfig")
    TxConfig.IniSome()
	
    local SoliderQualityUpConfig = this.requireLuaFile("SoliderQualityUpConfig")
    SoliderQualityUpConfig.IniSome()
    local MapConfig = this.requireLuaFile("MapConfig")
    MapConfig.IniSome()
    local ItemConfig=this.requireLuaFile("ItemDataConfig")
     ItemConfig.IniSome()
end

function GameMain.requireIniFile()

   this.requireLuaFile("WebEvent")
   this.requireLuaFile("SocketClient")
   this.requireLuaFile("GameModel")
   this.requireLuaFile("CalculateRoleProp")
   this.requireLuaFile("LoginData")
   this.requireLuaFile("handleNet_Game")
   this.requireLuaFile("BasePanel")
   this.requireLuaFile("MainGameUI")
   this.requireLuaFile("UIstring")
   this.requireLuaFile("ClinetInfomation")
   this.requireLuaFile("AtlasMsg")
   this.requireLuaFile("ResourceManager")
   this.requireLuaFile("ItemBase")
   --[[ this.requireLuaFile("SocketClient")

    this.requireLuaFile("configMag")

    this.requireLuaFile("SkillConfig")
    this.requireLuaFile("AmmoColliDisEffConfig")
    this.requireLuaFile("WallConfig")
    this.requireLuaFile("AmmoColliDisEffConfig")
    this.requireLuaFile("lgBsBuffMag")


    this.requireLuaFile("ResourceManager")
    this.requireLuaFile("StringExt")
    this.requireLuaFile("MainGameUI")

    this.requireLuaFile("lgBsBuffMag")
    this.requireLuaFile("lgSkillAiFun")
    this.requireLuaFile("normalAi")


    this.requireLuaFile("ClinetInfomation")
    this.requireLuaFile("DataUIInstance")
    this.requireLuaFile("NormalRecEvent")
    this.requireLuaFile("AccountInfo")
    this.requireLuaFile("BasePanel")
    this.requireLuaFile("ItemBase")
    this.requireLuaFile("PlayerControl")
    this.requireLuaFile("WebEvent")
    this.requireLuaFile("GameModel")
    this.requireLuaFile("LoginData")
    this.requireLuaFile("handleNet_Game")

    this.requireLuaFile("LoadingPanel")

    this.requireLuaFile("lgRolePopListMag")

    this.requireLuaFile("lgMapInfoMag")
    this.requireLuaFile("lgMapStandPosMag")


    this.requireLuaFile("AtlasMsg")
    this.requireLuaFile("Create3DModel")

    this.requireLuaFile("lgFindAmmoPosition")
    this.requireLuaFile("EyeFaceConfig")
    this.requireLuaFile("RoleModeSizeConfig")
    this.requireLuaFile("DebugLogMag")

    --]]
end


function GameMain.IniSome()

    GameMain.requireIniFile()
    GameMain.IniDB()

    GameModel.Init()

    GameMain.InitWorldMap()
    TeamMakeSys.InitPonts()

    --[[GameMain.IniDB() --加载数据库配置
    GameMain.requireIniFile()

    GameMain.GetAutoAttSet()

    GameModel.Init()

    GameStateIns.LoginAllState()                                    --注册游戏状态
    GameMain.EnterLoadingBoundle()


    GameMain.AddCallBack("GameMain.NetDieCB", GameMain.NetDieCB)--]]
end

local ChangeStateto = "null"

function GameMain.SetStateChange(changeto)
    if MyGameMainState ~= changeto then
        ChangeStateto = changeto
        this.QuitNowState()
    end


end
function GameMain.QuitNowState()
    if MyGameMainState~="null" then
        --snbug
        --Debug.Log("GameMain.QuitNowState "..MyGameMainState)
        this.QuitNowStateFinish()
    else
        this.QuitNowStateFinish()
    end
end

function GameMain.QuitNowStateFinish()

    this.EnterState()
end

function GameMain.EnterState()
    --Debug.Log("GameMain.EnterState "..MyGameMainState.." "..ChangeStateto)
    MyGameMainState = ChangeStateto
    ChangeStateto = "null"

    this["EnterStateCall"][MyGameMainState]()
end
--游戏跟新-
local UpdateLuaList_ = {}
local MainSceneUpdateLuaList = {}

UpdateLuaList_.add = function (thislua) table.insert(UpdateLuaList_,thislua) end
UpdateLuaList_.del = function (thislua)
    --Debug.Log("UpdateLuaList_.del "..tostring(thislua))
    for i=1,#(UpdateLuaList_),1 do
        if UpdateLuaList_[i]== thislua then
            table.remove(UpdateLuaList_,i)
            break
        end
    end

end

--注意这里不检查是否存在  可以加2个一样的脚本-
function GameMain.AddUpdateLua(thislua)
    --Debug.Log("GameMain.AddUpdateLua")
    if thislua==nil then
        Debug.Log("GameMain.AddUpdateLua(thislua) nil")
    end

    UpdateLuaList_.add(thislua)
end
function GameMain.DelUpdateLua(thislua)
    UpdateLuaList_.del(thislua)
end
GameMain.testobj = nil

--GameMain.UpdataHz = 2  --更新的频率
--GameMain.useUpdataHz = -1
GameMain.PauseGameUpdate = false
GameMain.t = 1
function GameMain.Update()
    --[[if GameMain.useUpdataHz==-1 then
    GameMain.useUpdataHz = 1
    return
    else
    GameMain.useUpdataHz=-1
    end--]]

    for listid = 1,#(UpdateLuaList_),1 do
        if UpdateLuaList_[listid]~=nil then
            --return
            UpdateLuaList_[listid](Time.deltaTime)
        end

    end

    if GameStateIns~=nil and  GameStateIns.NowStateName=="mainsceneState" then
        for i = 1 , #(MainSceneUpdateLuaList) , 1 do
            if MainSceneUpdateLuaList[i]~=nil then
                --return
                MainSceneUpdateLuaList[i](Time.deltaTime)
            end

        end
    end
end
--[[function GameMain.testabFun(prefab)
GameObject.Instantiate(prefab)
--GameMain.testobj = GameObject.Instantiate(prefab)
--GameMain.testobj.name = "testobj1"
--GameMain.testobj =nil
end	--]]

-- 最好在没有要加载东西的时候调用清理  lgNoDelCsFun.Ins:GetLoadObjCBListNum() ? 0
function GameMain.DoClearAsset()
    collectgarbage("collect")
    lgNoDelCsFun.Ins:DoClear()
end


MainSceneUpdateLuaList.add = function (thislua) table.insert(MainSceneUpdateLuaList,thislua) end
MainSceneUpdateLuaList.del = function (thislua)
    --Debug.Log("MainSceneUpdateLuaList.del "..tostring(thislua))
    for i=1,#(MainSceneUpdateLuaList),1 do
        if MainSceneUpdateLuaList[i]== thislua then
            table.remove(MainSceneUpdateLuaList,i)
            break
        end
    end

end


--mainSceneUpdate方法
function GameMain.AddMainSceneUpdateLua(thislua)
    --Debug.Log("GameMain.AddUpdateLua")
    if thislua==nil then
        Debug.Log("GameMain.AddUpdateLua(thislua) nil")
    end

    MainSceneUpdateLuaList.add(thislua)
end
function GameMain.DelMainSceneUpdateLua(thislua)
    MainSceneUpdateLuaList.del(thislua)
end


local LateUpdateLuaList_ = {}
LateUpdateLuaList_.add = function (thislua) table.insert(LateUpdateLuaList_,thislua) end
LateUpdateLuaList_.del = function (thislua)
    --Debug.Log("UpdateLuaList_.del "..tostring(thislua))
    for i=1,#(LateUpdateLuaList_),1 do
        if LateUpdateLuaList_[i]== thislua then
            table.remove(LateUpdateLuaList_,i)
            break
        end
    end

end
function GameMain.AddLateUpdateLua(thislua)
    --Debug.Log("GameMain.AddUpdateLua")
    if thislua==nil then
        Debug.Log("GameMain.AddLateUpdateLua(thislua) nil")
    end

    LateUpdateLuaList_.add(thislua)
end
function GameMain.DelLateUpdateLua(thislua)
    LateUpdateLuaList_.del(thislua)
end
function GameMain.LateUpdate()
    --Debug.LogError("GameMain.LateUpdate(dt) dt="..dt)
    for listid = 1,#(LateUpdateLuaList_),1 do
        if LateUpdateLuaList_[listid]~=nil then

            LateUpdateLuaList_[listid](Time.deltaTime)
        end

    end
end
--[[function GameMain.CB1(info,assetBundle)

local addobj = GameObject.Instantiate(assetBundle)


--addobj.transform.localPosition = Vector3.zero
--addobj.transform.localRotation = Quaternion.identity

end	--]]

--退出游戏-
function GameMain.Quit()
    Application.Quit();
end

--重新开始游戏-
function GameMain.Resetgame()
    SetStateChange("Login");
end
function GameMain.GetGameState()
    return MyGameMainState
end
--luaPathType =0  uilua  1 gmlua 2 commenlua 3 skilllua
function GameMain.DoLuaFile(luaPathType,filename)

    local path =""
    if isPctest ==true then
        if luaPathType ==0 then
            path =UiLuaPathPc.."/"..filename

        else
            if luaPathType == 1 then
                path = GmLuaPathPc.."/"..filename
            else
                if luaPathType == 2 then
                    path = ComLuaPathPc.."/"..filename
                end
            end
        end
    else
        if luaPathType ==0 then
            path =UiLuaPath.."/"..filename

        else
            if luaPathType == 1 then
                path = GmLuaPath.."/"..filename
            else
                if luaPathType == 2 then
                    path = ComLuaPath.."/"..filename
                end
            end
        end

    end
    path = string.gsub(path,"/","//")
    --Debug.Log("DoLuaFile" .. path)
    return dofile(path)
end
function GameMain.LoadLuaFile(filename)
    --	local luaStr = lgNoDelCsFun.Ins:LoadLuaStr(filename)
    --	return loadstring(luaStr)()
    return loadfile(filename)
end
function GameMain.requireLuaFile(filename)
    --	Debug.Log("requirefile:" .. filename)
    --	local luaStr = lgNoDelCsFun.Ins:LoadLuaStr(filename)
    --	return loadstring(luaStr)()
    return require(filename)
end
--进入战斗场景

local EnterBattleP_ = {
    Bt_map_name = "",		--加载副本scene名
    Bt_Type = "",			--副本类型-
    Bt_SC_name ="",			--场景配置文件名-
    Bt_SC_Eve = "",			--场景事件描述  包括怪物生成 胜利失败条件 镜头动画 剧情等-
    Bt_MapId = "",          --副本ID
    Bt_GameType = "",       --玩法类型  jjc fuben pvp boss
}
function GameMain.EnterTestLocalBattle()
    --测试数据-
    --Debug.Log("GameMain.EnterTestLocalBattle test")
    EnterBattleP_.Bt_map_name = "BasicScene_2"
    EnterBattleP_.Bt_Type = "pve" --BsType.pvp
    EnterBattleP_.Bt_NetBattle = false
    EnterBattleP_.Bt_SC_name = "Elf_1" --"BS_6_2"
    EnterBattleP_.Bt_SC_Eve = ""
    EnterBattleP_.Bt_MapId = 1410103
    EnterBattleP_.Bt_GameType = ""
    EnterBattleP_.Music = "Music_battle1"
    this.SetStateChange("battle")
    GameMain.EnterBattleState()
end

function GameMain.EnterMapBattle(_MapInfo)                          --进入普通副本

    EnterBattleP_.Bt_map_name = "BasicScene_2"
    EnterBattleP_.Bt_Type =  "pve"--tostring(_MapInfo.BattleType) --BsType.pvp      --关卡类型
    EnterBattleP_.Bt_NetBattle = false
    EnterBattleP_.Bt_SC_name = _MapInfo.Scene_Name
    EnterBattleP_.Bt_MapId = tostring(_MapInfo.Id)                      --进入某个关卡的ID
    EnterBattleP_.Bt_SC_Eve = ""
    EnterBattleP_.Bt_GameType = "fuben"
    EnterBattleP_.Music = _MapInfo.Music
    --GameMain.Print(EnterBattleP_, "EnterBattleP_ ========222========")
    this.SetStateChange("battle")
    GameMain.EnterBattleState()
end

function GameMain.EnterGeneraMapBattle(_MapInfo)                    --进入通用副本

    EnterBattleP_.Bt_map_name = "BasicScene_2"
    EnterBattleP_.Bt_Type =  "pve"--tostring(_MapInfo.BattleType) --BsType.pvp      --关卡类型
    EnterBattleP_.Bt_NetBattle = false
    EnterBattleP_.Bt_SC_name = _MapInfo.Scene_Name
    EnterBattleP_.Bt_MapId = tostring(_MapInfo.Id)                      --进入某个关卡的ID
    EnterBattleP_.Bt_SC_Eve = ""
    EnterBattleP_.Bt_GameType = "Generafuben"
    EnterBattleP_.Music = _MapInfo.Music
    --GameMain.Print(EnterBattleP_, "EnterBattleP_ ========222========")
    this.SetStateChange("battle")
    GameMain.EnterBattleState()
end

GameMain.isAutoFightTest = false
function GameMain.EnterBattleTest(basicMapName,btType,isNet,dataConfigFileName,mapId)

    EnterBattleP_.Bt_map_name = basicMapName
    EnterBattleP_.Bt_Type = "pve" --BsType.pvp      --关卡类型
    EnterBattleP_.Bt_NetBattle = false
    --[[
    if isNet == "True" then
    EnterBattleP_.Bt_NetBattle = true
    else
    EnterBattleP_.Bt_NetBattle = false
    end
    --]]
    EnterBattleP_.Bt_SC_name = dataConfigFileName             --暂时用这个场景
    EnterBattleP_.Bt_MapId = mapId --"1410101"                      --进入某个关卡的ID
    EnterBattleP_.Bt_SC_Eve = ""

    GameMain.isAutoFightTest = true
    --GameMain.Print(EnterBattleP_, "EnterBattleP_ ================")
    this.SetStateChange("battle")
    GameMain.EnterBattleState()
end



--接收聊天消息
function GameMain.ChatSysGetMessage(chatType, dataType, data)
    ChatSys.GetMessage(chatType,dataType, data)
end

--发送聊天消息
function GameMain.ChatSysSendMessage(chatType, dataType, data)
    ChatSys.SendMessage(chatType,dataType, data)
end

--加载bunlde test
function GameMain.LoadUIAssetBundleTest(prefabName)
    ResourceManager.LoadAssetUI(prefabName, GameMain.LoadUIAssetBundleTestCb)
end
--加载bunlde test
function GameMain.LoadGMAssetBundleTest(prefabName)
    ResourceManager.LoadAsset(prefabName, GameMain.LoadGMAssetBundleTestCb)
end
--提示消息
function GameMain.PopTip(tipId)
    DataUIInstance.PopTip(tipId)
end
----AssetBunld初始化完成
--function GameMain.AssetBundleInitFinish(isFinish)
--    ResourceManager.InitFinish()
--end

function GameMain.LoadGMAssetBundleTestCb(bundle)
    Debug.Log("LoadGMAssetBundleTestCb" .. bundle.name)
end

function GameMain.LoadUIAssetBundleTestCb(bundle)
    Debug.Log("LoadUIAssetBundleTestCb" .. bundle.name)
end

--[[
[Bt_NetBattle] => false
[Bt_MapId] => ""
[Bt_SC_name] => "BS_6_2"
[Bt_map_name] => "BasicScene_2"
[Bt_Type] => "3"
[Bt_SC_Eve] => ""

--]]
--[[
function GameMain.EnterNetPvPTestBattle()
    local PVPMap = MapDataSys.GetMapInfoData(MapDataSys.MapIDPVP)
    --测试数据-
    --Debug.Log("GameMain.EnterNetPvPTestBattle test")
    EnterBattleP_.Bt_map_name = "BattleScene"
    EnterBattleP_.Bt_Type = "pvp" --BsType.pvp
    EnterBattleP_.Bt_NetBattle = true
    EnterBattleP_.Bt_SC_name = PVPMap.Scene_Name --BattleScene04
    EnterBattleP_.Bt_MapId = MapDataSys.MapIDPVP
    EnterBattleP_.Bt_SC_Eve = ""
    EnterBattleP_.Bt_GameType = "pvp"
    EnterBattleP_.Music = PVPMap.Music

    --snbug test
    --Debug.Log("lgNoDelCsFun.Ins:LuaFunT345345345346436est(Main.DebugLogstr)")
    --lgNoDelCsFun.Ins:LuaFunTest("LuaFunTest990909",GameMain.DebugLogstr)

    GameMain.ask_enter_battle(12) --请求进入PVP战场
end
function GameMain.EnterNetzhangyuBattle()
    --测试数据-
    --Debug.Log("GameMain.EnterNetzhangyuBattle test")
    EnterBattleP_.Bt_map_name = "BattleScene"
    EnterBattleP_.Bt_Type = "pvp" --BsType.pvp
    EnterBattleP_.Bt_NetBattle = true
    EnterBattleP_.Bt_SC_name = "BattleScene07_hen_BOSS1" --"BattleScene07"
    EnterBattleP_.Bt_SC_Eve = ""
    EnterBattleP_.Bt_MapId = 1410103
    EnterBattleP_.Bt_GameType = "Boss"
    EnterBattleP_.Music = "Music_battle1"

    GameMain.ask_enter_battle(1) --请求进入boss战场
end

function GameMain.EnterNetDengLongYuBattle()
    --测试数据-
    --Debug.Log("GameMain.EnterNetDengLongYuBattle test")
    EnterBattleP_.Bt_map_name = "BattleScene"
    EnterBattleP_.Bt_Type = "pvp" --BsType.pvp
    EnterBattleP_.Bt_NetBattle = true
    EnterBattleP_.Bt_SC_name = "BattleScene08_hen_BOSS2" --"BattleScene08"
    EnterBattleP_.Bt_SC_Eve = ""
    EnterBattleP_.Bt_GameType = "Boss"
    EnterBattleP_.Music = "Music_battle1"

    GameMain.ask_enter_battle(1) --请求进入boss战场
end

function GameMain.EnterNetJJCBattle()
    local JJCMap = MapDataSys.GetMapInfoData(MapDataSys.MapIDJJC)

    --Debug.Log("GameMain.EnterNetJJCBattle")
    EnterBattleP_.Bt_map_name = "BattleScene"
    EnterBattleP_.Bt_Type = "pve" --BsType.pvp
    EnterBattleP_.Bt_NetBattle = false
    EnterBattleP_.Bt_SC_name = JJCMap.Scene_Name--"Elf_1" --"BattleScene08"
    EnterBattleP_.Bt_SC_Eve = ""
    EnterBattleP_.Bt_MapId = MapDataSys.MapIDJJC
    EnterBattleP_.Bt_GameType = "jjc"
    EnterBattleP_.Music = "Music_battle1"
    --GameMain.Print(EnterBattleP_, "EnterBattleP_ ========222========")
    this.SetStateChange("battle")
    GameMain.EnterBattleState()
end

function GameMain.EnterDailyBossBattle()
    local BossMap = MapDataSys.GetMapInfoData(MapDataSys.MapIDZhangyu)

    --Debug.Log("GameMain.EnterDailyBossBattle")
    EnterBattleP_.Bt_map_name = "BattleScene"
    EnterBattleP_.Bt_Type = "pve" --BsType.pvp
    EnterBattleP_.Bt_NetBattle = false
    EnterBattleP_.Bt_SC_name = BossMap.Scene_Name--"Elf_1" --"BattleScene08"
    EnterBattleP_.Bt_SC_Eve = ""
    EnterBattleP_.Bt_MapId = MapDataSys.MapIDZhangyu
    EnterBattleP_.Bt_GameType = "Boss"
    EnterBattleP_.Music = "Music_battle1"
    --GameMain.Print(EnterBattleP_, "EnterBattleP_ ========222========")
    this.SetStateChange("battle")
    GameMain.EnterBattleState()
end

function GameMain.EnterNetPVPRobotBattle()
    local JJCMap = MapDataSys.GetMapInfoData(MapDataSys.MapIDJJC)

    --Debug.Log("GameMain.EnterNetPVPRobotBattle")
    EnterBattleP_.Bt_map_name = "BattleScene"
    EnterBattleP_.Bt_Type = "pve" --BsType.pvp
    EnterBattleP_.Bt_NetBattle = false
    EnterBattleP_.Bt_SC_name = JJCMap.Scene_Name--"Elf_1" --"BattleScene08"
    EnterBattleP_.Bt_SC_Eve = ""
    EnterBattleP_.Bt_MapId = MapDataSys.MapIDJJC
    EnterBattleP_.Bt_GameType = "robotpvp"
    EnterBattleP_.Music = "Music_battle1"
    --GameMain.Print(EnterBattleP_, "EnterBattleP_ ========222========")
    this.SetStateChange("battle")
    GameMain.EnterBattleState()
end
--]]

function GameMain.EnterZQBattle()
    MainGameUI.ReleaseAllPanel()

    lgNoDelCsFun.Ins:EnterBattle(1 , 100101)--100102)

end

function GameMain.OutZQBattle()
    this.InitWorldMap()
end

function GameMain.AskPVEConnectBattle(BossName)				--请求链接PVE

    SocketClient.AskBattleConnect(BossName)
end

function GameMain.AskPVPConnectBattle()				--请求链接PVP排队

    SocketClient.AskBattleConnect("PVP")
end

function GameMain.DisConnectPVPBattle()				--请求断开链接PVP排队

    SocketClient.DisConnectPVPLine(nil)
end

local MyBtSceneLeader =nil
function GameMain.EnterBattle()
    --Debug.LogError("GameMain.EnterBattle() ")
    MainGameUI.ReleaseAllPanel()

    --lgNoDelCsFun.Ins:DoClear()
    if MyBtSceneLeader==nil then
        MyBtSceneLeader = GameMain.requireLuaFile("BtSceneLeader")
    end
    MyBtSceneLeader.loadBattleScene(EnterBattleP_)
end

function GameMain.LoadMainScene()

end

function GameMain.ReLoadMainScene()                     --重回主场景
    Debug.Log("#######################GameMain.EnterMainScene ########################")

    MyGameMainState = "mainscene"
    ChangeStateto = "null"

    DotNetClient.hzClient.Destroy();

    local UIBattle = MainGameUI.FindPanelTarget("UIBattle")
    if UIBattle~=nil then
        UIBattle:BattleReleasePanel()
    end
    MainGameUI.ReleaseAllPanel()

    GameMain.DelUpdateLua(BtSceneLeader.Update)
    DataUIInstance.CreateControlUI(GameMain.CreateCity)                    --加载总控制UI界面

    GameMain.EnterMainCity()

end

--切换加载LoadboundleState
function GameMain.EnterLoadingBoundle()
    GameStateIns.ChangeState("LoadingBoundleState")
end

--切换加载总UI
function GameMain.EnterLoadUI()
    GameStateIns.ChangeState("LoadUIState")
end

--切换公告界面
function GameMain.EnterBroad()
    GameStateIns.ChangeState("BroadState")
end

--切换进入登录
function GameMain.EnterLogin()
    GameStateIns.ChangeState("LoginState")
end
--切换进创角状态
function GameMain.EnterCreatePlayer()
    GameStateIns.ChangeState("CreatePlayerState")
end

--切换进主程状态
function GameMain.EnterMainCity()
    GameStateIns.ChangeState("mainsceneState")
end

--切换战斗状态
function GameMain.EnterBattleState()
    GameStateIns.ChangeState("battleState")
end

--[[GameMain.MainCity = nil
--创建主城
function GameMain.CreateCity()
    --local _data = {}
    --ResourceManager.LoadAssetByObject(_data , "City" , GameMain.CreateCityCallBack)
    GameMain.CreateCityCallBack()
end

function GameMain.CreateCityCallBack(_data , _prefab)
    --[[if GameMain.MainCity==nil then
    local City = GameObject.Instantiate(_prefab)
    City.transform.localPosition = Vector3.zero
    City.transform.localScale = Vector3.one
    GameMain.MainCity = City
    end--]]                                                                            --初始化场景内玩家
   --[[ PlayerControl.InitSome()
    local pos1 = Random.Range(1,10)
    local pos2 = Random.Range(1,10)
    local pos3 = Random.Range(1,10)
    local pos4 = Random.Range(1,10)
    local pos5 = Random.Range(1,10)
    local pos6 = Random.Range(1,10)
    local pos7 = Random.Range(1,10)
    local Pos = tostring(pos1).."_"..tostring(pos2).."_"..tostring(pos3).."_"..tostring(pos4).."_"..tostring(pos5).."_"..tostring(pos6).."_"..tostring(pos7)
    RouteSys.MoveTree(Pos)
end
--]]
--]]

--网络模块
--玩家请求进入莫pk关卡
local NetPkTarInfoList={}
local NetPkMeInfoList={}
function GameMain.GetNetPkTarInfoList()
    return NetPkTarInfoList
end
function GameMain.GetNetPkMeInfoList()
    return NetPkMeInfoList
end
local IniPkBsFinish = false
function GameMain.SetIniPkBsFinish(isfinish)
    IniPkBsFinish = isfinish
end
function GameMain.ask_enter_battle(battle_id)
    Debug.Log("##################hzClient:#######################")
    --Debug.Log(hzClient)
    IniPkBsFinish =false
    SocketClient.AskEnterBattle(battle_id, GameMain.response_enter_battle)
end

--请求返还
function GameMain.response_enter_battle(result)
    Debug.LogWarning("GameMain.response_enter_battle")
    -- NetPkTarInfoList=friendList
    --NetPkMeInfoList=enemyList
    --把对手加入NetPkTarInfoList
    --把自己对战信息写入NetPkMeInfoList

    if result==0 then

        this.SetStateChange("battle")
        GameMain.EnterBattleState()
    else --错误日志-

    end

    --GameMain.EnterNetTestBattleCB()
end
--[[function GameMain.SomeOneEnPkScence( friendList,enemyList )
--Debug.Log(" GameMain.SomeOneEnPkScence( friendList,enemyList )111111111111111111")
if MyGameMainState == "battle" and IniPkBsFinish ==true  then

--Debug.Log(" GameMain.SomeOneEnPkScence( friendList,enemyList )22222222222222222----"..tostring(#(enemyList)))
lgBtSceneMag.SomeOneEnPkScence( friendList,enemyList )
end

end--]]

--请求换坐骑
--[[function GameMain.ask_changeVehicle(driver_obj_uuid, vehicle_obj_uuid)
SocketClient.ChangeVehicleAsk(driver_obj_uuid, vehicle_obj_uuid)
end
function GameMain.update_changeVehicle(driver_obj_uuid, vehicle_obj_uuid)
lgBtSceneMag.update_changeVehicle(driver_obj_uuid, vehicle_obj_uuid)
end--]]
--请求移动-
--[[--(int NetWorldid, int NetRealid, Vector3 nowpos, Vector3 mudidi, List<Vector2> path)
function GameMain.ask_role_move( roleuuid,nowpos, mudidi,iniface, tarface,m_inRankId, path)
SocketClient.AskRoleMove(roleuuid, nowpos, mudidi, iniface, tarface, path,m_inRankId,nil)

end
--请求更新移动
--(int NetWorldid, int NetRealid, Vector3 nowpos, Vector3 mudidi, List<Vector2> path)
function GameMain.updata_role_move( roleuuid, nowpos, mudidi,iniface, tarface, path)
--Debug.Log("GameMain.updata_role_move roleuuid = "..tostring(roleuuid).." nowpos = "..tostring(nowpos))
if MyGameMainState == "battle" and IniPkBsFinish ==true  then
lgBtSceneMag.updata_role_move(roleuuid, nowpos, mudidi,iniface, tarface, path)
end
end--]]
--技能更新-
--请求使用技能-
--[[
function GameMain.ask_UseSkillNew(skill_id, src_obj_uuid, target_obj_uuid, srcPos, targetPos)
if targetPos ==nil then
targetPos =Vector4(-999,-999,-999,1)
end
--Debug.Log("GameMain.ask_UseSkill")
SocketClient.SkillAskNew(skill_id, src_obj_uuid, target_obj_uuid, srcPos, targetPos)
end

function GameMain.ask_UseSkill(skill_id, src_uuid, src_real_id, target_uuid, target_real_id, srcPos, targetPos)
if targetPos ==nil then
targetPos =Vector4(-999,-999,-999,1)
end
--Debug.Log("GameMain.ask_UseSkill")
SocketClient.SkillAsk(skill_id, src_uuid, src_real_id, target_uuid, target_real_id, srcPos, targetPos)
end
--请求使用技能结果-
function GameMain.ask_UseSkillCB(resultid,resulttable)
--Debug.Log("GameMain.ask_UseSkillCB")
if MyGameMainState == "battle" and IniPkBsFinish ==true  then
if resultid==0 then
lgBtSceneMag.ask_UseSkillCB( resultid,resulttable)
else

end
end

end
function GameMain.updata_UseSkill(infotable)
--Debug.Log("GameMain.updata_UseSkill")
if MyGameMainState == "battle" and IniPkBsFinish ==true  then
lgBtSceneMag.updata_UseSkill(infotable)
end
end
-- 角色属性更新-
function GameMain.updata_RolePop(infotable)
if MyGameMainState == "battle" and IniPkBsFinish ==true  then
lgBtSceneMag.updata_RolePop(infotable)
end
end
function GameMain.NetAskUpdata_RoleBeHurt(infotable)
lgBtSceneMag.NetAskUpdata_RoleBeHurt(infotable)
end
function GameMain.NetAskUpdata_RoleDie(infotable)
lgBtSceneMag.NetAskUpdata_RoleDie(infotable)
end--]]



--function GameMain.LoadScene(scenename)
--	--lgNoDelCsFun.Ins:debuglog(scenename,"GameMain.LoadSceneCB")


--end
--function GameMain.LoadSceneCB(scenename,p2)

--	Debug.Log("GameMain.LoadSceneCB(scenename)"..scenename..p2)
--end
function GameMain.CallBack(funname,...)
    if funcname~="HeartJump.SendHeartJumpCallBack" then
        --LoadingPanel.StopLoadingPanel()
    else
        Debug.LogError(funcname)
    end
    if this["CallBackFun"][funname]~=nil then
        this["CallBackFun"][funname](...)
    end
end
function GameMain.AddCallBack(funname, cb)
    if this["CallBackFun"][funname]==nil then
        this["CallBackFun"][funname] = cb
    end
end
local GetHitRayCB =nil

function GameMain.GetCollisionPos( thiscollision, id)
    return lgNoDelCsFun.Ins:GetCollisionPos(thiscollision, id)
end

function GameMain.GetHitRayCB(...)
    if GetHitRayCB~=nil then
        GetHitRayCB(...)
    end
end

function GameMain.GetHitRayCollider(collider,ray,far,cb)
    GetHitRayCB = cb
    GameMain["CallBackFun"]["GetHitRay"] = GameMain.GetHitRayCB
    lgNoDelCsFun.Ins:GetColliderHitRay(collider,ray,far,"GetHitRay")

end

function GameMain.GetHitRay(ray,far,cb)
    GetHitRayCB = cb
    GameMain["CallBackFun"]["GetHitRay"] = GameMain.GetHitRayCB
    lgNoDelCsFun.Ins:GetHitRay(ray,far,"GetHitRay")
end
--接收战斗网络事件下发-
function GameMain.RecNetEvent(e)
    --GameMain.Print(e," GameMain.RecNetEvent")
    if MyGameMainState == "battle" and lgBtSceneMag~=nil and lgBtSceneMag.EveSysIni ==true  then
        lgBtEventMag.NetEvent(e)
    else
        NormalRecEvent.HandleNormalNet(e)
    end
end
function GameMain.SendHttpRequest(url, data, funname, cb)
    GameMain.AddCallBack(funname, cb)

    local Wrm = WebRequestManager.GetInstance();
    Wrm:SendRequest3(url, data, funname);
end

function GameMain.SendHttpRequestNormal(url, funname, cb)
    GameMain.AddCallBack(funname, cb)

    local Wrm = WebRequestManager.GetInstance();
    Wrm:SendRequest(url , funname);
end

function GameMain.handleHttpRequest(result, returnID, errorMsg, cb)
    if returnID == 0 then
        local resulTable = GameMain.JsonDecode(result)
        this.CallBack(cb, resulTable , returnID)
    else

        this.CallBack(cb, nil , returnID)
        -- prompt error message on client
    end
end
function GameMain.SendSocketRequest(data, funname, cb)
    GameMain.AddCallBack(funname, cb)
end
function GameMain.handleSocketRequest(result, cb)
    this.CallBack(cb, result)
end

function GameMain.handleCommoninfo(data)
    --LoadingPanel.StopLoadingPanel()
    Comminfo.HandleCommon(data)

end

local JSON = nil
function GameMain.JsonDecode(jsonStr)
    if JSON==nil then
        JSON = GameMain.requireLuaFile("JSON")
    end
    return JSON:decode(jsonStr)
end
function GameMain.JsonEncode(thistable)
    if JSON==nil then
        JSON = GameMain.requireLuaFile("JSON")
    end
    return JSON:encode(thistable)
end

function SetNetUseCB(cb)
    GameMain["CallBackFun"]["NetUseCb"] = cb
end

GameMain["CallBackFun"] = {
    ["null"] = nil,
    ["LoadSceneCB"] = this.LoadSceneCB,
    ["handleHttpRequest"] = this.handleHttpRequest,
    ["Commoninfo"] = this.handleCommoninfo,
    ["GetHitRay"] =nil,
    ["NetUseCb"] = nil,
}

GameMain["EnterStateCall"] = {
    ["null"] = nil,
    ["bulletin"] = nil,
    ["LoadUI"] = nil,--this.EnterLoadUIControl,
    ["Login"] = nil,--this.EnterLogin,
    ["CreatePlayer"] =nil,-- this.EnterCreatePlayer,
    ["mainscene"] = this.LoadMainScene,
    ["battle"] =  this.EnterBattle,
}

GameMain.SkillMsg = {
    skillNoCoolDown = "skillNoCoolDown",

}
function GameMain.StringSplit(str,split)
    --Debug.Log("GameMain.StringSplit-- str = "..tostring(str))
    local list = {}
    local pos = 1
    if string.find("", split, 1) then -- this would result in endless loops
        error("split matches empty string!")
    end
    while 1 do
        local first, last = string.find(str, split, pos)
        if first then -- found?
            table.insert(list, string.sub(str, pos, first-1))
            pos = last+1
        else
            table.insert(list, string.sub(str, pos))
            break
        end
    end
    return list
end
function GameMain.Print ( t, msg )
    local print_r_cache={}

    local function sub_print_r(t,indent)
        if (print_r_cache[tostring(t)]) then
            return "\n" .. indent.."*"..tostring(t)
        else
            print_r_cache[tostring(t)]=true

            if (type(t)=="table") then
                local ret = ""
                for pos,val in pairs(t) do
                    if (type(val)=="table") then

                        ret = ret .. "\n" .. indent.."["..pos.."] => "..tostring(t).." {"
                        ret = ret .. "" .. sub_print_r(val,indent..string.rep(" ",string.len(pos)+2))
                        ret = ret .. "\n" .. indent--[[..string.rep(" ",string.len(pos)+6)--]].."}"

                    elseif (type(val)=="string") then
                        ret = ret .. "\n" .. indent.."["..pos..'] => "'..val..'"'
                    else
                        ret = ret .. "\n" .. indent.."["..pos.."] => "..tostring(val)
                    end
                end

                return ret
            else
                return "\n" .. indent..tostring(t)
            end
        end
    end

    local ret = ""
    if (type(t)=="table") then
        ret = tostring(t).." {"
        ret = ret .. sub_print_r(t,"  ")
        ret = ret .. "\n" .. "}"
    else
        ret = sub_print_r(t,"  ")
    end

    if msg == nil then
        msg = ""
    end
    Debug.Log( "---- PRINT " .. msg ..  "\n" .. ret )
end

--设置表只读
function GameMain.table_read_only(t)

    local proxy = {}
    local mt = {         -- create metatable
    __index = t,
    __newindex = function (t,k,v)
        error("attempt to update a read-only table", 2)
    end
}

setmetatable(proxy, mt)
return proxy

end


--[[
/**
@brief 一维Hermite曲线位置插值
@param fT   范围(0-1) 参数
fP0  起点位置
fP1  终点位置
fM0  起点切线
fM1  终点切线
*/
]]--
function GameMain.m_hermite_C(fT,fP0,fP1,fM0,fM1)

    local fT2 = fT*fT;
    local fT3 = fT*fT*fT;
    return (2*fT3-3*fT2+1)*fP0 + (fT3-2*fT2+fT)*fM0 + (fT3-fT2)*fM1 + (-2*fT3 + 3*fT2)*fP1
end
--[[
/**
@brief 一维Hermite曲线切线插值
@param fT   范围(0-1) 参数
fP0  起点位置
fP1  终点位置
fM0  起点切线
fM1  终点切线
*/
]]--
function GameMain.m_hermiteD_C( fT, fP0, fP1, fM0, fM1)

    local fT2 = fT*fT;
    return (6*fT2-6*fT)*fP0 + (3*fT2-4*fT+1)*fM0 + (3*fT2-2*fT)*fM1 + (-6*fT2 + 6*fT)*fP1
end

--pos str to vector3
function GameMain.PosStrToVector3( postr)
    local pos3 = GameMain.StringSplit(postr,",")
    return Vector3(tonumber( pos3[1]),tonumber(pos3[2]),tonumber(pos3[3]))
end

function GameMain.GetNowLevelName()

    local name = lgNoDelCsFun.Ins:GetNowLevelName() --Application.loadedLevelName
    return name
end

function GameMain.ListenGoinUIcontrol()											--监听加载总界面z


    local LevelName = this.GetNowLevelName()
    local bundleState = lgNoDelCsFun.Ins:GetAssetBoundleState()
    Debug.LogError("LevelName:" .. LevelName .. ",bundleState:" .. bundleState);
    if LevelName=="MainGame" then
        if bundleState==1 or bundleState == 2 then                                            --监听完成后获取服务器列表

            GameMain.EnterLoadUI()
        end
    end
end




function GameMain.ListenGoinLogin()                                               --监听加载登录界面z
    local Panelobj = MainGameUI.FindPanel("UIControl")
    if GameStateIns.NowStateName=="LoadUIState" and Panelobj~=nil then
        GameMain.EnterBroad()
    end
end

--test
function GameMain.ClickEvent(_Gob)

     PlayerControl.ClickCityEvent(_Gob)

end

function GameMain.InitWorldMap()
    if MainGameUI["target"]["UIControl"]==nil then
		local lua = GameMain.requireLuaFile("UIControl")
		local obj1 = lua:new()
	   	MainGameUI["target"]["UIControl"] = obj1
   end
   if MainGameUI["GameObject"]["UIControl"]==nil then
      MainGameUI["GameObject"]["UIControl"] = GameObject.Find("UIControl").gameObject--.transform:FindChild("Camera"):FindChild("UITT")
   end
   MainGameUI["target"]["UIControl"]:OpenUI()

   if MainGameUI["target"]["UIWorldMap"]==nil then
		local lua = GameMain.requireLuaFile("UIWorldMap")
		local obj1 = lua:new()
	   	MainGameUI["target"]["UIWorldMap"] = obj1
   end
   if MainGameUI["GameObject"]["UIWorldMap"]==nil then
      MainGameUI["GameObject"]["UIWorldMap"] = GameObject.Find("UIControl").transform:FindChild("Camera"):FindChild("AnchorCenter"):FindChild("UIWorldMap").gameObject
   end
   MainGameUI["target"]["UIWorldMap"]:OpenUI()

   if MainGameUI["target"]["UITeamMake"]==nil then
		local lua = GameMain.requireLuaFile("UITeamMake")
		local obj1 = lua:new()
	   	MainGameUI["target"]["UITeamMake"] = obj1
   end
   if MainGameUI["GameObject"]["UITeamMake"]==nil then
      MainGameUI["GameObject"]["UITeamMake"] = GameObject.Find("UIControl").transform:FindChild("Camera"):FindChild("AnchorCenter"):FindChild("UITeamMake").gameObject
   end
   MainGameUI["target"]["UITeamMake"]:OpenUI()



end


--UIeventUI事件的监听分发z
function GameMain.UIHandleEvent(_Lua , _Gob)
    if MainGameUI["UIEvent"][_Lua]~=nil then
        MainGameUI["UIEvent"][_Lua](nil , _Lua , _Gob)

    else
        --local lua = this.requireLuaFile(_Lua)
        --local gob = _Gob
        --local obj1 = lua:new()
        local Target = nil
        if MainGameUI["target"][_Lua]~=nil then
            Target = MainGameUI["target"][_Lua]
            MainGameUI["UIEvent"][_Lua] = Target.UIHand
            MainGameUI["UIEvent"][_Lua](Target , _Lua , _Gob)
        end
        -- lua = nil
        --  gob = nil

    end
end

function  GameMain.UIDragUpEvent(_Lua , _UpGob , _DragGob)
    if MainGameUI["UIDragUpEvent"][_Lua]~=nil then
        MainGameUI["UIDragUpEvent"][_Lua](nil , _Lua , _UpGob , _DragGob)
    else

        --local lua = this.requireLuaFile(_Lua)
        --local obj1 = lua:new()
        local Target = nil
        if MainGameUI["target"][_Lua]~=nil then
            -- MainGameUI["target"][_Lua] = obj1
            Target = MainGameUI["target"][_Lua]
            if Target.UIDragUpEvent==nil then
                return
            end
            MainGameUI["UIDragUpEvent"][_Lua] = Target.UIDragUpEvent
            MainGameUI["UIDragUpEvent"][_Lua](Target , _Lua , _UpGob , _DragGob)
        end
    end
end

function  GameMain.UIDragEvent(_Lua , _Gob , _Detal)
    if MainGameUI["UIDragEvent"][_Lua]~=nil then
        MainGameUI["UIDragEvent"][_Lua](nil , _Lua , _Gob , _Detal)
    else

        --local lua = this.requireLuaFile(_Lua)

        --local obj1 = lua:new()
        local Target = nil
        if MainGameUI["target"][_Lua]~=nil then
            -- MainGameUI["target"][_Lua] = obj1
            Target = MainGameUI["target"][_Lua]
            if Target.UIDragEvent==nil then
                return
            end

            MainGameUI["UIDragEvent"][_Lua] = Target.UIDragEvent
            MainGameUI["UIDragEvent"][_Lua](Target , _Lua , _Gob , _Detal)
        end
    end
end

function  GameMain.UIPressItemEvent(_Lua , _Gob , _isPress)

    if MainGameUI["UIOnPress"][_Lua]~=nil then
        MainGameUI["UIOnPress"][_Lua](nil , _Lua , _Gob , _isPress)
    else
        --local lua = this.requireLuaFile(_Lua)

        --local obj1 = lua:new()
        local Target = nil
        if MainGameUI["target"][_Lua]~=nil then
            Target = MainGameUI["target"][_Lua]
            if Target.UIOnPress==nil then
                return
            end
            MainGameUI["UIOnPress"][_Lua] = Target.UIOnPress
            MainGameUI["UIOnPress"][_Lua](Target , _Lua , _Gob , _isPress)
            -- MainGameUI["target"][_Lua] = obj1
        end
    end
end

function GameMain.GetConfigData(_Type , _Id)
    if _Type == "RoleData" then
       return RoleDataSys.GetRoleById(_Id)
    elseif _Type == "Skill" then
       return RoleSkillConfig.GetRoleSkillById(_Id)
    elseif _Type == "Ammo" then
       return AmmoConfig.GetAmmoById(_Id)
    elseif _Type == "Buff" then
       return BuffConfig.GetBuffById(_Id)
    elseif _Type == "Map" then
       return MapConfig.GetMapConfigById(_Id)
	elseif _Type == "Tx" then
       return TxConfig.GetTxById(_Id)
    end
end

function GameMain.GetRoleProp(_Id , _Lvl , _QualityLvl)
    return CalculateRoleProp.CalculatProp(_Id , _Lvl , _QualityLvl)
end

function GameMain.GetHeroProp(_Type , _Camp , _UUID)
    return CalculateRoleProp.CalculatHeroProp(10011 , 1 , 1)
end

function GameMain.GetSoliders()
    return SoliderPackageSys.GetSoliders()
end

function GameMain.GetHero()
    return HeroPackageSys.GetHero()
end

function GameMain.GetPvpTeam()
    return TeamSys.GetPvpTeam()
end

function GameMain.WebEvent(_EventId)
    --[[local Data =
    {
        Descrip = ""
    }
    if _EventId==1002 then
        Data.Descrip = UIstring.NetError
        DataUIInstance.PopTipPanel("NetError" , GameMain.HandleWebEvent , Data)
    end
    if _EventId==1007 then
        Data.Descrip = UIstring.CPPNetError
        DataUIInstance.PopTipPanel("NetError" , GameMain.HandleCPPNet , Data)
    end--]]
end

function GameMain.HandleWebEvent()
    --[[if MainGameUI.PanelOpenName~="null" and MainGameUI.NowPanelTarget~=nil then
        MainGameUI.NowPanelTarget:ClosePanel()
    end
    local UIControlTar = MainGameUI.FindPanelTarget("UIControl")
    if UIControlTar~=nil then
        UIControlTar:ClosePanel()
    end
    local UIPopPanelTar = MainGameUI.FindPanelTarget("UIPopPanel")
    if UIPopPanelTar~=nil then
        UIPopPanelTar:ClosePanel()
    end

    GuideSys.ReleaseGuide()                  --释放引导
    LoadingPanel.CloseLoadingGamePanel()

    if GameStateIns.NowStateName == "mainsceneState" then
        GameStateIns.ChangeState("LoginState")
    end

    if GameStateIns.NowStateName == "battleState" then
        if lgBtSceneMag~=nil  then
            lgBtSceneMag.EndBtSceneLogic()
        end
    end           --]]
end

function GameMain.HandleCPPNet()

end

--PHP网络事件z
function GameMain.SendPack(data , funcname , cb)
    if funcname~="HeartJump.SendHeartJumpCallBack" then
       -- LoadingPanel.OpenLoadingPanel()
    end
    GameMain.AddCallBack(funcname, cb)

    local PackIns = packMgr.GetInstance();
    PackIns:limitSendPackLua(data);
end

--深拷贝
function GameMain.DeepCopy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[GameMain.DeepCopy(orig_key)] = GameMain.DeepCopy(orig_value)
        end
        setmetatable(copy, GameMain.DeepCopy(getmetatable(orig)))
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end

function GameMain.AddComponent(obj,csstr)
    lgNoDelCsFun.Ins:AddComponent(obj.transform,csstr)
end

--更新一次自动战斗设置
function GameMain.UpdateAutoAtt()
    GameMain.SetPlayerIntSet("AutoAtt",GameMain.UseAutoAttack)
end

function GameMain.GetAutoAttSet()
    local result = false

    result,GameMain.UseAutoAttack = GameMain.GetPlayerIntSet("AutoAtt")
    if result==false then
        --GameMain.UseAutoAttack = false
        GameMain.SetPlayerIntSet("AutoAtt",GameMain.UseAutoAttack)
    end

end

--保存玩家设置 整形
function GameMain.SetPlayerIntSet(str,va)
    PlayerPrefs.SetInt (str, va)
end


--得到玩家设置 -
function GameMain.GetPlayerIntSet(str)

    if PlayerPrefs.HasKey (str) ==true then
        return true, PlayerPrefs.GetInt (str)
    end
    return false , 0
end

--获得当前开发环境
function GameMain.GetDevelopEnviroment()
    return lgNoDelCsFun.Ins:GamePlatform()
end

--网络异常通知
function GameMain.NetDieCB(str)
    DebugLogMag.PrintThisThis(3,"GameMain_NetDieCB","GameMain_NetDieCB str="..str,nil)
    if MyGameMainState == "battle" then --在战斗中 --提示退出战斗
        --弹出网络异常通知
        --GameMain.CB_QuitNowBt()

        local Data={}
        Data.Descrip =""
        if str~=nil then
            Data.Descrip = str
        end
        DataUIInstance.PopTipPanel("NetError" , GameMain.CB_QuitNowBt , Data)

    else --在外面主城
        local Data={}
        Data.Descrip =""
        if str~=nil then
            Data.Descrip = str
        end
        DataUIInstance.PopTipPanel("NetError" , nil , Data)
    end
end

--通知退出当前战斗
function GameMain.CB_QuitNowBt()
    if lgBtSceneMag~=nil  then
        lgBtSceneMag.EndBtSceneLogic()
    end
end


---------------------------------------------------------
--  网络模块测试代码
---------------------------------------------------------
function GameMain.SocketTestCase()
    -- 建立连接
    SocketClient.CreateConnection("172.16.3.114", 37001);

    --SocketClient.CreateConnection("172.16.3.84", 37001);

    --SocketClient.CreateConnection("139.196.16.254", 39009)

    -- 注册网络收包回调函数
    SocketClient.RegistMsgHandle(SocketClient.MsgID.ReceiveAfterConnected, GameMain.ReceiveAfterConnectedHandle); --确认连接
    --SocketClient.RegistMsgHandle(SocketClient.MsgID.ReceiveMove, GameMain.ReceiveMoveHandle);
    SocketClient.RegistMsgHandle(SocketClient.MsgID.ReceiveCastSpell, GameMain.ReceiveCastSpellHandle);
    SocketClient.RegistMsgHandle(SocketClient.MsgID.ReceiveDebugMsg, GameMain.ReceiveDebugMsgHandle);
    SocketClient.RegistMsgHandle(SocketClient.MsgID.ReceiveBattleEnd, SocketClient.ReceiveBattleEndHandle);

    --[[GameMain.SendMove(1);
    GameMain.SendMove(2);
    GameMain.SendMove(3);
    GameMain.SendMove(4);
	GameMain.SendCastSpell(1);
	GameMain.SendCastSpell(2);
	GameMain.SendCastSpell(3);--]]
end
function GameMain.SendCastSpell(spellId)
    local data = {
        intList = { tonumber(spellId) },
    };
	SocketClient.SendNetEvent(SocketClient.MsgID.RequestCastSpell, data);
end
function GameMain.SendMove(pos)
    local data = {
        intList = { tonumber(pos) },
    };
    SocketClient.SendNetEvent(SocketClient.MsgID.RequestMove, data);
end

function GameMain.ReceiveLoginHandle(data)



end

function GameMain.ReceiveAfterConnectedHandle(data)
    Debug.LogError("握手成功");
    local data = {
        intList = { tonumber( SocketClient.GetPlayerId() ) },
    };
    SocketClient.SendNetEvent(SocketClient.MsgID.RequestLogin, data);
end

function GameMain.ReceiveDebugMsgHandle(data)
    Debug.LogWarning("Info: " .. data.stringList[1]);
end

function GameMain.ReceiveMoveHandle(data)
    local playerId = tonumber(data.intList[1]);
    local v = tonumber(data.intList[2]);
    local s = "广播：禽兽" .. tostring(playerId);
    local s2
    if v == 1 then
        s2 = "向左移动啦";
    elseif v == 2 then
        s2 = "向右移动啦";
    elseif v == 3 then
        s2 = "向上移动啦";
    elseif v == 4 then
        s2 = "向下移动啦";
    end
    Debug.Log(s .. s2);
end

function GameMain.ReceiveCastSpellHandle(data)
    local playerId = tonumber(data.intList[1]);
    local v = tonumber(data.intList[2]);
    local s = "广播：禽兽" .. tostring(playerId);
    Debug.Log(s .. "放了大招" .. tostring(v));
end

function GameMain.ReceiveBattleEndHandle(data)
    Debug.LogWarning("战斗结束: " .. data.stringList[1]);
end



return GameMain


----
--
