DataUIInstance = {}  																	--数据层 逻辑层 调用UI层 都走这边 方便查询
DataUIInstance.CreateBattleUIOn = false																																																																										--生成黑色界面 暂时用这个先z
function DataUIInstance.OpenBlackPanel(pause , type)									--pause 表示 0不暂停 1暂停
																						--type 切屏方式  -1无方式 >=1 表示切屏方式
	if MainGameUI["target"]["BlackPanel"]==nil then										--把切屏对象放入界面管理器z
		local lua = GameMain.requireLuaFile("BlackPanel")
		local obj1 = lua:new()
	   	MainGameUI["target"]["BlackPanel"] = obj1
	end
	MainGameUI["target"]["BlackPanel"]:OpenBlackPanel(pause , type)	
	
end


function DataUIInstance.JudgeUIEvent()													--检测UI射线是否点到
	local nowState = GameMain.GetGameState()
	if nowState=="battle" then
		local BattleUICamera = MainGameUI.GetUICameraInBattle()								--检测点击的UI按钮是否绑定事件z	
		if BattleUICamera~=nil then
			--if BattleUICamera.hoveredObject~=nil then
			    --if lgNoDelCsFun.Ins:CheckObjIsNull(BattleUICamera.hoveredObject)==false then                
				    local UIevent = nil
				    UIevent = lgNoDelCsFun.Ins:GetHoveredObject()	
				    if UIevent~=nil then
					    return true
				    end
			   -- end
            --end
		end
	end
	if nowState~="battle" then
		local MainCityUICamera = MainGameUI.GetUICameraInMainCity()
		if MainCityUICamera~=nil then
			--if MainCityUICamera.hoveredObject~=nil then
			    --if lgNoDelCsFun.Ins:CheckObjIsNull(MainCityUICamera.hoveredObject)==false then	
				    local UIevent = nil
				    UIevent = lgNoDelCsFun.Ins:GetHoveredObject()	
	
				    if UIevent~=nil then
					    return true
				    end
			    --end
            --end
		end 
	end
	
	return false
	
end


--创建界面

function DataUIInstance.CreateControlUI(CB)		--UI总控制
    if CB==nil then
	   MainGameUI.OpenOnePanel("UIControl" , "UIControl" , "UIControl" , nil , DataUIInstance.ReflashPlayInfo)
    else
       MainGameUI.OpenOnePanel("UIControl" , "UIControl" , "UIControl" , nil , CB)
    end
end

function DataUIInstance.ReflashPlayInfo()
    local data =                                                   --刷新账号信息
     {  
        Name = ClinetInfomation.PlayerName,
        Lvl = ClinetInfomation.Lvl,
        Coin = ClinetInfomation.Coin,
        Diamond = ClinetInfomation.Diamond,
        Sta = ClinetInfomation.Sta,
        Energy = ClinetInfomation.Energy,
        Vip = ClinetInfomation.VipLevel,
     }
     local ControlTar = MainGameUI.FindPanelTarget("UIControl")
     if ControlTar~=nil then
        ControlTar:SetLeftTopPlayerInfo(data)
     end
end

function DataUIInstance.CreateLoginUI(CB)		--创建注册界面
	local _father =  MainGameUI.FindPanel("UIControl")	
	MainGameUI.OpenOnePanel("UILogin" , "UILogin" , "UILogin" , _father , CB , nil)
end

function DataUIInstance.CreateCreatePlayerUI()	--创建创角界面
	local _father =  MainGameUI.FindPanel("UIControl")	
	MainGameUI.OpenOnePanel("UICreatePlayer" , "UICreatePlayer" , "UICreatePlayer" , _father)
end

function DataUIInstance.OpenPVPPanel()		--创建PVP界面
	local _father =  MainGameUI.FindPanel("UIControl")	
	MainGameUI.OpenOnePanel("UIPVP" , "UIPVP" , "UIPVP" , _father)
end

function DataUIInstance.OpenPVEPanel()		--创建PVE界面
	local _father =  MainGameUI.FindPanel("UIControl")	
	MainGameUI.OpenOnePanel("UIPVE" , "UIPVE" , "UIPVE" , _father)
end

function DataUIInstance.OpenBabyPack()		--创建宝宝背包界面
	local _father =  MainGameUI.FindPanel("UIControl")	
	MainGameUI.OpenOnePanel("UIBabyPackage" , "UIBabyPackage" , "UIBabyPackage" , _father)
end

function DataUIInstance.OpenItemPack()		--创建道具背包界面
	local _father =  MainGameUI.FindPanel("UIControl")	
	MainGameUI.OpenOnePanel("UIItemPackage" , "UIItemPackage" , "UIItemPackage" , _father)
end

function DataUIInstance.OpenItemFactory()  --创建宝宝背包界面
	local _father =  MainGameUI.FindPanel("UIControl")	
	MainGameUI.OpenOnePanel("UIItemFactory" , "UIItemFactory" , "UIItemFactory" , _father)
end

function DataUIInstance.OpenMap()		    --创建副本界面
	local _father =  MainGameUI.FindPanel("UIControl")	
	MainGameUI.OpenOnePanel("UIMap" , "UIMap" , "UIMap" , _father)
end

function DataUIInstance.OpenMaster()                                        --大师
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIMaster" , "UIMaster" , "UIMaster" , _father)
end

function DataUIInstance.OpenSummon()                                        --召唤
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UISummon" , "UISummon" , "UISummon" , _father)
end

function DataUIInstance.OpenMail()                                          --邮件
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIMail" , "UIMail" , "UIMail" , _father)
end

function DataUIInstance.OpenArena()                                         --竞技场                           
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIArena" , "UIArena" , "UIArena" , _father) 
end

function DataUIInstance.OpenDailyBoss()                                     --天天boss
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIDailyBoss" , "UIDailyBoss" , "UIDailyBoss" , _father) 
end

function DataUIInstance.OpenFriend()                                        --好友
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIFriend" , "UIFriend" , "UIFriend" , _father) 
end

function DataUIInstance.OpenSign()                                      --签到
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UISign" , "UISign" , "UISign" , _father) 
end

function DataUIInstance.OpenShop()                                          --商城
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIShop" , "UIShop" , "UIShop" , _father) 
end

function DataUIInstance.OpenActivity()                                      --活动界面
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIActivity" , "UIActivity" , "UIActivity" , _father) 
end

function DataUIInstance.OpenPlayerSkill()                                     --主角技能
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIPlayerSkill" , "UIPlayerSkill" , "UIPlayerSkill" , _father) 
end

function DataUIInstance.OpenRankList()                                         --打开排行界面
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIRankList" , "UIRankList" , "UIRankList" , _father) 
end

function DataUIInstance.OpenPlayerGrow()                                         --主线
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIPlayerGrow" , "UIPlayerGrow" , "UIPlayerGrow" , _father) 
end

function DataUIInstance.OpenGameSys()                                          --游戏设置
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIGameSys" , "UIGameSys" , "UIGameSys" , _father) 
end

function DataUIInstance.OpenChatSys()
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIChat" , "UIChat" , "UIChat" , _father) 
end

function DataUIInstance.OpenFirstRecharge()                                   --打开首冲界面
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIFirstRecharge" , "UIFirstRecharge" , "UIFirstRecharge" , _father) 
end

function DataUIInstance.OpenWorldPlayerShow(_WorldPlayer)                      --展示世界玩家
   local _father =  MainGameUI.FindPanel("UIControl")	
   MainGameUI.OpenOnePanel("UIWorldPlayerShow" , "UIWorldPlayerShow" , "UIWorldPlayerShow" , _father , DataUIInstance.WorldPlayerShow ,_WorldPlayer) 
end

function DataUIInstance.WorldPlayerShow(WorldPlayer)
   local UIWorldPlayerShowTar = MainGameUI.FindPanelTarget("UIWorldPlayerShow")
   UIWorldPlayerShowTar:SetWorldPlayer(WorldPlayer)
end

function DataUIInstance.PopTip(_MsgID , _NowY , _TarY)                                            --弹提示
   local UIPopPanelTar = MainGameUI.FindPanelTarget("UIPopPanel")
   local data = 
   {
      MsgID = _MsgID,
      NowY = _NowY,
      TarY = _TarY,
   }	
   if UIPopPanelTar==nil then
      local _father =  MainGameUI.FindPanel("UIControl")     
      MainGameUI.OpenOnePanel("UIPopPanel" , "UIPopPanel" , "UIPopPanel" , _father , DataUIInstance.PopTipCallBack ,data)
   else
      local _Msg = UIstring[data.MsgID]
      if _Msg==nil then
         UIPopPanelTar:PopTip(data.MsgID , data.NowY , data.TarY)
      else
         UIPopPanelTar:PopTip(_Msg , data.NowY , data.TarY)
      end
      
   end
end

function DataUIInstance.PopTipCallBack(data)
   local UIPopPanelTar = MainGameUI.FindPanelTarget("UIPopPanel")
   if UIPopPanelTar~=nil then
      local _Msg = UIstring[data.MsgID]
      if _Msg==nil then
         UIPopPanelTar:PopTip(data.MsgID , data.NowY , data.TarY)
      else
         UIPopPanelTar:PopTip(_Msg , data.NowY , data.TarY)
      end
   end
end

function DataUIInstance.PopProp(_PropList)
   local UIPopPanelTar = MainGameUI.FindPanelTarget("UIPopPanel")
   if UIPopPanelTar==nil then
      local _father =  MainGameUI.FindPanel("UIControl")     
      MainGameUI.OpenOnePanel("UIPopPanel" , "UIPopPanel" , "UIPopPanel" , _father , DataUIInstance.PopPropCallBack ,_PropList)
   else   
      UIPopPanelTar:StartPopProp(_PropList)     
   end
end

function DataUIInstance.PopPropCallBack(_PropList)
   local UIPopPanelTar = MainGameUI.FindPanelTarget("UIPopPanel")
   if UIPopPanelTar~=nil then
      UIPopPanelTar:StartPopProp(_PropList)
   end
end


function DataUIInstance.PopTipPanel(_Type , _CallBack , _Data)                                       --弹板参数类型  , 回调函数 , 数据 ,弹提示面板 
   local data = 
   {
      Type = _Type,
      Data = _Data,
      CallBack = _CallBack,
   }

   local UIPopPanelTar = MainGameUI.FindPanelTarget("UIPopPanel")
   if UIPopPanelTar==nil then
      local _father =  MainGameUI.FindPanel("UIControl")
      if _father~=nil then
         MainGameUI.OpenOnePanel("UIPopPanel" , "UIPopPanel" , "UIPopPanel" , _father , DataUIInstance.PopTipPanelCallBack ,data)
      else
         local father = MainGameUI.FindPanel("UIBattle")
         if father~=nil then
            MainGameUI.OpenOnePanel("UIPopPanel" , "UIPopPanel" , "UIPopPanel" , father , DataUIInstance.PopTipPanelCallBack ,data)
         else
            MainGameUI.OpenOnePanel("UIPopPanel" , "UIPopPanel" , "UIPopPanel" , nil , DataUIInstance.PopTipPanelCallBack ,data)
         end
      end
   else
      UIPopPanelTar:PopTipPanel(data)
   end
end

function DataUIInstance.PopTipPanelCallBack(_Data)
   local UIPopPanelTar = MainGameUI.FindPanelTarget("UIPopPanel")
   if UIPopPanelTar~=nil then
      UIPopPanelTar:PopTipPanel(_Data)
   end
end

return DataUIInstance