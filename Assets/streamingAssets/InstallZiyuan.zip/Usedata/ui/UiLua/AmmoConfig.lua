AmmoConfig = {}
AmmoConfig.AmmoConfig = {}
function AmmoConfig.IniSome()

	local theDB = configDB.Ins.theDB;
	local sqReader = theDB:ReadFullTable("Ammo")
    AmmoConfig.Number = 1
	while (sqReader:Read() ~= false) 
	do
      
        AmmoConfig.AmmoConfig[AmmoConfig.Number] = {        
            Id = sqReader:GetInt32(0),                        --ID                 
            PrefabName = sqReader:GetString(1),                 --�ȼ�modify     
            LogicName = sqReader:GetString(2),                 --
            Param = sqReader:GetString(3),                 --
            Description =  sqReader:GetString(4),     
		}
        AmmoConfig.Number = AmmoConfig.Number + 1
    end
end

function AmmoConfig.GetAmmoById(_Id)
    
    for i = 1 , #AmmoConfig.AmmoConfig  ,1 do
        if AmmoConfig.AmmoConfig[i].Id == _Id then
           return AmmoConfig.AmmoConfig[i]
        end
    end 
    return nil
end

function AmmoConfig.GetAmmoData()
    
    return AmmoConfig.AmmoConfig

end

return AmmoConfig