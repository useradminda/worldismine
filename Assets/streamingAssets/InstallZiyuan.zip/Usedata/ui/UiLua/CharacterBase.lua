
CharacterBase = {}                                                                      --世界地图角色控制类
local this = CharacterBase
CharacterBase.__index = CharacterBase

CharacterBase.Id = nil																	--玩家ID
CharacterBase.name = nil																--玩家名字

CharacterBase.PlayerObj = nil															--玩家模型GOb
CharacterBase.PlayerTrans = nil
CharacterBase.NameMeshTrans = nil
CharacterBase.NameText = nil                                                            --玩家姓名的mesh

CharacterBase.World_Id = 0                                                             --世界ID
CharacterBase.PlayerName = ""
CharacterBase.PlayerRealId = 0

CharacterBase.OwnerShip = 1                                                             --归属国

CharacterBase.MoveState = "Idle"                                                      --玩家状态  Idle 停止在城市 Move移动在路上 Fight 在城池中战斗 Watch 在城池中观看
CharacterBase.MoveStates = {"Idle" , "Move" , "Fight" , "Watch"}
CharacterBase.MoveTimeCD = 9                                                          --移动CD
CharacterBase.IdleTime = 0                                                         --停留时间CD
CharacterBase.MoveCDState = false                                                     --是否可以移动
CharacterBase.nowIdleTime = 0                                                       --当前停留状态时间

CharacterBase.NowNode = nil                                                           --当前点
CharacterBase.LastNode = nil                                                          --上一个点
CharacterBase.StartNode = nil                                                         --开始寻路点
CharacterBase.EndNode = nil                                                           --终点

CharacterBase.Starpos = nil
CharacterBase.Temppos = nil

CharacterBase.nowTime = 0                   
CharacterBase.MoveTime = 3                                                    
CharacterBase.StartMoveState = false
CharacterBase.NextMoveNode = nil
CharacterBase.NextMoveNodeId = 0
CharacterBase.SaveNodes = nil

CharacterBase.tempEndNode = nil                                                        --当前移动状态的临时终点

CharacterBase.GoInCity = false                                                          --进入城池

CharacterBase.NetMoveEventCome = false                                                  --移动变更

function  CharacterBase:new(o)
    o=o or {}
    setmetatable(o,self)
    self.__index = self
    return o
end

function CharacterBase:CreatePlayer(_WorldId , _PlayerName , _ModelName)
    
   self.World_Id = _WorldId
   self.NetMoveEventCome = false
   self.MoveTimeCD = 9

   local data =
   {
      Charc = self,
    --  NowNode = _NowNode,
   }

   WorldMapSys.LoadAssetByObject(data , "my" , CharacterBase.InitSomeCallback)
	
end

function CharacterBase.InitSomeCallback(_data , _prefab)              
   local Gob = GameObject.Instantiate(_prefab,Vector3.zero,Quaternion.identity)
   _data.Charc.PlayerObj = Gob
   _data.Charc.PlayerTrans = Gob.transform
   _data.Charc.PlayerTrans.localScale = Vector3(100 , 100 , 100)
   _data.Charc.PlayerTrans.localPosition = Vector3(10000 , 10000 , 10000)
   _data.Charc.PlayerTrans.localEulerAngles = Vector3(90 , 0 , 0)
   _data.Charc.NameMeshTrans = _data.Charc.PlayerTrans:FindChild("Name")
   _data.Charc.NameText = _data.Charc.NameMeshTrans:GetComponent("TextMesh")
   _data.Charc.NameText.text = tostring(_data.Charc.World_Id)

  -- _data.Charc.NowNode = _data.NowNode
  -- _data.Charc.PlayerTrans.localPosition = _data.NowNode.Pos
  -- _data.Charc.MoveState = "Idle"
                                                                          --移动CD时间
end

function CharacterBase:SetOwner(_OwnerShip)
   self.OwnerShip = _OwnerShip
   if self.OwnerShip==1 then           --蜀国
      lgNoDelCsFun.Ins:SetNameMeshColor(self.NameText , 255/255 , 0/255 , 0/255) 
   elseif self.OwnerShip==2 then       --魏国
      lgNoDelCsFun.Ins:SetNameMeshColor(self.NameText , 0/255 , 245/255 , 255/255)
   elseif self.OwnerShip==3 then       --吴国
      lgNoDelCsFun.Ins:SetNameMeshColor(self.NameText , 30/255 , 255/255 , 0/255)
   elseif self.OwnerShip==4 then       --中立
      lgNoDelCsFun.Ins:SetNameMeshColor(self.NameText , 255/255 , 0/255 , 227/255)
   end
end

function CharacterBase:SetNodeInfo(_Node)
   self.NowNode = _Node
   self:SetMyMapCityPosition(self.NowNode.Pos) 
end

function CharacterBase:SetPos(_Pos)
   self.PlayerTrans.localPosition = _Pos
end

function CharacterBase:SetMoveState(_MoveState)
   self.MoveState = _MoveState
end

function CharacterBase:InitMoveState()
   self.StartMoveState = false
   self.GoInCity = false 
   self:ShowMeInWorldMap(false)
end

function CharacterBase:ShowMeInWorldMap(_Show)
   if self.World_Id~=PlayerControl.WorldId then
      self.PlayerObj.gameObject:SetActive(_Show)
   end 
end

function CharacterBase:SetMyMapCityPosition()
   
   if self.World_Id==PlayerControl.WorldId then 
      PlayerControl.MyMapCityTrans.localPosition = Vector3((self.NowNode.Pos.x/8) + 1892 , -100 , (self.NowNode.Pos.z/8) + 882)
   end
end

function CharacterBase:SetPlayerTrun(_LastNodeX , _NextNodeX)
   local TurnX = _LastNodeX - _NextNodeX
   if self.NameMeshTrans~=nil then
      if TurnX > 0 then
         self.NameMeshTrans.localEulerAngles = Vector3(0 , 180 , 0)
         self.PlayerTrans.localEulerAngles = Vector3(-90 , 180 , 0)
      elseif TurnX < 0 then
         self.NameMeshTrans.localEulerAngles = Vector3(0 , 0 , 0)
         self.PlayerTrans.localEulerAngles = Vector3(90 , 0 , 0)
      end
   end
end

function CharacterBase:StartMove()
   if self.MoveState=="Idle" and self.SaveNodes~=nil and #self.SaveNodes~=0 then                                                                           --开始移动      
       self.NextMoveNode = self.SaveNodes[2]
       self.NextMoveNodeId = 2
       self.Temppos = Vector3(0 , 0 ,0)
       self.Starpos = Vector3(self.PlayerTrans.localPosition.x , 0 ,self.PlayerTrans.localPosition.z)
       self.MoveState = "Move"                                                                          --移动状态
       self.MoveTime = self.NowNode.NeighbourPassTime[tostring(self.NowNode.NodeId).."_"..tostring(self.NextMoveNode.NodeId)]   --城池之间的移动时间    
       self:SetPlayerTrun(self.NowNode.Pos.x , self.NextMoveNode.Pos.x)                                                                              
       self.NowNode = self.NextMoveNode
       self:SetMyMapCityPosition(self.NowNode.Pos) 
       self.LastNode = self.SaveNodes[1]
       self.nowTime = 0                                                                                   --当前移动过程中的当前时间
       self.MoveTimeCD = 9                                                                               --移动CD总时间
       self.IdleTime = self.MoveTimeCD - self.MoveTime
       self.nowIdleTime = 0
       self.GoInCity = false
       self:ShowMeInWorldMap(true)
       self.StartMoveState = true     
   end
end

function CharacterBase:ClearStarData()
   self.EndNode = nil
   self.NextMoveNode = nil
   self.tempEndNode = nil
   self.Temppos = Vector3(0 , 0 ,0)
   self.NextMoveNodeId = 2
end

function CharacterBase:GoInCityEvent()                                 --进城设置点信息
    self.GoInCity = true                                               --进入城池状态
    self:ShowMeInWorldMap(false)
end

function CharacterBase:OutCitySetNodeEvent()
   if self.World_Id==PlayerControl.WorldId then
      if self.tempEndNode~=nil  then      
         WorldMapSocketSys.SendMoveSocketEvent(self.SaveNodes)              
      else
         self:OutCitySetNode()
      end
   else
      --if self.NetMoveEventCome==false then
      self:OutCitySetNode()
      --end
   end
end

function CharacterBase:OutCitySetNode()                                --出城设置点信息
    self.NextMoveNodeId = self.NextMoveNodeId + 1
    --GameMain.Print(self.SaveNodes[self.NextMoveNodeId])
    if self.SaveNodes[self.NextMoveNodeId]~=nil then                   --非终点
       self.NextMoveNode = self.SaveNodes[self.NextMoveNodeId]
       self.MoveTime = self.NowNode.NeighbourPassTime[tostring(self.NowNode.NodeId).."_"..tostring(self.NextMoveNode.NodeId)]   --城池之间的移动时间      
       self.Starpos = self.PlayerTrans.localPosition  
       if self.World_Id==PlayerControl.WorldId then                    --玩家操作  
          if self.tempEndNode~=nil  then
             self:GetTempEndNode()
          end     
       end
       self:SetPlayerTrun(self.NowNode.Pos.x , self.NextMoveNode.Pos.x)
       self.IdleTime = self.MoveTimeCD - self.MoveTime       
       self.NowNode = self.SaveNodes[self.NextMoveNodeId]
       self.LastNode = self.SaveNodes[self.NextMoveNodeId - 1]  
       self:SetMyMapCityPosition(self.NowNode.Pos) 
       self:ShowMeInWorldMap(true)   
    else                                                               --终点
       if self.World_Id==PlayerControl.WorldId then                    --玩家操作  
           if self.tempEndNode~=nil then
              if self.tempEndNode==self.NowNode then
                 self.StartMoveState = false
                 self:ClearStarData()     
                 self.MoveState = "Idle"
              else
                  self:GetTempEndNode()  
                  self:SetPlayerTrun(self.NowNode.Pos.x , self.NextMoveNode.Pos.x)             
                  self.NowNode = self.SaveNodes[self.NextMoveNodeId]
                  self.LastNode = self.SaveNodes[self.NextMoveNodeId - 1]  
                  self:SetMyMapCityPosition(self.NowNode.Pos)
                  self:ShowMeInWorldMap(true)   
              end           
           else
              self.StartMoveState = false
              self:ClearStarData()     
              self.MoveState = "Idle"
           end
        else
           if self.NetMoveEventCome==true then

           else
              self.StartMoveState = false
              self:ClearStarData()     
              self.MoveState = "Idle"
           end
        end
    end
    self.GoInCity = false
end

function CharacterBase:GetTempEndNode()                                 --移动的时候尝试获取临时设置的终点  
    self.NextMoveNode = self.SaveNodes[2]
    self.NextMoveNodeId = 2
    self.Temppos = Vector3(0 , 0 ,0)
    self.Starpos = Vector3(self.PlayerTrans.localPosition.x , 0 ,self.PlayerTrans.localPosition.z)
    self.tempEndNode = nil 

    self.MoveTime = self.NowNode.NeighbourPassTime[tostring(self.NowNode.NodeId).."_"..tostring(self.NextMoveNode.NodeId)]
    self.IdleTime = self.MoveTimeCD - self.MoveTime
    
end


function CharacterBase:SendNetEvent(_SaveNodes)
   if self.MoveState=="Idle" then          
      self.SaveNodes = {}
      self.SaveNodes = _SaveNodes
      self:StartMove()
   elseif self.MoveState=="Move" then
      if self.World_Id==PlayerControl.WorldId then
         self.SaveNodes = {}
         self.SaveNodes = _SaveNodes
         self:OutCitySetNode()
      else                                                                                                 --其他玩家 新包来就按照新包走
         self.SaveNodes = {}
         self.SaveNodes = _SaveNodes
         --self.NetMoveEventCome = true
         
         self.NowNode = self.SaveNodes[1]                                                                    
         self.NextMoveNode = self.SaveNodes[2]                                                              --开始移动   
         self.NextMoveNodeId = 2
         self.Temppos = Vector3(0 , 0 ,0)
         self.Starpos = Vector3(self.SaveNodes[1].Pos.x , 0 ,self.SaveNodes[1].Pos.z)
         --self.MoveState = "Move"                                                                          --移动状态
         self.MoveTime = self.NowNode.NeighbourPassTime[tostring(self.NowNode.NodeId).."_"..tostring(self.NextMoveNode.NodeId)]   --城池之间的移动时间
         self:SetPlayerTrun(self.NowNode.Pos.x , self.NextMoveNode.Pos.x)                                                                                     
         self.NowNode = self.SaveNodes[2]
         self.LastNode = self.SaveNodes[1] 
         self.nowTime = 0                                                                                   --当前移动过程中的当前时间
         self.MoveTimeCD = 9                                                                                --移动CD总时间
         self.IdleTime = self.MoveTimeCD - self.MoveTime
         self.nowIdleTime = 0
         self.GoInCity = false
         self.StartMoveState = true 
         self:ShowMeInWorldMap(true)
       --  self:OutCitySetNode()       
      end
      
   end
end

function CharacterBase:SendNetEventTempTime(_SaveNodes , _TempTime)
   --Debug.LogError(_TempTime/self.MoveTimeCD)
   self.MoveState = "Move" 
   self.SaveNodes = _SaveNodes
   local NodeNum = math.floor(_TempTime/self.MoveTimeCD)                           --向下取整

   local lastNode = self.SaveNodes[NodeNum + 1]   
   self.NextMoveNode = self.SaveNodes[NodeNum + 2]
   self.NextMoveNodeId = NodeNum + 2
   self.MoveTime = lastNode.NeighbourPassTime[tostring(lastNode.NodeId).."_"..tostring(self.NextMoveNode.NodeId)]   --城池之间的移动时间         
   self.NowNode = _SaveNodes[NodeNum + 2]
   self.LastNode =  lastNode
   self:SetMyMapCityPosition(self.NowNode.Pos) 

   local tempMoveTime = _TempTime - self.MoveTimeCD*NodeNum                         --出上一个城池路上的时间
   if tempMoveTime <= self.MoveTime then                                            --在城池的路上
      self.Starpos = Vector3(lastNode.Pos.x , 0 , lastNode.Pos.z)
      self.Temppos = Vector3(0 , 0 ,0)                                                                
      self.nowTime = tempMoveTime                                                  --当前移动过程中的当前时间

      GameMain.Print(self.MoveTime , "MoveTime")
      GameMain.Print(self.nowTime , "nowTime")

      local beilv = self.nowTime/self.MoveTime
      local x = Mathf.Lerp(self.Starpos.x , self.NextMoveNode.Pos.x , beilv)
      local z = Mathf.Lerp(self.Starpos.z , self.NextMoveNode.Pos.z , beilv)
      self.PlayerTrans.localPosition = Vector3(x , 0 , z)
      self.IdleTime = self.MoveTimeCD - self.MoveTime
      self.nowIdleTime = 0
      self.GoInCity = false                                                         --不在城池里
      self.StartMoveState = true
      self:ShowMeInWorldMap(true)
   else                                                                             --已经入城     
      self.PlayerTrans.localPosition = Vector3(self.NowNode.Pos.x , 0 , self.NowNode.Pos.z)
      self.Starpos = Vector3(self.NowNode.Pos.x , 0 , self.NowNode.Pos.z)
      self.Temppos = Vector3(0 , 0 ,0)
      self.nowTime = 0
      self.IdleTime = self.MoveTimeCD - self.MoveTime
      self.nowIdleTime = tempMoveTime - self.MoveTime
      self.GoInCity = true                                                          --在城池里
      self.StartMoveState = true
      self:ShowMeInWorldMap(false)
   end
   

end 

function CharacterBase:SetNewPath()
   self.NextMoveNode = self.SaveNodes[2]
   self.NextMoveNodeId = 2
   self.Temppos = Vector3(0 , 0 ,0)
   self.Starpos = Vector3(self.PlayerTrans.localPosition.x , 0 ,self.PlayerTrans.localPosition.z)
   self.MoveTime = self.NowNode.NeighbourPassTime[tostring(self.NowNode.NodeId).."_"..tostring(self.NextMoveNode.NodeId)]
   self.IdleTime = self.MoveTimeCD - self.MoveTime
   self.NetMoveEventCome = false
end

function CharacterBase:Update(dt)
  
       if self.StartMoveState==true then
          if self.GoInCity ==false then
              self.nowTime = self.nowTime + dt  
              if  self.nowTime <= self.MoveTime then
                 local beilv = self.nowTime/self.MoveTime
                 self.Temppos.x = Mathf.Lerp(self.Starpos.x , self.NextMoveNode.Pos.x , beilv)
	             self.Temppos.z = Mathf.Lerp(self.Starpos.z , self.NextMoveNode.Pos.z , beilv)
                 self.PlayerTrans.localPosition = self.Temppos           
              else                                      
                 self.nowTime = 0
                 self:GoInCityEvent()
              end
          end

          if self.GoInCity==true then
             self.nowIdleTime = self.nowIdleTime + dt
             if self.nowIdleTime <= self.IdleTime then 

             else
                --self:OutCitySetNode()
                self:OutCitySetNodeEvent()
                self.nowIdleTime = 0              
                
             end 
          end
       end

end

function CharacterBase:GetMoveNodes(_EndNode)

   self.StartNode = self.NowNode
   self.EndNode = _EndNode
   local Nodes = WorldMapSys.AstarBegin(self.StartNode , self.EndNode)
   if Nodes==nil then
      return nil
   end

   if Nodes~=nil then     
      return Nodes
   end 

end

function CharacterBase:SetEndNode(_EndNode)
   if self.MoveState=="Move" then                                                              --移动状态终点存入临时终点 
      
      if self.tempEndNode~=nil and self.tempEndNode.NodeId == _EndNode.NodeId then
         Debug.LogError("请等待走完") 
         return
      end         
       
      if self.EndNode~=nil and self.EndNode.NodeId == _EndNode.NodeId then
         Debug.LogError("开始点和终点是一个点 不移动")                                            
         return
      end     
          
      local Nodes = self:GetMoveNodes(_EndNode)
      if Nodes~=nil then
         self.tempEndNode = _EndNode
         self.SaveNodes = Nodes
         Debug.LogError("新的终点")
      else
         Debug.LogError("No Path")
         return 
      end
                                          
   elseif self.MoveState=="Idle" then                                                          --玩家从站立开始移动
      self.SaveNodes = {}
      if self.NowNode~=nil and self.NowNode.NodeId == _EndNode.NodeId then
         Debug.LogError("开始点和终点是一个点 不移动")                                            
         return
      end 

      Debug.LogError("重新开始移动")           
      local Nodes = self:GetMoveNodes(_EndNode)
      if Nodes~=nil then
         self.SaveNodes = Nodes
         Debug.LogError("新的终点")
      else
         Debug.LogError("No Path")
         return 
      end
      WorldMapSocketSys.SendMoveSocketEvent(self.SaveNodes)
   end

end



return CharacterBase