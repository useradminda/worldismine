﻿BuffConfig = {}
BuffConfig.BuffConfig = {}
function BuffConfig.IniSome()

	local theDB = configDB.Ins.theDB;
	local sqReader = theDB:ReadFullTable("Buff")
	while (sqReader:Read() ~= false) 
	do
        local _Id = sqReader:GetInt32(0)
        BuffConfig.BuffConfig[_Id] = {        
            Id = sqReader:GetInt32(0),                        --ID          
            Type = sqReader:GetInt32(1),                     --名字  
            PropertyId = sqReader:GetInt32(2),                  --名字  
            LvlModify = sqReader:GetString(3),                 --等级modify     
            SpellModify = sqReader:GetString(4),                 --
            SustainTime = sqReader:GetFloat(5),                 --
            Description =  sqReader:GetString(6),     
		}     
    end
end

function BuffConfig.GetBuffById(_Id)
    
    if BuffConfig.BuffConfig[tonumber(_Id)]~=nil then
       return BuffConfig.BuffConfig[tonumber(_Id)]
    end
    Debug.LogError("数据库Buff配置错误id:")
    Debug.LogError(_Id)
    return nil
end

function BuffConfig.GetBuffData()
    
    return BuffConfig.BuffConfig

end

return BuffConfig