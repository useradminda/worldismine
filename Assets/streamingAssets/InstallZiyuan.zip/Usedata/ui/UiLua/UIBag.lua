--背包界面  后续将使用界面和出售界面分离开
UIBag = {}
local UIBag = BasePanel:new()
local this = UIBag
UIBag.UIBagGod = nil

UIBag.TabPage=nil --标签页
UIBag.Grid=nil --存放道具列表的父物体
UIBag.ItemList={} --存放物品列表的数组（key,item）

UIBag.ItemClick=nil --点击的那个物品

UIBag.SwitchBtns=
{
	daoju=nil,
	libao=nil,
	zhuangbei=nil,
	suipian=nil,
	shizhuang=nil,
}

UIBag.ItemInfoPanel={}
UIBag.ItemSellAndUsePanel={}


function UIBag:OpenUI(_PanelName , _LuaName)
	UIBag.UIBagGod=MainGameUI.FindPanel("UIBag")
	UIBag.Grid=UIBag.UIBagGod.transform:FindChild("right"):FindChild("scrollView"):FindChild("Grid"):GetComponent("UIGrid")

	UIBag.UIBagUseItemPanel=UIBag.UIBagGod.transform:FindChild("UIBagItemUsePanel")


	this:GetSwitchBtns()
	this:GetItemInfoPanel()
	this:GetItemSellAndUsePanel()
	this:UpDateInfo()
	this:showItemOpenInfoPanel()
end

function UIBag:showItemOpenInfoPanel()
	for i=1,#ItemPackageSys.ItemList,1  do
		if ItemPackageSys.ItemList[i]~=nil and ItemPackageSys.ItemList[i].Useable==1 then
			this:showItemInfoPanel(i)
		return
		end
	end
end

function UIBag:GetItemInfoPanel()
	local left=UIBag.UIBagGod.transform:FindChild("left")
	UIBag.ItemInfoPanel.border=left.transform:FindChild("item"):FindChild("BG"):GetComponent("UISprite")--品质框
	UIBag.ItemInfoPanel.icon=left.transform:FindChild("item"):FindChild("Img"):GetComponent("UISprite")
	UIBag.ItemInfoPanel.name=left.transform:FindChild("item"):FindChild("LabelName"):GetComponent("UILabel")--名称
	UIBag.ItemInfoPanel.labelInfo=left.transform:FindChild("item"):FindChild("Labelinfo"):GetComponent("UILabel")--相关说明
	UIBag.ItemInfoPanel.des=left.transform:FindChild("infoPanel"):FindChild("infodes"):GetComponent("UILabel")
end


function UIBag:GetItemSellAndUsePanel()
	local useSellPanel=UIBag.UIBagGod.transform:FindChild("left"):FindChild("UseSellPanel")
	UIBag.ItemSellAndUsePanel.des=useSellPanel.transform:FindChild("des"):GetComponent("UILabel")
	UIBag.ItemSellAndUsePanel.SellPrice=useSellPanel.transform:FindChild("jinbi"):FindChild("Label"):GetComponent("UILabel")
	UIBag.ItemSellAndUsePanel.OnlySellBtn=useSellPanel.transform:FindChild("OnlySellBtn")
	UIBag.ItemSellAndUsePanel.SellAndUse=useSellPanel.transform:FindChild("sellAndUse")
	UIBag.ItemSellAndUsePanel.OnlyUseBtn=useSellPanel.transform:FindChild("OnlyUseBtn")
end
function UIBag:GetSwitchBtns()
	local _switchBtnsList=UIBag.UIBagGod.transform:FindChild("right")
	UIBag.SwitchBtns.daoju=_switchBtnsList:FindChild("daojuBtn"):FindChild("BG"):GetComponent("UISprite")
	UIBag.SwitchBtns.libao=_switchBtnsList:FindChild("libaoBtn"):FindChild("BG"):GetComponent("UISprite")
	UIBag.SwitchBtns.zhuangbei=_switchBtnsList:FindChild("zhuangbeiBtn"):FindChild("BG"):GetComponent("UISprite")
	UIBag.SwitchBtns.suipian=_switchBtnsList:FindChild("suipianBtn"):FindChild("BG"):GetComponent("UISprite")
	UIBag.SwitchBtns.shizhuang=_switchBtnsList:FindChild("shizhuangBtn"):FindChild("BG"):GetComponent("UISprite")

	this:ClearBtnsState(UIBag.SwitchBtns.daoju)
end

function UIBag:UpDateInfo()--每切换一次都要更新显示

	if UIBag.TabPage==UIBag.SwitchBtns.daoju then
		this:ShowDaoJuPanel()
		this:showItemOpenInfoPanel()
	end
	if UIBag.TabPage==UIBag.SwitchBtns.libao then
		this:ClearPanel()
	end
	if UIBag.TabPage==UIBag.SwitchBtns.zhuangbei then
		this:ClearPanel()
	end
	if UIBag.TabPage==UIBag.SwitchBtns.suipian then
		this:ClearPanel()
	end
	if UIBag.TabPage==UIBag.SwitchBtns.shizhuang then
		this:ClearPanel()
	end
end

function UIBag:ClearPanel()	--其他数据没有，先暂时统一这样处理一下
	for key, value in pairs(UIBag.ItemList) do
		this:CloseItemPanel(UIBag.ItemSellAndUsePanel.des.transform.parent)
		this:CloseItemPanel(UIBag.ItemInfoPanel.des.transform.parent)
		this:CloseItemPanel(UIBag.ItemInfoPanel.icon.transform.parent)
		if value~=nil then
			value.itemContain.gameObject:SetActive(false)
			value.ItemData=nil
		end
	end


end

function UIBag:ShowDaoJuPanel()	--显示道具列表界面
--	GameMain.Print(ItemPackageSys.ItemList)
	table.sort(ItemPackageSys.ItemList,UIBag.Comp)
--	GameMain.Print(ItemPackageSys.ItemList)
	if UIBag.ItemList~=nil and (#UIBag.ItemList > #ItemPackageSys.ItemList )then
		local num=#UIBag.ItemList-#ItemPackageSys.ItemList
		for i=#ItemPackageSys.ItemList,num,1 do
			UIBag.ItemList[i].itemContain.gameObject:SetActive(false)
		end
	end
	if #ItemPackageSys.ItemList==0 then
		Debug.Log("没有道具")
		return
	end

	for i=1,#ItemPackageSys.ItemList,1 do
		if ItemPackageSys.ItemList[i]~=nil and tonumber(ItemPackageSys.ItemList[i].Useable)==1 then
			local data=
			{
				itemData=ItemPackageSys.ItemList[i],
				index=i,
			}
				if  UIBag.ItemList[i]~=nil and UIBag.ItemList[i].itemContain~=nil then
					this:CreateItemListCallBack(UIBag.ItemList[i].itemContain,data)
				else

					MainGameUI.CreateLittleItem(tostring(i) , "itemIcon" , UIBag.Grid.transform , data , this.CreateItemListCallBack , "UIBag")
				end

		end
	end
end


function UIBag:CreateItemListCallBack(_Gob , _Info)--创建物品列表并做信息显示

	if _Info.itemData.Useable==0 then
		_Gob.gameObject:SetActive(false)
		elseif _Info.itemData.Useable==1 then
		_Gob.gameObject:SetActive(true)
	end

    local numLabel=_Gob.transform:FindChild("count"):GetComponent("UILabel")
	local itemSprite=_Gob.transform:FindChild("Img"):GetComponent("UISprite")
	local itemBorder=_Gob.transform:FindChild("BG"):GetComponent("UISprite")

    if _Info.itemData.Count==0 then
       if numLabel.text~="" then
          numLabel.text = ""
       end
       Debug.Log(tostring( _Info.itemData.Id) .. "count is 0")
    else
       numLabel.text = tostring(_Info.itemData.Count)
    end

    AtlasMsg.SetAtlas(itemSprite , _Info.itemData.AtlasName , _Info.itemData.SpriteName)
    itemBorder.spriteName = UIstring.ItemFg[_Info.itemData.Quality]

    UIBag.ItemList[_Info.index] =
    {
        ItemData = _Info.itemData,
        itemContain = _Gob,
    }
end

function UIBag:UIHand(_LuaName , _Gob)
	if _Gob.name=="daojuBtn" then
		this:ClearBtnsState(UIBag.SwitchBtns.daoju)
		this:UpDateInfo()
	end

	if _Gob.name=="libaoBtn" then
		this:ClearBtnsState(UIBag.SwitchBtns.libao)
		this:UpDateInfo()
	end

	if _Gob.name=="zhuangbeiBtn" then
		this:ClearBtnsState(UIBag.SwitchBtns.zhuangbei)
		this:UpDateInfo()
	end
	if _Gob.name=="suipianBtn" then
		this:ClearBtnsState(UIBag.SwitchBtns.suipian)
		this:UpDateInfo()
	end
	if _Gob.name=="shizhuangBtn" then
		this:ClearBtnsState(UIBag.SwitchBtns.shizhuang)
		this:UpDateInfo()
	end

	if _Gob.name=="closeBtn" then
		this:ClosePanel()
	end

	local ItemKey = tonumber(_Gob.name)
       local ItemParentName = _Gob.transform.parent.name
       if ItemKey~=nil and ItemParentName=="Grid" then
           if ItemKey~=nil and UIBag.ItemList[ItemKey]~=nil then                       --点击背包里面的道具
                 this:showItemInfoPanel(ItemKey)
                 return
           end
     end

	if _Gob.name=="OnlyUseBtn" then
		this:OpenUIBagItemUsePanel()
	end

	if _Gob.name=="OnlySellBtn" then

	end

	if _Gob.name=="sellBtn" and _Gob.transform.parent.name=="sellAndUse" then

	end

	if _Gob.name=="useBtn" and _Gob.transform.parent.name=="sellAndUse" then

		this:OpenUIBagItemUsePanel()
	end
	--使用界面的点击事件，后续独立成一个panel
	if _Gob.name=="useBtn" and  _Gob.transform.parent.name=="UIBagItemUsePanel" then
		--使用界面的使用按钮点击

		this:UseItem()
	end

	if _Gob.name=="add" and  _Gob.transform.parent.name=="UIBagItemUsePanel" then
		this:UseItemCountChange(1)
	end
	if _Gob.name=="sub" and  _Gob.transform.parent.name=="UIBagItemUsePanel" then
		this:UseItemCountChange(-1)
	end
	if _Gob.name=="max" and  _Gob.transform.parent.name=="UIBagItemUsePanel" then
		if UIBag.ItemClick~=nil then
			this:UseItemCountChange(UIBag.ItemClick.ItemData.Count)
		end
	end
end
function UIBag:ClearBtnsState(_activeBtn)
	if UIBag.TabPage~=nil then
		AtlasMsg.SetAtlas(UIBag.TabPage,"UIBagAltas","yeqian")
	end
		UIBag.TabPage=_activeBtn
		AtlasMsg.SetAtlas(UIBag.TabPage,"UIBagAltas","yeqiantihuan")

end

function UIBag:showItemInfoPanel(id)--显示左侧的物品信息，根据Index来

	if UIBag.TabPage==UIBag.SwitchBtns.daoju then--道具标签
		local item=UIBag.ItemList[id]
		if item==nil then
			this:CloseItemPanel(UIBag.ItemInfoPanel.icon.transform.parent)
			this:CloseItemPanel(UIBag.ItemInfoPanel.des.transform.parent)
			this:CloseItemPanel(UIBag.ItemSellAndUsePanel.des.transform.parent)
			return
		end

		if UIBag.ItemClick~=nil then
			UIBag.ItemClick.itemContain.transform:FindChild("click").gameObject:SetActive(false)
		end

		item.itemContain.transform:FindChild("click").gameObject:SetActive(true)

		UIBag.ItemClick=item
	--基本的显示
		UIBag.ItemInfoPanel.name.text=tostring(item.ItemData.name)
		AtlasMsg.SetAtlas(UIBag.ItemInfoPanel.icon,item.ItemData.AtlasName,item.ItemData.SpriteName)
		UIBag.ItemInfoPanel.border.spriteName = UIstring.ItemFg[item.ItemData.Quality]
		UIBag.ItemInfoPanel.labelInfo.text="拥有"..tostring(item.ItemData.Count).."件"

		if item.ItemData.CanSell==1 and item.ItemData.IsUse==1 then --既可以出售也可以使用
			this:ShowItemUseAndSellPanel()
			UIBag.ItemSellAndUsePanel.SellPrice.text=tostring(item.ItemData.Price)
			UIBag.ItemSellAndUsePanel.des.text=tostring(item.ItemData.Description)
			this:ShowGameobj(UIBag.ItemSellAndUsePanel.SellAndUse,true)
			this:ShowGameobj(UIBag.ItemSellAndUsePanel.OnlySellBtn,false)
			this:ShowGameobj(UIBag.ItemSellAndUsePanel.OnlyUseBtn,false)
		end
		if item.ItemData.CanSell==0 and item.ItemData.IsUse==1 then	--只可以使用
			this:ShowItemUseAndSellPanel()
			UIBag.ItemSellAndUsePanel.SellPrice.text=tostring(item.ItemData.Price)
			UIBag.ItemSellAndUsePanel.des.text=tostring(item.ItemData.Description)
			this:ShowGameobj(UIBag.ItemSellAndUsePanel.SellAndUse,false)
			this:ShowGameobj(UIBag.ItemSellAndUsePanel.OnlySellBtn,false)
			this:ShowGameobj(UIBag.ItemSellAndUsePanel.OnlyUseBtn,true)
		end
		if item.ItemData.CanSell==1 and item.ItemData.IsUse==0 then --只可以出售
			this:ShowItemUseAndSellPanel()
			UIBag.ItemSellAndUsePanel.SellPrice.text=tostring(item.ItemData.Price)
			UIBag.ItemSellAndUsePanel.des.text=tostring(item.ItemData.Description)
			this:ShowGameobj(UIBag.ItemSellAndUsePanel.SellAndUse,false)
			this:ShowGameobj(UIBag.ItemSellAndUsePanel.OnlySellBtn,true)
			this:ShowGameobj(UIBag.ItemSellAndUsePanel.OnlyUseBtn,false)
		end

		if item.ItemData.CanSell==0 and item.ItemData.IsUse==0 then		--只有说明
			this:CloseItemPanel(UIBag.ItemSellAndUsePanel.des.transform.parent)
			this:OpenItemPanel(UIBag.ItemInfoPanel.des.transform.parent)
			UIBag.ItemInfoPanel.des.text=tostring( item.ItemData.Description)
		end
	end


end
function UIBag:RefrashUIBagItem(item)--刷新背包中单个item
	if UIBag.ItemList~=nil then
		local id=tonumber( item.itemContain.name)
		if item.ItemData.Count==0 then
			UIBag.ItemList[id]=nil
			GameObject.Destroy(item.itemContain.gameObject)
			UIBag.ItemClick=nil
			UIBag.Grid.enabled =true
			UIBag.Grid:Reposition()
			this:showItemInfoPanel(tonumber(id)+1)
			return
		end
		if item.ItemData.Count>0  then
			UIBag.ItemList[id]=item
			item.itemContain.transform:FindChild("count"):GetComponent("UILabel").text=tostring(item.ItemData.Count)
			this:showItemInfoPanel(id)
		end
	end
	if UIBag.ItemList[id]==nil then
		UIBag.ItemList[id]=item
		local data=
		{
			itemData=item.ItemData,
			index=item.itemContain.name,
		}
		MainGameUI.CreateLittleItem(tostring(index) , "itemIcon" , UIBag.Grid.transform , data , this.CreateItemListCallBack , "UIBag")
	end
end
function UIBag:ShowItemUseAndSellPanel()
	this:OpenItemPanel(UIBag.ItemInfoPanel.icon.transform.parent)
	this:CloseItemPanel(UIBag.ItemInfoPanel.des.transform.parent)
	this:OpenItemPanel(UIBag.ItemSellAndUsePanel.des.transform.parent)
end
function UIBag:ClosePanel()
	UIBag.UIBagGod:SetActive(false)
end

function UIBag:OpenItemPanel(panel)
	panel.gameObject:SetActive(true)
end

function UIBag:CloseItemPanel(panel)
	panel.gameObject:SetActive(false)
end

function UIBag:ShowGameobj(obj,isShow)
	obj.gameObject:SetActive(isShow)
end
--排序
function UIBag.Comp(A , B)
    if A~=nil and B~=nil then
       if A.Quality>B.Quality then
          return true

		elseif A.Quality==B.Quality then
             if A.Id > B.Id then
                return true
             elseif A.Id < B.Id then
                return false
             elseif A.Id==B.Id then
                return false
			end
       elseif A.Quality<B.Quality then
          return false
       end
    end
--    return false
end

function UIBag:ReleasPanel()
	UIBag.UIBagGod = nil

	UIBag.TabPage=nil --标签页
	UIBag.Grid=nil --存放道具列表的父物体
	UIBag.ItemList={} --存放物品列表的数组（key,item）

	UIBag.ItemClick=nil --点击的那个物品

	UIBag.SwitchBtns=
	{
		daoju=nil,
		libao=nil,
		zhuangbei=nil,
		suipian=nil,
		shizhuang=nil,
	}

	UIBag.ItemInfoPanel={}
	UIBag.ItemSellAndUsePanel={}

	UIBag.UIBagUseItemPanel=nil
	UIBag.UIBagUseItemPanelName=nil
	UIBag.UIBagUseItemPanelCountText=nil
	UIBag.UIBagUseItemPanelCount=1
end





--[[物品使用的panel，后续将独立出来--]]
UIBag.UIBagUseItemPanel=nil
UIBag.UIBagUseItemPanelName=nil
UIBag.UIBagUseItemPanelCountText=nil
UIBag.UIBagUseItemPanelCount=1
function UIBag:OpenUIBagItemUsePanel()
	this:OpenItemPanel(UIBag.UIBagUseItemPanel.gameObject)

	if UIBag.ItemClick~=nil then
		UIBag.UIBagUseItemPanelName=UIBag.UIBagUseItemPanel.transform:FindChild("name"):GetComponent("UILabel")
		UIBag.UIBagUseItemPanelCountText=UIBag.UIBagUseItemPanel.transform:FindChild("count"):GetComponent("UILabel")
		UIBag.UIBagUseItemPanelName.text=tostring(UIBag.ItemClick.ItemData.name)
--local max=UIBag.ItemClick.ItemData.Count
		UIBag.UIBagUseItemPanelCountText.text=tostring(UIBag.UIBagUseItemPanelCount)
	end
end

function UIBag:UseItem()
	--使用，向服务器发出使用道具请求,扣除数据,
	--测试用
	this:CloseItemPanel(UIBag.UIBagUseItemPanel.gameObject)
	local count=tonumber(UIBag.ItemClick.ItemData.Count)-tonumber(UIBag.UIBagUseItemPanelCount)
	local id=tonumber(UIBag.ItemClick.itemContain.name)
	if UIBag.TabPage==UIBag.SwitchBtns.daoju then
		ItemPackageSys.AddItem(UIBag.ItemClick.ItemData.Id, count)
	end

	UIBag.UIBagUseItemPanelCount=1
--	this:UpDateInfo()
	UIBag.ItemList[id].ItemData.Count=count

	this:RefrashUIBagItem(UIBag.ItemList[id])

end

function UIBag:UseItemCountChange(num)
	if UIBag.ItemClick~=nil then
		if tonumber( num)>=UIBag.ItemClick.ItemData.Count then
			UIBag.UIBagUseItemPanelCount=UIBag.ItemClick.ItemData.Count
		end
		UIBag.UIBagUseItemPanelCount=UIBag.UIBagUseItemPanelCount+num
		if tonumber(UIBag.UIBagUseItemPanelCount) <= 0 then
			UIBag.UIBagUseItemPanelCount=0
		end
		if tonumber(UIBag.UIBagUseItemPanelCount) >= tonumber(UIBag.ItemClick.ItemData.Count) then
			UIBag.UIBagUseItemPanelCount=UIBag.ItemClick.ItemData.Count
		end

	UIBag.UIBagUseItemPanelCountText.text=tostring(UIBag.UIBagUseItemPanelCount)
	end
end

return UIBag
