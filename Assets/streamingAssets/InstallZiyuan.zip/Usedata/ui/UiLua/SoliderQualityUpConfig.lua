﻿SoliderQualityUpConfig = {}                                                            
SoliderQualityUpConfig.SoliderQualityUpConfig = {}
function SoliderQualityUpConfig.IniSome()

	local theDB = configDB.Ins.theDB;
	local sqReader = theDB:ReadFullTable("Soldier_Quality_Up")
	while (sqReader:Read() ~= false) 
	do
        local _Id = sqReader:GetInt32(0)
        SoliderQualityUpConfig.SoliderQualityUpConfig[_Id] =
        {        
            Id = sqReader:GetInt32(0),                        --ID          
            Quality = sqReader:GetInt32(1),                     --名字  
            QualityLvl = sqReader:GetInt32(2),                  --名字  
            UpToId = sqReader:GetInt32(3),                 --名字         
            UpNeed = sqReader:GetString(4),               --Start1_Time            
		}
    end
end

function SoliderQualityUpConfig.GetSoliderQualityInfoById(_Id)
    if SoliderQaulityUpConfig.SoliderQaulityUpConfig[_Id] ~=nil then
       return SoliderQaulityUpConfig.SoliderQaulityUpConfig[_Id]
    end
    Debug.LogError("数据库配置Soldier_Quality_Up错误id:")
    Debug.LogError(_Id)
    return nil
end

function SoliderQualityUpConfig.GetNextQualityInfo(_Id)
   local _QualityInfo = SoliderQaulityUpConfig.GetSoliderQualityInfoById(_Id)
   local _NextInfoId = _QualityInfo.UpToId
   if _QualityInfo~=nil then
      local _NextQualityInfo  = SoliderQaulityUpConfig.GetSoliderQualityInfoById(_NextInfoId)
      if _NextQualityInfo==nil then
         Debug.LogError("已达到最高品质")
         return nil     
      else
         return _NextQualityInfo
      end
   else
      Debug.LogError("数据库配置Soldier_Quality_Up错误id:")
      Debug.LogError(_Id)
      return nil
   end
end

return SoliderQualityUpConfig