PlayerControl = {}															   --鼠标点击事件和角色控制

local this = PlayerControl

PlayerControl.MainCamera = nil												   --场景中的主摄像机父亲
PlayerControl.MainCityCamera = nil
PlayerControl.MainCameraTransform = nil
PlayerControl.UICamera = nil
PlayerControl.TheMeCharacter = nil											   --获得玩家操作对象
PlayerControl.UICallBack = nil												   --玩家移动到某个位置的UI事件

PlayerControl.TheMeNav = nil	
PlayerControl.TheMeAnimation = nil
PlayerControl.TargetPosition = nil
PlayerControl.TheMeGob = nil 												   --玩家操作的移动者
PlayerControl.TheMeGobTransform = nil

PlayerControl.PlayerList = {}
PlayerControl.WorldId = nil

PlayerControl.MyMapCityGob = nil 
PlayerControl.MyMapCityTrans = nil

function PlayerControl.InitSome()
    
	local lua = GameMain.requireLuaFile("CharacterBase")
	local Character = lua:new()
    Character:CreatePlayer(PlayerControl.WorldId , "my"  , "my")
    
    local data = {}
    WorldMapSys.LoadAssetByObject(data , "MapCity" , PlayerControl.CreateMyMapCity)

	PlayerControl.TheMeCharacter = Character

    PlayerControl.PlayerList = {}
    PlayerControl.MainCamera = GameObject.Find("MainCamera")
    PlayerControl.MainCityCamera = PlayerControl.MainCamera:GetComponent("Camera")
    PlayerControl.MainCameraTransform = PlayerControl.MainCamera.transform

   -- PlayerControl.TheMeCharacter:GetMoveNodes(WorldMapSys.Stat , WorldMapSys.End)
	GameMain.AddUpdateLua(PlayerControl.Update)

end

function PlayerControl.ClickCityEvent(_City)
  

   local UIWorldMapTar = MainGameUI.FindPanelTarget("UIWorldMap")
   if UIWorldMapTar~=nil then
      UIWorldMapTar:OpenCityInfoPanel(_City)
   end
end

function PlayerControl.CreateMyMapCity(_Info , _Prefab)
   local Gob = GameObject.Instantiate(_Prefab,Vector3.zero,Quaternion.identity)

   Gob.transform.name = "MyMapPoint"
   --Gob.transform.parent = WorldMapSys.SmallMapFatehr.transform
   Gob.transform.localScale = Vector3(1 , 1 , 1)
   Gob.transform.localEulerAngles = Vector3(0 , 0 , 0)
   Gob.transform.localPosition = Vector3(-568 , 0 , -320) --_Info.Pos.x/128)/2.5 , 0 , (_Info.Pos.z/128)/3.5)
   PlayerControl.MyMapCityGob = Gob.transform:FindChild("MyPoint")
   PlayerControl.MyMapCityTrans = PlayerControl.MyMapCityGob.transform
   lgNoDelCsFun.Ins:SetSpriteColor(PlayerControl.MyMapCityGob:GetComponent("SpriteRenderer") , 255/255 , 255/255 , 0/255)
end


function PlayerControl.CreateCharacter(_WordldId , _Nodes , _TempTime , _NodeCount)
   if _WordldId==PlayerControl.WorldId then                         --对于本玩家来说
      local SaveNodes = {}
      for i = 1 , #_Nodes , 1 do
          local NodeId = _Nodes[i]
          SaveNodes[i] = WorldMapSys.CityNodes[NodeId]
      end

      if _NodeCount==1 then                                         --进入世界地图 初始位置
         PlayerControl.TheMeCharacter:SetNodeInfo(SaveNodes[1])
         PlayerControl.TheMeCharacter:SetPos(SaveNodes[1].Pos)
         --PlayerControl.TheMeCharacter:SetMoveState("Idle")
         --PlayerControl.TheMeCharacter:InitMoveState()          
      else                                                         
          if _TempTime~=nil and _TempTime~=0 then                   --登陆后 上次移动还没有结束
             PlayerControl.TheMeCharacter:SendNetEventTempTime(SaveNodes , _TempTime)
          elseif _TempTime~=nil and _TempTime==0 then               --已经在世界地图中 然后进行移动
             PlayerControl.TheMeCharacter:SendNetEvent(SaveNodes)
          end 
      end

   else          
       local SaveNodes = {}                                         --其他玩家
       for i = 1 , #_Nodes , 1 do
           local NodeId = _Nodes[i]
           SaveNodes[i] = WorldMapSys.CityNodes[NodeId]
       end
                                                          
       if _NodeCount==1 then
          if PlayerControl.PlayerList[_WordldId]==nil then
              local lua = GameMain.requireLuaFile("CharacterBase")
	          local Character = lua:new()
              PlayerControl.PlayerList[_WordldId] = Character
              local StartNode = SaveNodes[1]
              Character:CreatePlayer(_WordldId , "my"  , "my")
          end
          PlayerControl.PlayerList[_WordldId]:SetNodeInfo(SaveNodes[1])
          PlayerControl.PlayerList[_WordldId]:SetPos(SaveNodes[1].Pos)
          PlayerControl.PlayerList[_WordldId]:SetMoveState("Idle")
          PlayerControl.PlayerList[_WordldId]:InitMoveState()
          return
       end

       
       if _TempTime==nil or _TempTime==0 then                       --当前玩家已经在世界地图中 然后进行移动
           if PlayerControl.PlayerList[_WordldId]==nil then         --玩家不在缓存中
              local lua = GameMain.requireLuaFile("CharacterBase")
	          local Character = lua:new()
              PlayerControl.PlayerList[_WordldId] = Character
              local StartNode = SaveNodes[1]
              Character:CreatePlayer(_WordldId , "my"  , "my")
              Character:SetNodeInfo(StartNode)
              Character:SetPos(StartNode.Pos)
              Character:SetMoveState("Idle")
           
              Character:SendNetEvent(SaveNodes)      
           else                                                     --玩家存在
              local Character = PlayerControl.PlayerList[_WordldId]
              Character:SendNetEvent(SaveNodes)   
           end
       elseif _TempTime~=nil and _TempTime~=0 then                  --更新其他玩家已经在移动的状态
           if PlayerControl.PlayerList[_WordldId]==nil then
              local lua = GameMain.requireLuaFile("CharacterBase")
	          local Character = lua:new()
              PlayerControl.PlayerList[_WordldId] = Character
              local StartNode = SaveNodes[1]
              Character:CreatePlayer(_WordldId , "my"  , "my")
              Character:SetNodeInfo(StartNode)
              Character:SetPos(StartNode.Pos)
              Character:SetMoveState("Idle")

              Character:SendNetEventTempTime(SaveNodes , _TempTime)      
           else
              local Character = PlayerControl.PlayerList[_WordldId]
              Character:SendNetEventTempTime(SaveNodes , _TempTime)
      
           end

       end
   end
end


function PlayerControl.GetCamera()                                                                  --获得玩家主场景控制的摄像机
	return PlayerControl.MainCityCamera	
end

function PlayerControl.ClickEvent()                                                                  --玩家的点击事件
	 if Input.GetMouseButtonDown(0)==true then		
		local pos1 = Input.mousePosition
	
		PlayerControl.PlayerTouch(pos1)			
	end	
end

function PlayerControl.PlayerTouch(pos)

	if DataUIInstance.JudgeUIEvent()==true then                                                     --检查是否点击UI
		return
	end											
	
	local cam = PlayerControl.GetCamera()	
	local ray =cam:ScreenPointToRay(pos)
	GameMain.GetHitRay(ray,1000,PlayerControl.GetHitRayCB)
	
end



function PlayerControl.GetHitRayCB(terHit,hitInfo)                                                  --普通按地面移动
	  if terHit == false then
            return
      end

	  local pos = Vector3(hitInfo.point.x,hitInfo.point.y,hitInfo.point.z)
	  if PlayerControl.clickEffectObj == nil then
          local params = {}
		  params.pos = pos
		  ResourceManager.LoadAssetByObject(params, "arrow", PlayerControl.loadClickEffectObjCb)
	  else
		  PlayerControl.PlayClickEffectAnimation(pos)
	  end


	  if hitInfo.collider.gameObject.name=="City1_1_road_sea" or hitInfo.collider.gameObject.name=="City_Terrain1_Road" then
	     PlayerControl.UICallBack = nil
	  	 local targetPos = Vector3(hitInfo.point.x,hitInfo.point.y,hitInfo.point.z)
		 PlayerControl.GoPosition(targetPos , nil , nil)
         MusicPlaySys.MainCityNewDestination()
	  elseif hitInfo.collider.gameObject.name=="City_Board" then
         local UIControlTar = MainGameUI.FindPanelTarget("UIControl")
         if UIControlTar~=nil then
            UIControlTar.OpenMasterInfomation()
         end
      else

         local WorldId = hitInfo.collider.transform.parent.parent.name
       
         if WorldId==ClinetInfomation.World_id then
            return
         end
         WorldPlayerSys.SearchWorldPlayer(WorldId , DataUIInstance.OpenWorldPlayerShow)
         MusicPlaySys.PlayOpenSCROLLMusic()
      end
	
end


function PlayerControl.Update(deletime)
    
   PlayerControl.MyActions(deletime/2)      
   PlayerControl.OthersActions(deletime/2)
end

function PlayerControl.MyActions(deletime)
    if PlayerControl.TheMeCharacter~=nil then
       PlayerControl.TheMeCharacter:Update(deletime)
    end
end


function PlayerControl.OthersActions(deletime)
   for key , value in pairs(PlayerControl.PlayerList) do
       value:Update(deletime)
   end
end

function PlayerControl.UpdateNPCMessage(deletime) 

   for i = 1 , #PlayerControl.NPC , 1 do
       if PlayerControl.NPC[i].ChatMessageGob~=nil and  PlayerControl.NPC[i].SkinMeshRender~=nil and PlayerControl.NPC[i].ShowMessage==true then                           --显示NPC头顶的文字
              
          PlayerControl.NPC[i].NowShowMessageTime = PlayerControl.NPC[i].NowShowMessageTime + deletime
          if PlayerControl.NPC[i].NowShowMessageTime > PlayerControl.NPC[i].ShowMessageTime then
             PlayerControl.NPC[i].NowShowMessageTime = 0
             PlayerControl.NPC[i].ShowMessageTime = 5
             PlayerControl.NPC[i].ShowTime = false
             if PlayerControl.NPC[i].ChatMessageGob.position.x ~= 10000 then          
                PlayerControl.NPC[i].ChatMessageGob.position = Vector3(10000 , 0 , 0)
             end 
          elseif PlayerControl.NPC[i].NowShowMessageTime <= PlayerControl.NPC[i].ShowMessageTime and PlayerControl.NPC[i].ShowTime == true then
              local pos1 = PlayerControl.MainCityCamera:WorldToScreenPoint(PlayerControl.NPC[i].localPosition) 
              pos1 = Vector3(pos1.x , pos1.y + 70 , 0)
              if PlayerControl.UICamera==nil then
                 local UICamera = MainGameUI.GetUICameraInMainCity()
                 PlayerControl.UICamera = UICamera:GetComponent("Camera")
              end
              local pos2 = PlayerControl.UICamera:ScreenToWorldPoint(pos1)
              PlayerControl.NPC[i].ChatMessageGob.position = pos2
          end       
       elseif PlayerControl.NPC[i].ChatMessageGob~=nil and PlayerControl.NPC[i].ShowMessage~=nil and PlayerControl.NPC[i].ShowMessage==false then
          if PlayerControl.NPC[i].ChatMessageGob.position.x ~= 10000 then
             PlayerControl.NPC[i].ChatMessageGob.position = Vector3(10000 , 0 , 0)
          end 
       end
   end

   for i = 1 , #PlayerControl.NPC , 1 do
       if PlayerControl.NPC[i].ChatMessageGob~=nil and PlayerControl.NPC[i].SkinMeshRender~=nil and PlayerControl.NPC[i].SkinMeshRender.isVisible == true then          
          if PlayerControl.NPC[i].ShowMessage~=nil and PlayerControl.NPC[i].ShowMessage == false and PlayerControl.TheMeGobTransform~=nil then
             local Distance = Vector3.Distance(PlayerControl.NPC[i].localPosition , PlayerControl.TheMeGobTransform.localPosition)
             if Distance<20 then
                 PlayerControl.NPC[i].ShowMessage = true
                 PlayerControl.NPC[i].ShowTime = true
                 PlayerControl.NPC[i].NowShowMessageTime = 0
                 PlayerControl.NPC[i].ShowMessageTime = 5 
                 PlayerControl.SetNPCMag()
             end           
          end                          
       end
        
       if PlayerControl.TheMeGobTransform~=nil and PlayerControl.NPC[i].ShowMessage~=nil and PlayerControl.NPC[i].ShowMessage == true then
          local Distance = Vector3.Distance(PlayerControl.NPC[i].localPosition , PlayerControl.TheMeGobTransform.localPosition)
          if Distance>20 then 
             PlayerControl.NPC[i].ShowMessage = false
          end
       end               
   end
end

function PlayerControl.SetNPCMag()
   for i = 1 , #PlayerControl.NPC , 1 do
       if PlayerControl.NPC[i].SkinMeshRender~=nil and PlayerControl.NPC[i].ChatMessageGob~=nil then
          local PosId =Random.Range(1 , 10)
          local Mag = ""
          if PosId>5 then
             Mag = PlayerControl.NPC[i].Message1
          else
             Mag = PlayerControl.NPC[i].Message2
          end
          PlayerControl.NPC[i].ChatLabel.text = Mag
          local Beilv = PlayerControl.NPC[i].ChatLabel.height/23
          local BgY = Beilv*32
          PlayerControl.NPC[i].ChatBg.height = BgY
       end
   end
end



function PlayerControl.Release()

	GameMain.DelMainSceneUpdateLua(PlayerControl.Update)

    if PlayerControl.TheMeCharacter~=nil then
       PlayerControl.TheMeCharacter:Release()
    end

    PlayerControl.SpeakIn = false 
    PlayerControl.TheMeCharacter = nil
    PlayerControl.TheMeNav = nil
    PlayerControl.TheMeGob = nil
    PlayerControl.MainCamera = nil
    PlayerControl.MainCityCamera = nil
    PlayerControl.UICamera = nil
	PlayerControl.clickEffectObj = nil
    PlayerControl.MainCameraTransform = nil
    PlayerControl.TheMeGobTransform = nil

    PlayerControl.ChangeSpeakTime = 1                                               --五秒取一条聊天数据
    PlayerControl.ChangeSpeakNowTime = 0
    PlayerControl.NextSpeakMessage = 1                                              --1秒间隔等待下个玩家说话
    PlayerControl.NextSpeakMessageNowTime = 0                                       --当前间隔时间

    for key , value in pairs(PlayerControl.PlayerMasterList) do
        if value.Gob~=nil then
           GameObject.Destroy(value.Gob)
        end
    end
    PlayerControl.PlayerMasterList = {}
    for key, value in pairs(PlayerControl.PlayerList) do
		if value~=nil then
		   local charat = value
		   charat:Release()
           PlayerControl.PlayerList[key]=nil
		end
	end

    PlayerControl.NPC = {}

    TalkSys.Release() 
end

return PlayerControl