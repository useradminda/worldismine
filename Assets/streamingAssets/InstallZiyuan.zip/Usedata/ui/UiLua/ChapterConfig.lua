ChapterConfig = {}                                                            
ChapterConfig.ChapterConfig = {}
function ChapterConfig.IniSome()

	local theDB = configDB.Ins.theDB;
	local sqReader = theDB:ReadFullTable("LevelChapter")
	while (sqReader:Read() ~= false) 
	do
        local _DBid = sqReader:GetInt32(0)
        ChapterConfig.ChapterConfig[_DBid] = {        
            Id = sqReader:GetInt32(0),                        --ID                                  
            Name = sqReader:GetString(1),                     --����  
            Count = sqReader:GetInt32(2),                  --ģ������
            Type = sqReader:GetInt32(3),                     --����
            Descrip = sqReader:GetString(4),                   --��������
            Icon = sqReader:GetString(5),                   --�������� 
            Turn = sqReader:GetInt32(6),              --�����ٶ�
            Pos = sqReader:GetString(7),              --�����ٶ�
            
		}
    end
end

function MapConfig.GetChapterConfigById(_Id)
    if ChapterConfig.ChapterConfig[tonumber(_Id)]~=nil then
       return ChapterConfig.ChapterConfig[tonumber(_Id)]
    end
    Debug.LogError("���ݿ�LevelChapter���ô���id:")
    Debug.LogError(_Id)
    return nil
end

function ChapterConfig.GetChapterConfigData()
    
    return ChapterConfig.ChapterConfig

end

return MapConfig