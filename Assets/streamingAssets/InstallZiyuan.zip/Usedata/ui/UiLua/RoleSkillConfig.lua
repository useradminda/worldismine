RoleSkillConfig = {}                                                            
RoleSkillConfig.RoleSkillConfig = {}
function RoleSkillConfig.IniSome()

	local theDB = configDB.Ins.theDB;
	local sqReader = theDB:ReadFullTable("Skill")
    RoleSkillConfig.Number = 1
	while (sqReader:Read() ~= false) 
	do
      
        RoleSkillConfig.RoleSkillConfig[RoleSkillConfig.Number] = {        
            Id = sqReader:GetInt32(0),                        --ID          
            Name = sqReader:GetString(1),                     --����  
            ColdTime = sqReader:GetFloat(2),                  --����  
            SkillTime = sqReader:GetFloat(3),                 --����         
            Start1_Time = sqReader:GetFloat(4),               --Start1_Time     
            Start2_Time = sqReader:GetFloat(5),               --Start2_Time  
            Ammo1_id = sqReader:GetString(6),                   --��������
            Ammo2_id = sqReader:GetString(7),                   --��������
            Buff1_id = sqReader:GetString(8),                   --��������
            Buff2_id = sqReader:GetString(9),                   --��������
            Start1_Effect = sqReader:GetInt32(10),                   --��������
            Start2_Effect = sqReader:GetInt32(11),                   --��������
            ChosePos = sqReader:GetInt32(12),                   --��������
            LogicName = sqReader:GetString(13),                 --�߼��ű�
            Param = sqReader:GetString(14),                 --��������  
            Descrip = sqReader:GetString(15),                 --��������              
            Music = sqReader:GetString(16),                 --��������   
            Icon = sqReader:GetString(17),                 --��������   
		}

        RoleSkillConfig.Number = RoleSkillConfig.Number + 1
    end
end

function RoleSkillConfig.GetRoleSkillById(_Id)
    
    for i = 1 , #RoleSkillConfig.RoleSkillConfig  ,1 do
        if RoleSkillConfig.RoleSkillConfig[i].Id == _Id then
           return RoleSkillConfig.RoleSkillConfig[i]
        end
    end 
    return nil
end

function  RoleSkillConfig.GetRoleSkillData()
    
    return RoleSkillConfig.RoleSkillConfig

end

return RoleSkillConfig