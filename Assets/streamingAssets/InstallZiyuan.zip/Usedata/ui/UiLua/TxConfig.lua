TxConfig = {}
TxConfig.TxConfigTable = {}
function TxConfig.IniSome()

	local theDB = configDB.Ins.theDB;
	local sqReader = theDB:ReadFullTable("Effect")
	while (sqReader:Read() ~= false) 
	do
        local _Id = sqReader:GetInt32(0)
        TxConfig.TxConfigTable[_Id] = {        
            Id = sqReader:GetInt32(0),                        --ID          
            LifeTime = sqReader:GetFloat(1),                    
            Type = sqReader:GetInt32(2),                   
            PrefabName = sqReader:GetString(3),                 -- 
            Mounttype = sqReader:GetInt32(4),                 --
            Mountid = sqReader:GetInt32(5),                 --
            Description =  sqReader:GetString(6),     
		}     
    end
end

function TxConfig.GetTxById(_Id)
    
    if TxConfig.TxConfigTable[tonumber(_Id)]~=nil then
       return TxConfig.TxConfigTable[tonumber(_Id)]
    end
    Debug.LogError("���ݿ�Buff���ô���id:")
    Debug.LogError(_Id)
    return nil
end

function TxConfig.GetTxData()
    
    return TxConfig.TxConfigTable

end

return TxConfig