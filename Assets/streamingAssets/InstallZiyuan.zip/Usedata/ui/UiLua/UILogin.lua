--[[��¼���� ȱ���½��棬�������б������档����--]]
UILogin = {}

local UILogin = BasePanel:new()     
local this = UILogin
UILogin.UILoginGob = nil

UILogin.RegistName=nil
UILogin.RegistPassWord=nil
UILogin.RegistePanel = nil

UILogin.LoginPanel = nil
UILogin.LoginName=nil
UILogin.LoginPassWord=nil

function UILogin:OpenUI(_PanelName , _LuaName)
	
	UILogin.UILoginGob=MainGameUI.FindPanel("UILogin")
	
	UILogin.LoginPanel = UILogin.UILoginGob.transform:FindChild("LoginPanel")
	UILogin.LoginName=UILogin.LoginPanel.transform:FindChild("LoginName"):GetComponent("UIInput")
	UILogin.LoginPassWord=UILogin.LoginPanel.transform:FindChild("LoginPassWord"):GetComponent("UIInput")

	UILogin.RegistePanel = UILogin.UILoginGob.transform:FindChild("RegistePanel")
	UILogin.RegistPassWord=UILogin.RegistePanel.transform:FindChild("registerPassWord"):GetComponent("UIInput")
	UILogin.RegistName=UILogin.RegistePanel.transform:FindChild("registerName"):GetComponent("UIInput")
--LoginPanel
	this:SetLoginInfo()
	
end

function UILogin:SetLoginInfo()--���õ�¼��Ϣ
	this:ClosePanel(UILogin.RegistePanel)
	this:OpenPanel(UILogin.LoginPanel)

	if LoginData.RegisterEmail~=nil then   
		UILogin.LoginName.value=LoginData.RegisterEmail
		if LoginData.RegisterPassword~=nil then
			UILogin.LoginPassWord.value=LoginData.RegisterPassword
		end
	end
end

function UILogin:UIHand(_LuaName , _Gob)
    if _Gob.name=="LoginBtn" then
		this:EnterGame()
    end

	if _Gob.name=="LoginRegistBtn" then
		this:ClosePanel(UILogin.LoginPanel)
		this:OpenPanel(UILogin.RegistePanel)
	end

	if _Gob.name == "RegistBtn" then     
       	this:RegistGame()  
	end 
	if _Gob.name=="RegisterCloseBtn" then
		this:ClosePanel(UILogin.RegistePanel)
	end
	if _Gob.name=="LoginCloseBtn" then
		this:ClosePanel(UILogin.LoginPanel)
	end            
end



function UILogin:EnterGame()	--��¼��Ϸ
	--������������ֲ�ƥ�� return
	 LoginData.LoginGame()
	 this:ClosePanel(UILogin.UILoginGob)
	
	--EnterGame
end

function UILogin:RegistGame()	--ע����Ϸ�˺�
	if UILogin.RegistName.value=="" then
		Debug.Log("You Should input your character name")
		return
	end
	
	if UILogin.RegistPassWord.value=="" then
		Debug.Log("You Should input your password")
		return
	end

--	Debug.Log(0000 + UILogin.RegistName.value)
--	Debug.Log(1111 + UILogin.RegistPassWord.value)

	LoginData.RegistGame(UILogin.RegistName.value,UILogin.RegistPassWord.value)
		
	UILogin.RegistName.value=nil
	UILogin.RegistPassWord.value=nil

	this:SetLoginInfo()
	
end

function UILogin:ClosePanel(PanelObj)
	PanelObj.gameObject:SetActive(false)
end

function UILogin:OpenPanel(PanelObj)
	PanelObj.gameObject:SetActive(true)
end


function UILogin:ReleasPanel()
    
    UIControl.UILoginGob = nil
    UIControl.UITT = nil
    UIControl.AnchorCenter = nil


	UILogin.RegistName=nil
	UILogin.RegistPassWord=nil
	UILogin.RegistePanel = nil
	
	UILogin.LoginPanel = nil
	UILogin.LoginName=nil
	UILogin.LoginPassWord=nil

end

return UILogin