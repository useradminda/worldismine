﻿RoleDataConfig = {}                                                            
RoleDataConfig.RoleDataConfig = {}
function RoleDataConfig.IniSome()

	local theDB = configDB.Ins.theDB;
	local sqReader = theDB:ReadFullTable("Role")
    RoleDataConfig.Number = 1
	while (sqReader:Read() ~= false) 
	do
        local _DBid = sqReader:GetInt32(0)
        RoleDataConfig.RoleDataConfig[_DBid] = {        
            Id = sqReader:GetInt32(0),                        --ID                                  
            RealId = sqReader:GetInt32(1),                    --RealId
            Quality = sqReader:GetInt32(2),                   --Quality
            Name = sqReader:GetString(3),                     --名字  
            FbxName = sqReader:GetString(4),                  --模型名字
            Life = sqReader:GetString(5),                     --生命
            Attack = sqReader:GetString(6),                   --攻击参数
            MoveSpeed = sqReader:GetString(7),                --移动速度
            AttackSpeed = sqReader:GetString(8),              --攻击速度
            Defence = sqReader:GetString(9),                  --防御速度
            AttackRange = sqReader:GetInt32(10),               --攻击类型
            WarningRange = sqReader:GetInt32(11),             --警戒范围
            RoleType = sqReader:GetInt32(12),                 --人物类型
            RoleSeries = sqReader:GetInt32(13),               --人物系别
            AdvanceId = sqReader:GetInt32(14),                --进阶材料
            AdvancedNeed = sqReader:GetString(15),             --材料数量
            Icon = sqReader:GetString(16),                    --头像
            Type_1 = sqReader:GetInt32(17),                   --类型1
            Attack_Id = sqReader:GetInt32(18),                --普攻技能
            Spell_Id = sqReader:GetInt32(19),                 --携带技能
            Mount = sqReader:GetString(20),                   --携带技能
            AttackType = sqReader:GetString(21),              --携带技能
            DefaultSoldier = sqReader:GetInt32(22),           --默认上阵兵种
            SoldierNumType = sqReader:GetInt32(23),           --兵种所占格子
		}

        local LifeList = GameMain.StringSplit(RoleDataConfig.RoleDataConfig[_DBid].Life , ",")
        RoleDataConfig.RoleDataConfig[_DBid].LifeList = LifeList

        local AttackList = GameMain.StringSplit(RoleDataConfig.RoleDataConfig[_DBid].Attack , ",")
        RoleDataConfig.RoleDataConfig[_DBid].AttackList = AttackList

        local MoveSpeedList = GameMain.StringSplit(RoleDataConfig.RoleDataConfig[_DBid].MoveSpeed , ",")
        RoleDataConfig.RoleDataConfig[_DBid].MoveSpeedList = MoveSpeedList

        local AttackSpeedList = GameMain.StringSplit(RoleDataConfig.RoleDataConfig[_DBid].AttackSpeed , ",")
        RoleDataConfig.RoleDataConfig[_DBid].AttackSpeedList = AttackSpeedList

        local DefenceList = GameMain.StringSplit(RoleDataConfig.RoleDataConfig[_DBid].Defence , ",")
        RoleDataConfig.RoleDataConfig[_DBid].DefenceList = DefenceList

       -- RoleDataConfig.Number = RoleDataConfig.Number + 1
    end
end

function RoleDataConfig.GetRoleById(_Id)
    if RoleDataConfig.RoleDataConfig[tonumber(_Id)]~=nil then
       return RoleDataConfig.RoleDataConfig[tonumber(_Id)]
    end
    Debug.LogError("数据库Role配置错误id:")
    Debug.LogError(_Id)
    return nil
end

function  RoleDataConfig.GetRoleData()
    
    return RoleDataConfig.RoleDataConfig

end

return RoleDataConfig