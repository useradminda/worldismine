UIPopPanel = {}

local UIPopPanel = BasePanel:new()                                                  
local this = UIPopPanel
UIPopPanel.UIPopPanelGob = nil

UIPopPanel.NowTime = 0
UIPopPanel.TotalTime = 1
UIPopPanel.State = 0
UIPopPanel.NowX = 0
UIPopPanel.TarX = 0


UIPopPanel.PopNowTime = 0
UIPopPanel.PopPropTotalTime = 0.5
UIPopPanel.PopState = 0
UIPopPanel.PopNumber = 1
UIPopPanel.GobNumber = 1
UIPopPanel.PopList = nil

function UIPopPanel:OpenUI(_PanelName , _LuaName)	 
	UIPopPanel.UIPopPanelGob = MainGameUI.FindPanel("UIPopPanel")
    UIPopPanel.UIPopPanelGob.transform.localPosition = Vector3(10000 , 0 , -1000)
    GameMain.AddUpdateLua(this.UpdatePanel)
end

UIPopPanel.TipWord = nil
function UIPopPanel:PopTip(_Msg , _NowY , _TarY)
   UIPopPanel.UIPopPanelGob.gameObject:SetActive(true)
   if UIPopPanel.TipWord==nil then
      UIPopPanel.TipWord = UIPopPanel.UIPopPanelGob.transform:FindChild("PopText")
   end
   UIPopPanel.TipWord.gameObject:SetActive(true)
   UIPopPanel.TipWord.transform:FindChild("WordMsg"):GetComponent("UILabel").text = _Msg
   local MsgHight = GameMain.StringSplit(_Msg , "\n")
   local HightCount = #MsgHight
   UIPopPanel.TipWord.transform:FindChild("Bg"):GetComponent("UISprite").height = 42*HightCount
   if _NowY==nil then
      UIPopPanel.NowY = 100
   else
      UIPopPanel.NowY = _NowY
   end
   if _TarY==nil then
      UIPopPanel.TarY = 200
   else
      UIPopPanel.TarY = _TarY
   end
   UIPopPanel.NowTime = 0
   UIPopPanel.State = 1
end

UIPopPanel.PropChangePanel = nil
function UIPopPanel:StartPopProp(_PropList)
   UIPopPanel.UIPopPanelGob.gameObject:SetActive(true)
   if UIPopPanel.PropChangePanel==nil then
      UIPopPanel.PropChangePanel = UIPopPanel.UIPopPanelGob.transform:FindChild("PropChangePanel")
   end
   UIPopPanel.PropChangePanel.gameObject:SetActive(true)

   for i = 1 , 5 , 1 do
       UIPopPanel.PropChangePanel:FindChild(tonumber(i)).gameObject:SetActive(false)
   end

   UIPopPanel.PopList = _PropList 
   UIPopPanel.PopNumber = 1
   UIPopPanel.GobNumber = 1
   UIPopPanel.PopNowTime = 0
   this:PopProp(UIPopPanel.GobNumber , UIPopPanel.PopNumber)
   UIPopPanel.PopState = 1
end

function UIPopPanel:PopProp(_GobNumber , _PopNumber)
   UIPopPanel.PropChangePanel:FindChild(tonumber(_GobNumber)).gameObject:SetActive(true)
   UIPopPanel.PropChangePanel:FindChild(tonumber(_GobNumber)):GetComponent("UILabel").text = UIPopPanel.PopList[_PopNumber]
   UIPopPanel.PropChangePanel:FindChild(tonumber(_GobNumber)):GetComponent("TweenPosition"):ResetToBeginning()
   UIPopPanel.PropChangePanel:FindChild(tonumber(_GobNumber)):GetComponent("TweenAlpha"):ResetToBeginning()
   UIPopPanel.PropChangePanel:FindChild(tonumber(_GobNumber)):GetComponent("TweenPosition"):Play()
   UIPopPanel.PropChangePanel:FindChild(tonumber(_GobNumber)):GetComponent("TweenAlpha"):Play()
end

UIPopPanel.CallBack = nil
function UIPopPanel:PopTipPanel(_Data)
   UIPopPanel.UIPopPanelGob.gameObject:SetActive(true)
   if _Data.Type=="BuySta" or _Data.Type=="BuyEnergy" then
      this:PopBuySta_EnergyPanel(_Data.Data)
   end

   if _Data.Type=="UseItem" then
      this:PopUseItemPanel(_Data.Data)
   end
   
   if _Data.Type=="BuyDiamon" then
      this:PopBuyDiamond(_Data.Data)
   end
   if _Data.Type=="BuyCoin" then
      this:PopBuyCoin(_Data.Data)
   end

   if _Data.Type=="BuyMoreMaterial" then
      this:PopBuyMoreMaterial(_Data.Data)
   end

   if _Data.Type=="Production" then
      this:PopProductionPanel(_Data.Data)
   end

   if _Data.Type=="SkillInfo" then
      this:PopSkillPanel(_Data.Data)
   end

   if _Data.Type=="Resign" then
      this:PopResignPanel(_Data.Data)
   end

   if _Data.Type=="ItemInfo" then
      this:PopItemInfoPanel(_Data.Data)
   end

   if _Data.Type=="ChoseRule" then
      this:PopChoseRulePanel(_Data.Data)
   end

   if _Data.Type=="NetError" then
      this:PopNetErrorPanel(_Data.Data)
   end

   UIPopPanel.CallBack = _Data.CallBack
end

UIPopPanel.BuySta_EnergyPanel = nil
function UIPopPanel:PopBuySta_EnergyPanel(data)                                 --�������� �������
   if UIPopPanel.BuySta_EnergyPanel==nil then
      MainGameUI.CreateLittleItem("PopPanelSta_Energy" , "PopPanelSta_Energy" , UIPopPanel.UIPopPanelGob , data , this.CreateSta_EnergyCallBack , "UIPopPanel")
   else
      this:CreateSta_EnergyCallBack(UIPopPanel.BuySta_EnergyPanel , data)
   end
end

function UIPopPanel:CreateSta_EnergyCallBack(_Gob , _Info)
   UIPopPanel.BuySta_EnergyPanel = _Gob 
end

UIPopPanel.UseItemPanel = nil
UIPopPanel.UseItem = nil
function UIPopPanel:PopUseItemPanel(data)                                   --ʹ�õ������
   if UIPopPanel.UseItemPanel==nil then
      MainGameUI.CreateLittleItem("UseItemPanel" , "UseItemPanel" , UIPopPanel.UIPopPanelGob , data , this.CreatePopUsePanel , "UIPopPanel")
   else
      this:CreatePopUsePanel(UIPopPanel.UseItemPanel , data) 
   end
end

function UIPopPanel:CreatePopUsePanel(_Gob , _Info)
   _Gob.gameObject:SetActive(true)
   UIPopPanel.UseItemPanel = _Gob
   UIPopPanel.UseItemPanel.transform.localPosition = Vector3(0 , 0 , -1000)
   UIPopPanel.UseItem = _Info
   this:SetUseItem(UIPopPanel.UseItem)
end

function UIPopPanel:SetUseItem(_Item)
    UIPopPanel.UseItemPanel.transform:FindChild("ItemInfo"):FindChild("ItemName"):GetComponent("UILabel").text = _Item.name
    UIPopPanel.UseItemPanel.transform:FindChild("ItemInfo"):FindChild("Descrip"):GetComponent("UILabel").text = _Item.Descrip
    local _Sprite = UIPopPanel.UseItemPanel.transform:FindChild("ItemHead"):FindChild("ItemIcon"):FindChild("ItemIMG"):GetComponent("UISprite")
    AtlasMsg.SetAtlas(_Sprite , _Item.AtlasName , _Item.SpriteName)
    UIPopPanel.UseItemPanel.transform:FindChild("ItemHead"):FindChild("ItemIcon"):FindChild("ItemFg"):GetComponent("UISprite").spriteName = UIstring.ItemFg[_Item.quality]
end

UIPopPanel.UseMoreItemPanel = nil                                                                             --��������ʹ�ý���
UIPopPanel.UseItemNum = 1
function UIPopPanel:PopUseMoreItemPanel()
   if UIPopPanel.UseItemPanel~=nil then
      if UIPopPanel.UseMoreItemPanel==nil then
         UIPopPanel.UseMoreItemPanel = UIPopPanel.UseItemPanel.transform:FindChild("UseMorePanel")
      end
   end
   UIPopPanel.UseMoreItemPanel.gameObject:SetActive(true)
   this:SetUseItemNum(UIPopPanel.UseItemNum)
end

function UIPopPanel:SetUseItemNum(_Num)                                                   --��������ʹ�õ��ߵ�����
   UIPopPanel.UseMoreItemPanel.transform:FindChild("Num"):FindChild("Num"):GetComponent("UILabel").text = tostring(_Num)
end

function UIPopPanel:SetRightNum()
   local Count = UIPopPanel.UseItem.Count                                                            --����һ���ж��ٸ�
   UIPopPanel.UseItemNum = UIPopPanel.UseItemNum + 10
   if UIPopPanel.UseItemNum > Count then
      UIPopPanel.UseItemNum = Count
   end
   this:SetUseItemNum(UIPopPanel.UseItemNum)
end

function UIPopPanel:SetLeftNum()
   if UIPopPanel.UseItemNum==1 then
      return
   end
   if UIPopPanel.UseItemNum<=11 then
      UIPopPanel.UseItemNum = 1
   else
      UIPopPanel.UseItemNum = UIPopPanel.UseItemNum - 10
   end
   this:SetUseItemNum(UIPopPanel.UseItemNum)
end

function UIPopPanel:CloseUseMorePanel()
   if UIPopPanel.UseMoreItemPanel~=nil then
      UIPopPanel.UseMoreItemPanel.gameObject:SetActive(false)
   end
   this:CloseUIPopPanel()
end

function UIPopPanel:CloseUseItemPanel()
   if UIPopPanel.UseItemPanel~=nil then
      UIPopPanel.UseItemPanel.gameObject:SetActive(false)
   end
   if UIPopPanel.UseMoreItemPanel~=nil then
      UIPopPanel.UseMoreItemPanel.gameObject:SetActive(false)
   end
   UIPopPanel.UseItemNum = 1 
   this:CloseUIPopPanel()
end

UIPopPanel.BuyDiamondPanel = nil
function UIPopPanel:PopBuyDiamond(data)                                         --������ʯ���

end

UIPopPanel.BuyCoinPanel = nil
function UIPopPanel:PopBuyCoin(data)                                            --���������

end

UIPopPanel.BuyMorePanel = nil                                                        --����������ʹ�����
UIPopPanel.BuyNum = 0
UIPopPanel.BuyMoreItem = nil
function UIPopPanel:PopBuyMoreMaterial(data)
   if UIPopPanel.BuyMorePanel==nil then
      MainGameUI.CreateLittleItem("BuyMoreMaterialPanel" , "BuyMoreMaterialPanel" , UIPopPanel.UIPopPanelGob , data , this.CreatePopBuyItemsPanel , "UIPopPanel")
   else
      this:CreatePopBuyItemsPanel(UIPopPanel.BuyMorePanel , data) 
   end
end

function UIPopPanel:CreatePopBuyItemsPanel(_Gob , _Info)
   
   _Gob.gameObject:SetActive(true)
   _Gob.transform:FindChild("Materials"):FindChild("MaterialIMG"):GetComponent("UISprite").spriteName = ItemsDataSys.GetResourceIMG(_Info.NeedId)
   UIPopPanel.BuyMoreItem = _Info
   UIPopPanel.BuyMorePanel = _Gob
   UIPopPanel.BuyMorePanel.transform.localPosition = Vector3(0 , 0 , -1000)
   UIPopPanel.BuyNum = 1
   this:SetMateralNum(UIPopPanel.BuyNum)
end

function UIPopPanel:SetMateralNum(_Num)
   UIPopPanel.BuyMorePanel.transform:FindChild("MaterialNum"):FindChild("Num"):GetComponent("UILabel").text = tostring(_Num)
   UIPopPanel.BuyMorePanel.transform:FindChild("Materials"):FindChild("MatericalNum"):GetComponent("UILabel").text = tostring(_Num*UIPopPanel.BuyMoreItem.NeedQtt)
end


function UIPopPanel:SetMaterialLeftNum()
   if UIPopPanel.BuyNum==1 then
      return
   end
   UIPopPanel.BuyNum = UIPopPanel.BuyNum - 1
   this:SetMateralNum(UIPopPanel.BuyNum)
end

function UIPopPanel:SetMaterialRightNum()
   local ItemCount = UIPopPanel.BuyMoreItem.CanBuyNum
   if ItemCount==-1 then
      ItemCount = 999
   end
   if UIPopPanel.BuyNum==ItemCount then
      return
   end
   UIPopPanel.BuyNum = UIPopPanel.BuyNum + 1
   this:SetMateralNum(UIPopPanel.BuyNum)
end

function UIPopPanel:CloseBuyMorePanel()
   if UIPopPanel.BuyMorePanel~=nil then
      UIPopPanel.BuyMorePanel.gameObject:SetActive(false)
   end
   this:CloseUIPopPanel()
end

--������
UIPopPanel.ProductionPanel = nil
UIPopPanel.ProductionList = {}                  --������
function UIPopPanel:PopProductionPanel(data)
   if UIPopPanel.ProductionPanel==nil then
      MainGameUI.CreateLittleItem("ProductionPanel" , "ProductionPanel" , UIPopPanel.UIPopPanelGob , data , this.CreateProductionPanel , "UIPopPanel")
   else
      this:CreateProductionPanel(UIPopPanel.ProductionPanel , data) 
   end
end

function UIPopPanel:CreateProductionPanel(_Gob , _Info)
    _Gob.gameObject:SetActive(true)
    UIPopPanel.ProductionPanel = _Gob
    UIPopPanel.ProductionPanel.transform.localPosition = Vector3(0 , 0 , -1000)


    
    local father = _Gob.transform:FindChild("ProductionPanel"):FindChild("ProductionPanel"):FindChild("ProductionGrid")
    local Count = #UIPopPanel.ProductionList
    for i = 1 , Count , 1 do
        UIPopPanel.ProductionList[i].Gob.gameObject:SetActive(false)
    end

    local Production = GameMain.JsonDecode(tostring(_Info))
  
   -- local Production = GameMain.JsonDecode(tostring(_Info.ProductionInfo))
    local ProductionCount = #Production
    for i = 1 , ProductionCount , 1 do
        if Production[i]~=nil then
           local ProData = Production[i]
           if UIPopPanel.ProductionList[i]~=nil then
              local data =
              {
                 ProData = ProData,
                 Number = i,
                 Father = father,
              }
              this:CreateProductionItems(UIPopPanel.ProductionList[i].Gob , data)
           else
              local data =
              {
                 ProData = ProData,
                 Number = i,
                 Father = father,
              }
              MainGameUI.CreateLittleItem(tostring(i) , "ProductionItem" , father , data , this.CreateProductionItems , "UIPopPanel")
           end
        end 
    end
end

function UIPopPanel:CreateProductionItems(_Gob , _Info)
   _Gob.gameObject:SetActive(true)
   GameMain.AddComponent(_Gob,"UIDragScrollView")
   this:SetProductionItem(_Gob , _Info.ProData)

   UIPopPanel.ProductionList[_Info.Number] =
   {
      Gob = _Gob,
      ProData = _Info.ProData,
   }

   _Info.Father:GetComponent("UIGrid").enabled = true
   _Info.Father:GetComponent("UIGrid"):Reposition()
end

function UIPopPanel:SetProductionItem(_Gob , _Info)
    UIPopPanel.ProductionPanel.transform:FindChild("ProductionPanel").gameObject:SetActive(false)
    UIPopPanel.ProductionPanel.transform:FindChild("ProductionDescrip").gameObject:SetActive(false)
    local Position  = _Info.p
    local Id = _Info.id
    if Position == "map" then
       UIPopPanel.ProductionPanel.transform:FindChild("ProductionPanel").gameObject:SetActive(true)
       local Map = MapDataSys.GetNowMapById(tonumber(Id))
       if Map~=nil then
           _Gob.transform:FindChild("StarInfo"):FindChild("StarNum"):FindChild("StarImg1").gameObject:SetActive(false)
           _Gob.transform:FindChild("StarInfo"):FindChild("StarNum"):FindChild("StarImg2").gameObject:SetActive(false)
           _Gob.transform:FindChild("StarInfo"):FindChild("StarNum"):FindChild("StarImg3").gameObject:SetActive(false)
           if Map.Star==1 then
              _Gob.transform:FindChild("StarInfo"):FindChild("StarNum"):FindChild("StarImg1").gameObject:SetActive(true)
           elseif Map.Star==2 then
              _Gob.transform:FindChild("StarInfo"):FindChild("StarNum"):FindChild("StarImg1").gameObject:SetActive(true)
              _Gob.transform:FindChild("StarInfo"):FindChild("StarNum"):FindChild("StarImg2").gameObject:SetActive(true)
           elseif Map.Star==3 then
              _Gob.transform:FindChild("StarInfo"):FindChild("StarNum"):FindChild("StarImg1").gameObject:SetActive(true)
              _Gob.transform:FindChild("StarInfo"):FindChild("StarNum"):FindChild("StarImg2").gameObject:SetActive(true)
              _Gob.transform:FindChild("StarInfo"):FindChild("StarNum"):FindChild("StarImg3").gameObject:SetActive(true)
           end

           _Gob.transform:FindChild("MapInfo"):FindChild("MapName"):GetComponent("UILabel").text = Map.Name
           _Gob.transform:FindChild("MapInfo"):FindChild("MapTimes"):GetComponent("UILabel").text = tostring(Map.LeftTimes)
       end
    else
        UIPopPanel.ProductionPanel.transform:FindChild("ProductionDescrip").gameObject:SetActive(true)
        UIPopPanel.ProductionPanel.transform:FindChild("ProductionDescrip"):FindChild("Descrip"):GetComponent("UILabel").text = Id
        if Position == "jjc" then

        elseif Position == "tt" then

        elseif Position == "xs" then

        elseif Position == "qjgc" then

        elseif Position == "qt" then
           

        end
    end
end

function UIPopPanel.GoMap(_Key)                              --�򿪸�������
   local ProData = UIPopPanel.ProductionList[_Key].ProData
   local Position  = ProData.p
   local Id = ProData.id
   if Position == "map" then
      local Map = MapDataSys.GetNowMapById(tonumber(Id))
      local Chapter = Map.Chapter
      local MapPos = Map.MapId
      local UIMapTar = MainGameUI.FindPanelTarget("UIMap")
      if UIMapTar~=nil then
         UIMapTar:OpenMapChatperPanel(Chapter , MapPos , Map.BattleType)
      end
   end
end

function UIPopPanel:OpenMap(_Key)
    local _father =  MainGameUI.FindPanel("UIControl")	
	MainGameUI.OpenOnePanel("UIMap" , "UIMap" , "UIMap" , _father , UIPopPanel.GoMap , _Key)
end

function UIPopPanel:CloseProductionPanel()
   if UIPopPanel.ProductionPanel~=nil then
      UIPopPanel.ProductionPanel.gameObject:SetActive(false)
   end
   this:CloseUIPopPanel()
end


--�����������
UIPopPanel.SkillPanel = nil
function UIPopPanel:PopSkillPanel(_SkillInfo)
   local data =
   {
       SkillInfo = _SkillInfo,
   }
   if UIPopPanel.SkillPanel==nil then
      MainGameUI.CreateLittleItem("SkillInfoPanel" , "SkillInfoPanel" , UIPopPanel.UIPopPanelGob , data , this.CreateSkillPanel , "UIPopPanel")
   else
      this:CreateSkillPanel(UIPopPanel.SkillPanel , data) 
   end
end

function UIPopPanel:CreateSkillPanel(_Gob , _Info)

   _Gob.gameObject:SetActive(true)
   UIPopPanel.SkillPanel = _Gob
   UIPopPanel.SkillPanel.transform:FindChild("SkillName"):GetComponent("UILabel").text = _Info.SkillInfo.SkillName
   local _Sprite = UIPopPanel.SkillPanel.transform:FindChild("SkillHead"):FindChild("SkillIcon"):FindChild("SkillIMG"):GetComponent("UISprite")
   AtlasMsg.SetAtlas(_Sprite , _Info.SkillInfo.AtlasName , _Info.SkillInfo.SpriteName)

   local SkillData = SkillData.GetSkillDataCf(tonumber(_Info.SkillInfo.SkillId))
  -- GameMain.Print(SkillData , "SkillData")
   local Descrip = SkillBuffDescrip.GetSkillDescrip(_Info.SkillInfo.SkillLevel , _Info.SkillInfo.SkillQuality , SkillData)
   UIPopPanel.SkillPanel.transform:FindChild("SkillDescrip"):GetComponent("UILabel").text = Descrip
end

function UIPopPanel:CloseSkillPanel()
   if UIPopPanel.SkillPanel~=nil then
      UIPopPanel.SkillPanel.gameObject:SetActive(false)
   end
   this:CloseUIPopPanel()
end

--��ǩ��ʾ���
UIPopPanel.ResignPanel = nil
UIPopPanel.ResignDays = 0
function UIPopPanel:PopResignPanel(_ResignData)
   if UIPopPanel.ResignPanel==nil then
      MainGameUI.CreateLittleItem("ResignPanel" , "ResignPanel" , UIPopPanel.UIPopPanelGob , _ResignData , this.CreateResignPanel , "UIPopPanel")
   else
      this:CreateResignPanel(UIPopPanel.ResignPanel , _ResignData) 
   end
end

function UIPopPanel:CreateResignPanel(_Gob , _Info)
   _Gob.gameObject:SetActive(true)
   UIPopPanel.ResignDays = _Info
   UIPopPanel.ResignPanel = _Gob
   UIPopPanel.ResignPanel.transform:FindChild("Descrip"):GetComponent("UILabel").text = UIstring.ResignTip..tostring(UIPopPanel.ResignDays)..UIstring.AntCi
   UIPopPanel.ResignPanel.transform:FindChild("ResignOne"):FindChild("DiamondNum"):GetComponent("UILabel").text = tostring(99)
   UIPopPanel.ResignPanel.transform:FindChild("ResignN"):FindChild("DiamondNum"):GetComponent("UILabel").text = tostring(99*UIPopPanel.ResignDays)
   UIPopPanel.ResignPanel.transform:FindChild("ResignN"):FindChild("Word"):GetComponent("UILabel").text = UIstring.Resign..tostring(UIPopPanel.ResignDays)..UIstring.AntCi
end

function UIPopPanel:CloseResignPanel()
   if UIPopPanel.ResignPanel~=nil then
      UIPopPanel.ResignPanel.gameObject:SetActive(false)
   end
   this:CloseUIPopPanel()
end


--��Ʒ��ϸ˵��
UIPopPanel.ItemInfoPanel = nil
function UIPopPanel:PopItemInfoPanel(_ItemData)
   if UIPopPanel.ItemInfoPanel==nil then
      MainGameUI.CreateLittleItem("ItemInfoPanel" , "ItemInfoPanel" , UIPopPanel.UIPopPanelGob , _ItemData , this.CreateItemInfoPanel , "UIPopPanel")
   else
      this:CreateItemInfoPanel(UIPopPanel.ItemInfoPanel , _ItemData) 
   end
end

function UIPopPanel:CreateItemInfoPanel(_Gob , _Info)
   if _Info~=nil then
      _Gob.gameObject:SetActive(true)
      UIPopPanel.ItemInfoPanel = _Gob
      UIPopPanel.ItemInfoPanel.transform:FindChild("ItemInfo"):FindChild("ItemName"):GetComponent("UILabel").text = _Info.Name
      UIPopPanel.ItemInfoPanel.transform:FindChild("ItemInfo"):FindChild("Descrip"):GetComponent("UILabel").text = _Info.Descrip
      local _Sprite = UIPopPanel.ItemInfoPanel.transform:FindChild("ItemHead"):FindChild("ItemIcon"):FindChild("ItemIMG"):GetComponent("UISprite")
      AtlasMsg.SetAtlas(_Sprite , _Info.AtlasName , _Info.SpriteName)
      UIPopPanel.ItemInfoPanel.transform:FindChild("ItemHead"):FindChild("ItemIcon"):FindChild("ItemFg"):GetComponent("UISprite").spriteName = UIstring.ItemFg[_Info.Quality]

      UIPopPanel.ItemInfoPanel.transform:FindChild("ItemHead"):FindChild("ItemIcon"):FindChild("ItemDebris").gameObject:SetActive(false)
      if _Info.ItemType==2 then 
         UIPopPanel.ItemInfoPanel.transform:FindChild("ItemHead"):FindChild("ItemIcon"):FindChild("ItemDebris").gameObject:SetActive(true)
      end

   end
end

function UIPopPanel:CloseItemInfoPanel()
   if UIPopPanel.ItemInfoPanel~=nil then
      UIPopPanel.ItemInfoPanel.gameObject:SetActive(false)
   end
   this:CloseUIPopPanel()
end

--ѡ������� ȷ�� ȡ��
UIPopPanel.ChoseRulePanel = nil
function UIPopPanel:PopChoseRulePanel(_Data)
   if UIPopPanel.ChoseRulePanel==nil then
      MainGameUI.CreateLittleItem("ChoseRulePanel" , "ChoseRulePanel" , UIPopPanel.UIPopPanelGob , _Data , this.CreateChoseRulePanel , "UIPopPanel")
   else
      this:CreateChoseRulePanel(UIPopPanel.ChoseRulePanel , _Data) 
   end
end

function UIPopPanel:CreateChoseRulePanel(_Gob , _Info)
   if _Info~=nil then
      _Gob.gameObject:SetActive(true)
      UIPopPanel.ChoseRulePanel = _Gob     
      UIPopPanel.ChoseRulePanel.transform:FindChild("Descrip"):GetComponent("UILabel").text = _Info.Descrip
   end
end

function UIPopPanel:CloseChoseRulePanel()
   if UIPopPanel.ChoseRulePanel~=nil then
      UIPopPanel.ChoseRulePanel.gameObject:SetActive(false)
   end
   this:CloseUIPopPanel()
end

--�������
UIPopPanel.NetErrorPanel = nil
function UIPopPanel:PopNetErrorPanel(_Data)
   if UIPopPanel.NetErrorPanel==nil then
      MainGameUI.CreateLittleItem("NetErrorPanel" , "NetErrorPanel" , UIPopPanel.UIPopPanelGob , _Data , this.CreateNetErrorPanel , "UIPopPanel")
   else
      this:CreateNetErrorPanel(UIPopPanel.NetErrorPanel , _Data) 
   end
end

function UIPopPanel:CreateNetErrorPanel(_Gob , _Info)
   if _Info~=nil then
      _Gob.gameObject:SetActive(true)
      LoadingPanel.StopLoadingGamePanel() 
      UIPopPanel.NetErrorPanel = _Gob     
      UIPopPanel.NetErrorPanel.transform:FindChild("Descrip"):GetComponent("UILabel").text = _Info.Descrip
      UIPopPanel.NetErrorPanel.transform.localPosition = Vector3(0 , 0 , -2000)
   end
end

function UIPopPanel:CloseNetErrorPanel()
   if UIPopPanel.NetErrorPanel~=nil then
      UIPopPanel.NetErrorPanel.gameObject:SetActive(false)
   end
   this:CloseUIPopPanel()
end

function UIPopPanel:UIHand(_LuaName , _Gob)
       if _Gob~=nil then
          if _Gob.name=="UseOne" then  --ʹ�õ��� 
            if UIPopPanel.CallBack~=nil then
                local data = 
                {
                    Item = UIPopPanel.UseItem,
                    Num = 1,
                }
                UIPopPanel.CallBack(data)
             end
             this:CloseUseItemPanel()
	      end 
       
          if _Gob.name=="UseMore" then             
             this:PopUseMoreItemPanel()
          end

          if _Gob.name=="LeftPovin" then
             this:SetLeftNum()
          end

          if _Gob.name=="RightPovin" then
             this:SetRightNum()
          end

          if _Gob.name=="UseItem" then                                             
             if UIPopPanel.CallBack~=nil then
                local data =
                {
                   Item = UIPopPanel.UseItem,
                   Num = UIPopPanel.UseItemNum,
                }
                UIPopPanel.CallBack(data)
                UIPopPanel.CallBack = nil
             end
             this:CloseUseItemPanel()
          end

          if _Gob.name=="UseMorePanel" then
             this:CloseUseMorePanel()
          end

          if _Gob.name=="CloseUseItemButton" then
             this:CloseUseItemPanel()
	      end            

          --����������
          if _Gob.name=="MaterialBuyButton" then
             if UIPopPanel.CallBack~=nil then
                local data =
                {
                   Num = UIPopPanel.BuyNum,
                }
                UIPopPanel.CallBack(data)
                UIPopPanel.CallBack = nil
             end
             this:CloseBuyMorePanel()
          end

          if _Gob.name=="LeftMaterialPovin" then
             this:SetMaterialLeftNum()
          end

          if _Gob.name=="RightMaterialPovin" then
             this:SetMaterialRightNum()
          end

          if _Gob.name=="BuyMoreMaterialPanel" then
             this:CloseBuyMorePanel()
          end
            
          --�������水ť�¼�
          
          if _Gob.name=="FightButton" then
             if UIPopPanel.CallBack~=nil then
                UIPopPanel.CallBack()
                UIPopPanel.CallBack = nil
             end
             if _Gob.transform.parent~=nil then  
                local key = tonumber(_Gob.transform.parent.name)
                this:OpenMap(key)
                this:CloseProductionPanel()
             end
          end

          if _Gob.name=="CloseProductionButton" then
             this:CloseProductionPanel()
          end

          --�����������
          if _Gob.name == "CloseSkillInfoButton" then
              this:CloseSkillPanel()
          end


          --��ǩ��ʾ
          if _Gob.name == "CloseResignPanelButton" then
             this:CloseResignPanel()
          end       
          if _Gob.name == "ResignOne" then
             if UIPopPanel.CallBack~=nil then
                UIPopPanel.CallBack(1)
                UIPopPanel.CallBack = nil
             end
             this:CloseResignPanel()
          end
          if _Gob.name == "ResignN" then
             if UIPopPanel.CallBack~=nil then
                UIPopPanel.CallBack(UIPopPanel.ResignDays)
                UIPopPanel.CallBack = nil
             end
             this:CloseResignPanel()
          end
           
          --������Ϣ���
          if _Gob.name == "CloseItemInfoButton" then
             this:CloseItemInfoPanel()
          end

          if _Gob.name == "ItemInfoPanel" then
             this:CloseItemInfoPanel()
          end

          --ѡ�����˵�����
          if _Gob.name == "SureButton" then
             UIPopPanel.CallBack()
             UIPopPanel.CallBack = nil
             this:CloseChoseRulePanel()
          end

          if _Gob.name == "CancelButton" then
             UIPopPanel.CallBack = nil
             this:CloseChoseRulePanel()
          end 

          --����������
          if _Gob.name == "SureNet" then
             UIPopPanel.CallBack()
             UIPopPanel.CallBack = nil
             LoadingPanel.StopLoadingPanel()
             LoadingPanel.StopLoadingBigPanel()
             this:CloseNetErrorPanel()
          end

          if _Gob.name == "CloseNetErrorButton" then
             UIPopPanel.CallBack()
             UIPopPanel.CallBack = nil
             LoadingPanel.StopLoadingPanel()
             LoadingPanel.StopLoadingBigPanel()
             this:CloseNetErrorPanel()
          end
	   end
end

function UIPopPanel:ClosePanel()
    if UIPopPanel.BuySta_EnergyPanel~=nil then

    end
    if UIPopPanel.BuyDiamondPanel~=nil then

    end
    if UIPopPanel.BuyCoinPanel~=nil then

    end
    this:CloseUseItemPanel()
    this:CloseUseMorePanel()
    this:CloseBuyMorePanel()
    this:CloseProductionPanel()
    this:CloseSkillPanel()
    this:CloseResignPanel()
    this:CloseItemInfoPanel()
    this:CloseChoseRulePanel()

    this:InitMainUI()
end

function UIPopPanel.UpdatePanel(deletime)
   if UIPopPanel.State==1 then
		UIPopPanel.NowTime = UIPopPanel.NowTime + deletime
		local beilv = UIPopPanel.NowTime/UIPopPanel.TotalTime
		local MoveY = Mathf.Lerp(UIPopPanel.NowY , UIPopPanel.TarY ,beilv)
        UIPopPanel.TipWord.transform.localPosition = Vector3(UIPopPanel.TipWord.transform.localPosition.x , MoveY , UIPopPanel.TipWord.transform.localPosition.z)
		if UIPopPanel.NowTime >= UIPopPanel.TotalTime then
			UIPopPanel.NowTime = 0
			UIPopPanel.State = 0
            UIPopPanel.TipWord.gameObject:SetActive(false)
            this:CloseUIPopPanel()
		end
	end

    if UIPopPanel.PopState==1 then
       UIPopPanel.PopNowTime = UIPopPanel.PopNowTime + deletime
       if UIPopPanel.PopNowTime >= UIPopPanel.PopPropTotalTime then        
          UIPopPanel.PopNumber = UIPopPanel.PopNumber + 1     
          if UIPopPanel.PopNumber<=#UIPopPanel.PopList then
             UIPopPanel.GobNumber = UIPopPanel.GobNumber + 1
             this:PopProp(UIPopPanel.GobNumber , UIPopPanel.PopNumber)
             if UIPopPanel.GobNumber==6 then
                UIPopPanel.GobNumber = 1
                this:CloseUIPopPanel()
             end   
          else
             UIPopPanel.PopState = 0
          end                 
          UIPopPanel.PopNowTime = 0          
       end
    end
end

function UIPopPanel:CloseUIPopPanel()
   UIPopPanel.UIPopPanelGob.gameObject:SetActive(false)
end

function UIPopPanel:ReleasPanel()               				 --������Ϸʱ�ͷźͽ����ʼ��
	GameMain.DelUpdateLua(this.UpdatePanel)

    UIPopPanel.UIPopPanelGob = nil

    UIPopPanel.NowTime = 0
    UIPopPanel.TotalTime = 1
    UIPopPanel.State = 0
    UIPopPanel.NowX = 0
    UIPopPanel.TarX = 0

    UIPopPanel.PopNowTime = 0
    UIPopPanel.PopPropTotalTime = 0.5
    UIPopPanel.PopState = 0
    UIPopPanel.PopNumber = 1
    UIPopPanel.GobNumber = 1
    UIPopPanel.PopList = nil

    UIPopPanel.TipWord = nil
    UIPopPanel.PropChangePanel = nil

    UIPopPanel.CallBack = nil
    UIPopPanel.BuySta_EnergyPanel = nil

    UIPopPanel.UseItemPanel = nil
    UIPopPanel.UseItem = nil
    UIPopPanel.UseMoreItemPanel = nil                                                                            
    UIPopPanel.UseItemNum = 1

    UIPopPanel.BuyDiamondPanel = nil
    UIPopPanel.BuyCoinPanel = nil

    UIPopPanel.BuyMorePanel = nil                                                       
    UIPopPanel.BuyNum = 0
    UIPopPanel.BuyMoreItem = nil

    UIPopPanel.ProductionPanel = nil
    UIPopPanel.ProductionList = {}

    UIPopPanel.SkillPanel = nil

    UIPopPanel.ResignPanel = nil
    UIPopPanel.ResignDays = 0

    UIPopPanel.ItemInfoPanel = nil

    UIPopPanel.ChoseRulePanel = nil
    UIPopPanel.NetErrorPanel = nil
end


return UIPopPanel