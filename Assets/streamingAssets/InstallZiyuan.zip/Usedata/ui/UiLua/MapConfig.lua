﻿MapConfig = {}                                                            
MapConfig.MapConfig = {}
function MapConfig.IniSome()

	local theDB = configDB.Ins.theDB;
	local sqReader = theDB:ReadFullTable("LevelMap")
	while (sqReader:Read() ~= false) 
	do
        local _DBid = sqReader:GetInt32(0)
        MapConfig.MapConfig[_DBid] = {        
            Id = sqReader:GetInt32(0),                        --ID                                  
            Name = sqReader:GetString(1),                     --名字  
            Type = sqReader:GetInt32(2),                  --模型名字
            Turn = sqReader:GetInt32(3),                     --生命
            Descrip = sqReader:GetString(4),                   --攻击参数
            Chapter_Id = sqReader:GetInt32(5),                --移动速度
            Strenth = sqReader:GetInt32(6),              --攻击速度
            Reward = sqReader:GetString(7),                  --防御速度
            Music = sqReader:GetString(8),               --攻击类型
            Scene = sqReader:GetString(9),             --警戒范围
            Config = sqReader:GetString(10),                 --人物类型
            Map_Length = sqReader:GetInt32(11),               --人物系别
            Map_Wide = sqReader:GetInt32(12),                --进阶材料
            My_Pos = sqReader:GetInt32(13),             --材料数量
            Ememy_Pos = sqReader:GetInt32(14),                    --头像
            MyCamp_Id = sqReader:GetInt32(15),                   --类型1
            MyCamp_PosX = sqReader:GetInt32(16),                --普攻技能
            MyCamp_PosZ = sqReader:GetInt32(17),                 --携带技能
            EnemyCamp_Id = sqReader:GetInt32(18),                 --携带技能
            EnemyCamp_PosX = sqReader:GetInt32(19),                 --携带技能
            EnemyCamp_PosZ = sqReader:GetInt32(20),                 --携带技能
		}
    end
end

function MapConfig.GetMapConfigById(_Id)
    if MapConfig.MapConfig[tonumber(_Id)]~=nil then
       return MapConfig.MapConfig[tonumber(_Id)]
    end
    Debug.LogError("数据库LevelMap配置错误id:")
    Debug.LogError(_Id)
    return nil
end

function  MapConfig.GetMapConfigData()
    
    return MapConfig.MapConfig

end

return MapConfig