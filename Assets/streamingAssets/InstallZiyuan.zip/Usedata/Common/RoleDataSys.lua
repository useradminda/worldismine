RoleDataSys = {}

function RoleDataSys.GetRoleById(_Id)

   if RoleDataConfig.GetRoleById(_Id)~=nil then
      return RoleDataConfig.GetRoleById(_Id)
   end
   return nil

end

function RoleDataSys.CreateSolider(_Dbid , _Lvl , _QualityLvl , _IsActive) --
       
   local lua = GameMain.requireLuaFile("Role")
   local rolebaby = lua:new()
   local _RoleDBdata = RoleDataSys.GetRoleById(_Dbid)
   rolebaby:Init(_RoleDBdata , _Lvl , _QualityLvl , nil , _IsActive)
   return rolebaby

end

function RoleDataSys.CreateHero(_Dbid , _Lvl , _UUID)

   local lua = GameMain.requireLuaFile("Role")
   local rolebaby = lua:new()
   local _RoleDBdata = RoleDataSys.GetRoleById(_Dbid)
   rolebaby:Init(_RoleDBdata , _Lvl , nil , _UUID , 1)
   return rolebaby

end

return RoleDataSys