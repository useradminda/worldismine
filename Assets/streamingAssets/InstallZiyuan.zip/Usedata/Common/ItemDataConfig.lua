--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
ItemDataConfig={}
ItemDataConfig.ItemData={}

function ItemDataConfig.IniSome()
	local theDB = configDB.Ins.theDB;
	local sqReader = theDB:ReadFullTable("Item")
	while (sqReader:Read()~=false) do
		local id=sqReader:GetInt32(0)
		ItemDataConfig.ItemData[id]=
		{
			Id=id,
			Name=sqReader:GetString(1),
			Description=sqReader:GetString(2),
			Icon=sqReader:GetString(3),
			Quality=sqReader:GetInt32(4),--品质
			Type=sqReader:GetInt32(5),--类型
			Layer_count=sqReader:GetInt32(6),
			Is_Sell=sqReader:GetInt32(7),--能否被出售 int 1-可以，0-不行
			Price=sqReader:GetInt32(8),
			Is_Visible=sqReader:GetInt32(9),--背包是否可见 1可以0不可以
			Using=sqReader:GetInt32(10),
			IsUse=sqReader:GetInt32(11)
		}
		
	end
end
function ItemDataConfig.GetItemDBConfig(id)
	if ItemDataConfig.ItemData[tonumber(id)]~=nil then
		return ItemDataConfig.ItemData[tonumber(id)]
	end

	Debug.LogError("Item表配置错误ID:")
    Debug.LogError(id)
    return nil
end


return ItemDataConfig
--endregion