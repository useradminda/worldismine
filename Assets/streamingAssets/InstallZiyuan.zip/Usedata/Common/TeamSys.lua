TeamSys = {}
TeamSys.PveHeroList = {}
TeamSys.PveSoliderList = {}
TeamSys.Limit = nil

function TeamSys.UpPveHero(_Role)                           --����Ӣ��
    table.insert(TeamSys.PveHeroList , #TeamSys.PveHeroList + 1 , _Role) 
end

function TeamSys.SaveTheTeam()
   local Pos = ""
   for i = 1 , #TeamSys.PveHeroList , 1 do
       if i==1 then
          Pos = tostring(i).."_"..TeamSys.PveHeroList[i].UUID
       else
          Pos = Pos.."/"..tostring(i).."_"..TeamSys.PveHeroList[i].UUID
       end     
   end
   local info = "1,"..Pos
   WebEvent.SavePveHeros(info , "TeamSys.SavePveHerosCallBack" , TeamSys.SavePveHerosCallBack)
end

function TeamSys.SavePveHerosCallBack(data , _returnId)
    if _returnId==0 then
       
    elseif _returnId==1 then

    end
end

function TeamSys.ComminfoCallBack(_data)
   for key , value in pairs(_data) do
        local ID = tonumber(key)
        if ID~=nil then
           local _Type = tonumber(value["type"])
           local _TeamInfo = tostring(value["value"])
           if _Type==1 then
              local _TeamList = GameMain.StringSplit(_TeamInfo , ",")
              local _TeamInfoList = GameMain.StringSplit(_TeamList[2] , "/") 
              for i = 1 , #_TeamInfoList , 1 do
                  local _Team = GameMain.StringSplit(_TeamInfoList[i] , "_")
                  local _Pos = tonumber(_Team[1])
                  local _UUID = tostring(_Team[2])
                  local _Hero = HeroPackageSys.GetOneHeroBy_UUID(_UUID)
                  _Hero.IsUp = true
                  table.insert(TeamSys.PveHeroList , #TeamSys.PveHeroList + 1 , _Hero) 
              end
           end
        end
    end
end

function TeamSys.GetPveHeros()
    return TeamSys.PveHeroList
end

function TeamSys.GetPveSoliders()
    TeamSys.PveSoliderList = {}
    for i = 1 , #SoliderPackageSys.Soliders , 1 do
        if SoliderPackageSys.Soliders[i].isActivated==1 then
           table.insert(TeamSys.PveSoliderList , #TeamSys.PveSoliderList + 1 , SoliderPackageSys.Soliders[i])  
        end
    end
    return TeamMakeSys.PveSoliderList
end

TeamSys.PvpTeamInfo = {}
TeamSys.NowTeamPvp = 0
function TeamSys.SetPvpHeroInfo(_UpHeros , _TypeTeam)
   if TeamSys.PvpTeamInfo[_TypeTeam]==nil then
      TeamSys.PvpTeamInfo[_TypeTeam] = {}     
   end
   TeamSys.PvpTeamInfo[_TypeTeam] = {}

   for key , value in pairs(_UpHeros) do
       local data = 
       {
          PvpHeroUUID = value.HeroData.UUID,
          PvpSoldierId = value.SoldierId,
          PosX = value.X,
          PosY = value.Y,
       }
       table.insert(TeamSys.PvpTeamInfo[_TypeTeam] , #TeamSys.PvpTeamInfo[_TypeTeam] + 1 , data)  
   end
   
end

function TeamSys.SetPvpTeamType(_TeamType)
   TeamSys.NowTeamPvp = _TeamType
end

function TeamSys.SavePvpTeam()
   local Pos = ""
   for key , value in pairs(TeamSys.PvpTeamInfo) do
       for i = 1 , #value , 1 do
           if i == 1 then
              Pos =Pos..tostring(key).."="..tostring(value[i].PvpHeroUUID).."_"..tostring(value[i].PvpSoldierId).."_"..tostring(value[i].PosX).."_"..tostring(value[i].PosY)
           else
              Pos = Pos.."/"..tostring(value[i].PvpHeroUUID).."_"..tostring(value[i].PvpSoldierId).."_"..tostring(value[i].PosX).."_"..tostring(value[i].PosY)
           end
           Pos = Pos.."#"
       end
   end
   Pos = "2,"..Pos
end

TeamSys.PvpTeamList = {}
function TeamSys.GetPvpTeam()
   TeamSys.PvpTeamList = {} 
   if TeamSys.PvpTeamInfo[TeamSys.NowTeamPvp]~=nil then
       local _PvpTeam = TeamSys.PvpTeamInfo[TeamSys.NowTeamPvp]
       for i = 1 , #_PvpTeam , 1 do
           local _PvpHeroInfo = _PvpTeam[i]
           local _HeroUUID = _PvpHeroInfo.PvpHeroUUID
           local _Hero = HeroPackageSys.GetOneHeroBy_UUID(_HeroUUID)
           local _HeroPos = TeamSys.GetPvpHeroPos(_PvpHeroInfo.PosX , _PvpHeroInfo.PosY)
           local _Member = TeamSys.GetMemberInfo(_Hero , _HeroPos.X , _HeroPos.Y)
           table.insert(TeamSys.PvpTeamList , #TeamSys.PvpTeamList + 1 , _Member)
           local _SoldierId = _PvpHeroInfo.PvpSoldierId
           local _Soldier = SoliderPackageSys.GetOneSolider(_SoldierId)
           local _SoldierNum = _Soldier.roleData.SoldierNumType
           local _SoldiersPos = TeamSys.GetSoldiersPos(_PvpHeroInfo.PosX , _PvpHeroInfo.PosY , _SoldierNum)
           for i = 1 , #_SoldiersPos , 1 do
               local _SoMember = TeamSys.GetMemberInfo(_Soldier , _SoldiersPos[i].X , _SoldiersPos[i].Y)
               table.insert(TeamSys.PvpTeamList , #TeamSys.PvpTeamList + 1 , _SoMember)
           end
       end
     if #_PvpTeam == 0 then
          local data = 
          {
              RoleDbid = 10011,
              PosX = 15,
              PosY = 15,
              Lvl = 1,
              QualityLvl = 1,
              UUID = "1",
              Nowsitzuoqipname = "",
          }
          table.insert(TeamSys.PvpTeamList , #TeamSys.PvpTeamList + 1 , data)

          for i = 1 , 10 , 1 do
              local data = 
              {
                  RoleDbid = 50011,
                  PosX = 15 - i,
                  PosY = 15 - i,
                  Lvl = 1,
                  QualityLvl = 1,
                  UUID = "0",
                  Nowsitzuoqipname = "",
              }
              table.insert(TeamSys.PvpTeamList , #TeamSys.PvpTeamList + 1 , data)
          end
      end
   end
   
   return TeamSys.PvpTeamList
end

function TeamSys.GetMemberInfo(_Hero , _PosX , _PosY)
   local data = 
   {
      RoleDbid = _Hero.Dbid,
      PosX = _PosX,
      PosY = _PosY,
      Lvl = _Hero.lvl,
      QualityLvl = _Hero.qualityLvl,
      UUID = _Hero.UUID,
      Nowsitzuoqipname = "",
   }
   return data
end


function TeamSys.GetPvpHeroPos(_PosX , _PosY)
   local HeroPos = 
   {
      X = _PosX + 2,
      Y = _PosY - 1,
   }
   return HeroPos
end

function TeamSys.GetSoldiersPos(_PosX , _PosY , _SoldierNum)
   local SoldiersPos = 
   {

   }
  Debug.LogError(_SoldierNum)
   if _SoldierNum==1 then                               --Ӣ��
      SoldiersPos[1] = {}
      SoldiersPos[1] = 
      {
        X = _PosX + 2,
        Y = _PosY - 1,
      }
   elseif _SoldierNum==2 then
      for i = 1 , _SoldierNum , 1 do
          SoldiersPos[i] = {}
      end
      SoldiersPos[1] = 
      {
          X = _PosX - 3,
          Y = _PosY,
      }
      SoldiersPos[2]  =
      {
          X = _PosX - 3,
          Y = _PosY - 2,
      } 
   elseif _SoldierNum==4 then
      for i = 1 , _SoldierNum , 1 do
          SoldiersPos[i] = {}
      end
      SoldiersPos[1] = 
      {
          X = _PosX - 1,
          Y = _PosY,
      }
      SoldiersPos[2]  =
      {
          X = _PosX - 1,
          Y = _PosY - 2,
      }
      SoldiersPos[3]  =
      {
          X = _PosX - 3,
          Y = _PosY ,
      }
      SoldiersPos[4]  =
      {
          X = _PosX - 3,
          Y = _PosY - 2,
      }
   elseif _SoldierNum==8 then
      for i = 1 , _SoldierNum , 1 do
          SoldiersPos[i] = {}
      end
      SoldiersPos[1] = 
      {
          X = _PosX,
          Y = _PosY + 1,
      }
      SoldiersPos[2]  =
      {
          X = _PosX,
          Y = _PosY,
      }
      SoldiersPos[3]  =
      {
          X = _PosX,
          Y = _PosY - 1,
      }
      SoldiersPos[4]  =
      {
          X = _PosX,
          Y = _PosY - 2,
      }
      SoldiersPos[5] = 
      {
          X = _PosX - 2,
          Y = _PosY + 1,
      }
      SoldiersPos[6]  =
      {
          X = _PosX - 2,
          Y = _PosY,
      }
      SoldiersPos[7]  =
      {
          X = _PosX - 2,
          Y = _PosY - 1,
      }
      SoldiersPos[8]  =
      {
          X = _PosX - 2,
          Y = _PosY - 2,
      }
   end
   return SoldiersPos
end

return TeamSys