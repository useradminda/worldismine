--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
EquipDataConfig={}
EquipDataConfig.EquipData={}

function EquipDataConfig.IniSome()
	local theDB = configDB.Ins.theDB;
	local sqReader = theDB:ReadFullTable("Equip")
	while (sqReader:Read()~=false) do
		local id=sqReader:GetInt32(0)
		EquipDataConfig.EquipData[id]={
			Id=id,--编号
			Name=sqReader:GetString(1),--名称
			Type=sqReader:GetInt32(2),--类型  1-武器;2-头盔;3-胸甲;4-护腕;5-鞋子;6-披风;7-护符;8-戒指
			Quality=sqReader:GetInt32(3),--品质 1-白;2-绿;3-青;4-紫;5-金;6-橙;7-红
			Star=sqReader:GetInt32(4),--星级
			UpgradeAtt=sqReader:GetString(5),--强化攻击(基础值,等级增加值)
			UpgradeHp=sqReader:GetString(6),--强化生命(基础值,等级增加值)
			UpgradeSpeed=sqReader:GetString(7),--强化攻速(基础值,等级增加值)
			
			RefineAtt=sqReader:GetString(8),--洗练攻击
			RefineHp=sqReader:GetString(9),--洗练生命
			RefineSpeed=sqReader:GetString(10),--洗练攻速
			IsRecast=sqReader:GetInt32(11),--能否重铸
			IsRefine=sqReader:GetInt32(12),--能否洗练
			IsSell=sqReader:GetInt32(13),--能否出售
			Price=sqReader:GetInt32(14),--购买价格
			Sell=sqReader:GetInt32(15),--出售价格
			Recast_To_Id=sqReader:GetString(16),--重铸目标
			Recast_Resource=sqReader:GetString(17),--重铸材料(ID，数量)
}
			
			local _upgradeAtt=GameMain.StringSplit(EquipDataConfig.EquipData[id].UpgradeAtt)
			EquipDataConfig.EquipData[id].UpgradeAttBasicValue=_upgradeAtt[1]
			EquipDataConfig.EquipData[id].UpgradeAttAddValue=_upgradeAtt[2]

			local _upgradeHp=GameMain.StringSplit(EquipDataConfig.EquipData[id].UpgradeHp)
			EquipDataConfig.EquipData[id].UpgradeHpBasicValue=_upgradeHp[1]
			EquipDataConfig.EquipData[id].UpgradeHpAddValue=_upgradeHp[2]

			local _upgradeSpeed=GameMain.StringSplit(EquipDataConfig.EquipData[id].UpgradeSpeed)
			EquipDataConfig.EquipData[id].UpgradeSpeedBasicValue=_upgradeSpeed[1]
			EquipDataConfig.EquipData[id].UpgradeSpeedAddValue=_upgradeSpeed[2]

			local _recastResource=GameMain.StringSplit(EquipDataConfig.EquipData[id].Recast_Resource)
			EquipDataConfig.EquipData[id].Recast_ResourceID=_recastResource[1]
			EquipDataConfig.EquipData[id].Recast_ResourceCount=_recastResource[2]
			
			
	end
end

function EquipDataConfig.GetEquipDBConfig(id)
	if EquipDataConfig.EquipData[tonumber(id)]~=nil then
       return EquipDataConfig.EquipData[tonumber(id)]
    end
    Debug.LogError("equip表配置错误ID:")
    Debug.LogError(id)
    return nil
end

return EquipDataConfig

--endregion
