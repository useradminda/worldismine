CalculateRoleProp = {}

CalculateRoleProp.Prop =
{
    Life = 0,
    Attack = 0,
    AttackSpeed = 0,
    MoveSpeed = 0,
    Defence = 0,
}

function CalculateRoleProp.CalculatProp(_Id , _Lvl , _QualityLvl)
    local data = 
    {    
    }
    local _RoleProp = RoleDataSys.GetRoleById(_Id)
    local _life = tonumber(_RoleProp.LifeList[1]) + _QualityLvl*tonumber(_RoleProp.LifeList[2]) + tonumber(_RoleProp.LifeList[3]) + _Lvl*tonumber(_RoleProp.LifeList[4])
    local _Attack = tonumber(_RoleProp.AttackList[1]) + _QualityLvl*tonumber(_RoleProp.AttackList[2]) + tonumber(_RoleProp.AttackList[3]) + _Lvl*tonumber(_RoleProp.AttackList[4])   
    local TempAttackSpeed = tonumber(_RoleProp.AttackSpeedList[1]) + _QualityLvl*tonumber(_RoleProp.AttackSpeedList[2]) + tonumber(_RoleProp.AttackSpeedList[3]) + _Lvl*tonumber(_RoleProp.AttackSpeedList[4])
    local _AttackSpeed = 0
    if TempAttackSpeed==0 then
       _AttackSpeed = 0
    else
       _AttackSpeed = TempAttackSpeed
    end
    local _MoveSpeed = tonumber(_RoleProp.MoveSpeedList[1]) + _QualityLvl*tonumber(_RoleProp.MoveSpeedList[2]) + tonumber(_RoleProp.MoveSpeedList[3]) + _Lvl*tonumber(_RoleProp.MoveSpeedList[4])
    local _Defence = tonumber(_RoleProp.DefenceList[1]) + _QualityLvl*tonumber(_RoleProp.DefenceList[2]) + tonumber(_RoleProp.DefenceList[3]) + _Lvl*tonumber(_RoleProp.DefenceList[4])
    data.life = _life
    data.Attack = _Attack
    data.AttackSpeed = _AttackSpeed
    data.MoveSpeed = _MoveSpeed
    data.Defence = _Defence
    return data
end

function CalculateRoleProp.CalculatHeroProp(_Id , _Lvl , _QualityLvl)
    local data = 
    {    
    }
    local _RoleProp = RoleDataSys.GetRoleById(_Id)
    local _life = tonumber(_RoleProp.LifeList[1]) + _QualityLvl*tonumber(_RoleProp.LifeList[2]) + tonumber(_RoleProp.LifeList[3]) + _Lvl*tonumber(_RoleProp.LifeList[4])
    local _Attack = tonumber(_RoleProp.AttackList[1]) + _QualityLvl*tonumber(_RoleProp.AttackList[2]) + tonumber(_RoleProp.AttackList[3]) + _Lvl*tonumber(_RoleProp.AttackList[4])   
    local TempAttackSpeed = tonumber(_RoleProp.AttackSpeedList[1]) + _QualityLvl*tonumber(_RoleProp.AttackSpeedList[2]) + tonumber(_RoleProp.AttackSpeedList[3]) + _Lvl*tonumber(_RoleProp.AttackSpeedList[4])
    local _AttackSpeed = 0
    if TempAttackSpeed==0 then
       _AttackSpeed = 0
    else
       _AttackSpeed = TempAttackSpeed
    end
    local _MoveSpeed = tonumber(_RoleProp.MoveSpeedList[1]) + _QualityLvl*tonumber(_RoleProp.MoveSpeedList[2]) + tonumber(_RoleProp.MoveSpeedList[3]) + _Lvl*tonumber(_RoleProp.MoveSpeedList[4])
    local _Defence = tonumber(_RoleProp.DefenceList[1]) + _QualityLvl*tonumber(_RoleProp.DefenceList[2]) + tonumber(_RoleProp.DefenceList[3]) + _Lvl*tonumber(_RoleProp.DefenceList[4])
    data.life = _life
    data.Attack = _Attack
    data.AttackSpeed = _AttackSpeed
    data.MoveSpeed = _MoveSpeed
    data.Defence = _Defence
    return data
end

return CalculateRoleProp