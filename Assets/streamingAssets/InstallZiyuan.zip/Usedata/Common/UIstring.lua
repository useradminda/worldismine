UIstring = {}

--[[function UIstring.Init()   
    for key , value in pairs(MutLanguageConfig.MutLanguage) do
        UIstring[key] = value.MutWord      
    end
end--]]

UIstring.Ownerships =
{
   [1] = "[蜀]",
   [2] = "[魏]",
   [3] = "[吴]",
   [4] = "[中立]",
}

UIstring.WordId = {}

UIstring.WordColor =    --"绿","蓝","紫","橙","金"
{    
    [1] = "[00FF0C]",   --绿
    [2] = "[3078F1]",   --蓝
    [3] = "[984AE7]",   --紫
    [4] = "[FF6400]",   --橙
    [5] = "[F4CD0A]",   --金
    [6] = "[9C9C9C]",   --灰色
    [7] = "[F1F1F1]",   --白
    [8] = "[030303]",   --黑色 
}

UIstring.Red = "[FF0000]"
UIstring.Green = "[00FF0C]"
UIstring.PetFrameAtlasName = "UI_HZ_Head_PetFrame1"

UIstring.ItemBabyFg = 
{
    [1] = "kuang_da_lv",
    [2] = "kuang_da_lan",
    [3] = "kuang_da_zi",
    [4] = "kuang_da_cheng",
    [5] = "kuang_da_jin-", 
}

UIstring.ItemXiaoFg = 
{
    [1] = "kuang_xiao_lv",
    [2] = "kuang_xiao_lan",
    [3] = "kuang_xiao_zi",
    [4] = "kuang_xiao_cheng",
    [5] = "kuang_xiao_jin-", 
}

UIstring.ItemFg = 
{
    [1] = "kuang_da_lv",
    [2] = "kuang_da_lan",
    [3] = "kuang_da_zi",
    [4] = "kuang_da_cheng",
    [5] = "kuang_da_jin-", 
}

UIstring.kuang_da_2 = "kuang_da_2"

UIstring.EquipQuality = 
{
    [1] = "普通",
    [2] = "优秀",
    [3] = "精良",
    [4] = "史诗",
    [5] = "传说",
}

UIstring.EquipType = 
{
    [1] = "头盔",
    [2] = "项链",
    [3] = "衣服",
    [4] = "手镯",
    [5] = "武器",
    [6] = "戒指",
    [7] = "鞋子",
    [8] = "翅膀",
}

UIstring.PropName = 
{
    [1] = "生命",
    [2] = "攻击",
    [3] = "防御",
    [4] = "攻速",
    [5] = "移速",
    [6] = "暴击率",
    [7] = "暴击值",
    [8] = "闪避",
    [9] = "CD缩减",
    [10] = "翅膀",
    [24] = "cd缩减",
    [25] = "闪避",
    [26] = "攻击速度",
}

UIstring.PropName2 = 
{
    ["life"] = "生命",
    ["n_attack"] = "攻击",
    ["n_def"] = "防御",
    ["sp"] = "移速",             --移速
    ["crit"] = "暴击率",           --暴击率
    ["critvalue"] ="暴击值" ,      --暴击值
}

UIstring.VipNumSpriteName =
{
    [0] = "vip_0",
    [1] = "vip_1",
    [2] = "vip_2",
    [3] = "vip_3",
    [4] = "vip_4",
    [5] = "vip_5",
    [6] = "vip_6",
    [7] = "vip_7",
    [8] = "vip_8",
    [9] = "vip_9",   
}

UIstring.NumberSpriteName =
{
    [0] = "nub_0",
    [1] = "nub_1",
    [2] = "nub_2",
    [3] = "nub_3",
    [4] = "nub_4",
    [5] = "nub_5",
    [6] = "nub_6",
    [7] = "nub_7",
    [8] = "nub_8",
    [9] = "nub_9",   
}

UIstring.WhenStarIs = "当星级是"
UIstring.WhenLvlIs = "等级是"
UIstring.WhenReflevel = "精炼+"
UIstring.Star = "星"
UIstring.Lvl = "级"
UIstring.NoActived = "(未激活)"
UIstring.Actived = "（已激活）"
UIstring.ActivedWord = "激活"

UIstring.ResignTip = "您最多可以补签"
UIstring.Resign = "补签"

UIstring.AntCi = "次"
UIstring.ItemAnt = "个"
UIstring.RechargeByDay = "每日充值累计"
UIstring.Yuan = "元"
UIstring.OnLineTime = "在线时长"
UIstring.MaxVip = "你是我心中最大滴土豪"
UIstring.NeedRecharge = "再充"

UIstring.Year = "年"
UIstring.Month = "月"
UIstring.Day = "日"

UIstring.Hour = "时"
UIstring.Minit = "分"
UIstring.Second = "秒"

UIstring.Zoon = "区"

UIstring.jjc_1 = "前1000名，每次刷新最高排名都会获得钻石奖励！"
UIstring.jjc_2 = "每晚10点发放竞技场奖励"
UIstring.jjc_3 = "竞技场说明 1、竞技场每次胜利会获得少了声望。。。"

UIstring.dszl_1 = "大师挑战赛每届奖励 第1名：150钻石，48大师币 第2名：130钻石，44大师币 第3名..."
UIstring.dszl_2 = "匹配时间：12到24点 每天20到21点双倍积分"
UIstring.dszl_3 = ""

UIstring.ttboss_1 = "进入等级"
UIstring.ttboss_2 = "深海巨兽 挑战大章鱼可获得大量章鱼碎片，钻石，金币等道具 剩余开启时间01:12:25"
UIstring.ttboss_3 = "1、天天BOSS每日开启2次，12:30和20:30玩家可组队入场挑战BOSS以及胜利后可获得奖励..."
UIstring.ttboss_4 = "BOSS太过强大，但是不要灰心，你的小精灵还在，保卫精灵城就靠你了。"

UIstring.stlboss_1 = ""
UIstring.stlboss_2 = ""

UIstring.nd = ""

UIstring.qjgc_1 = "器具工厂说明 1，器具工厂分为三部分，分布是装备分解，装备还原和商店！ 2，分解装备..."

UIstring.ChoseServer = "请选择服务器"

UIstring.Nothing = "无"

UIstring.Gold = "金币"

UIstring.Life = "生命"
UIstring.Attack = "攻击"

UIstring.HighEggDsc = "最高产出道具和装备"
UIstring.SuperEggDsc = "最高产出道具和装备"

UIstring.OneCoinCall = "20000" --单抽需要多少金币
UIstring.TenCoinCall = "198000" --十抽需要多少金币
UIstring.OneDiamondCall = "280" --单抽钻石
UIstring.TenDiamondCall = "2660" --十抽钻石

UIstring.OneNiu = "扭蛋一次"
UIstring.TenNiu = "扭蛋十次"

UIstring.ChangeName = "是否花费1000钻修改名字!!"
UIstring.VipCanBuy = "当前Vip下您还可以购买"

UIstring.SellEuipsAllTip = "蓝绿装备最好用于装备强化哦，您真的要出售所有蓝绿装备么？"

UIstring.Vip = "Vip"
UIstring.CanBuy = "可以购买"
UIstring.NoLimitBuy = "无限畅购"
UIstring.Libao = "礼包"

UIstring.NetError = "网络错误，请重新登录"
UIstring.CPPNetError = "匹配网络错误，请稍候重试"

UIstring.LoadingDescrip = "会不会玩 , 低俗 , 幼稚"

UIstring.PlayerHeadSpriteName = 
{
    [111001] = "Icon_Headpic_2",
    [111002] = "Icon_Headpic_1",
}

UIstring.PlayerHeadAtlas = "UI_HZ_Hedpic"

UIstring.BossLastTime = "Boss剩余时间"
UIstring.BossOpenTime = "Boss即将开放"

UIstring.BossZhangyuName = "深渊巨兽"
UIstring.BossZhangyuDescrip = "挑战深海大章鱼可以获得大量章鱼碎片、钻石、美女等道具"

UIstring.Sta = "体力"
UIstring.Energy = "精力"
UIstring.Dsb = "大师币"

UIstring.Fight = "战斗力"

UIstring.PlayerBoy = "海战骑士"
UIstring.PlayerGirl = "冒险家"

UIstring.SummonLater = "后免费"
UIstring.Blood = "血石"

UIstring.Get = "获得"

UIstring.Travel = "游客"
UIstring.User = "用户"

UIstring.NoOpen = "(未开启)"
UIstring.OpenEd = "(已开启)"

--[[RolePropCalculate.PropBeilv =
{
    [1] = 1,        --生命
    [2] = 5,        --攻击
    [3] = 3,        --防御
    [4] = 10,       --攻速
    [5] = 0,        --移速
    [6] = 2,        --暴击率
    [7] = 2,        --暴击值
    [8] = 2,        --闪避
    [9] = 0,        --CD缩减
    [10] = 0,
}--]]

UIstring.npc_1_1 = ""
UIstring.npc_1_2 = ""
UIstring.npc_2_1 = ""
UIstring.npc_2_2 = ""
UIstring.npc_3_1 = ""
UIstring.npc_3_2 = ""
UIstring.npc_4_1 = ""
UIstring.npc_4_2 = ""

UIstring.shop1 = ""
UIstring.shop2 = ""
UIstring.shop3 = ""
UIstring.shop4 = ""
UIstring.shop5 = ""
UIstring.shop6 = ""
UIstring.shop7 = ""
UIstring.shop8 = ""

UIstring.A1 = "宝宝不存在"
UIstring.A2 = "材料不足"
UIstring.A3 = "升星失败"
UIstring.A4 = "品质已满"
UIstring.A5 = "等级不足"
UIstring.A6 = "星级已满"
UIstring.A7 = "金币不足"
UIstring.A8 = "等级已满"
UIstring.A9 = "位置错误"

UIstring.B1 = "同类装备不存在"
UIstring.B2 = "该装备不可分解"
UIstring.B3 = "体力不足"
UIstring.B4 = "副本次数不足"
UIstring.B5 = "战斗失败"
UIstring.B6 = "次数不足"
UIstring.B7 = "宝箱未被激活"
UIstring.B8 = "天梯尚未开战"
UIstring.B9 = "对手不存在"

UIstring.C1 = "尚未到免费事件"
UIstring.C2 = "钻石不足"
UIstring.C3 = "邮件不存在"
UIstring.C4 = "没有可领取的邮件"
UIstring.C5 = "BOSS已被击败"
UIstring.C6 = "BOSS战尚未开启"
UIstring.C7 = "好友不存在"
UIstring.C8 = "不能加自己为好友"
UIstring.C9 = "好友数量已满"

UIstring.D1 = "好友不在申请列表"
UIstring.D2 = "没有可领取的精力"
UIstring.D3 = "今日不能再领"
UIstring.D4 = "搜索的好友不存在"
UIstring.D5 = "今日已领取"
UIstring.D6 = "奖励不存在"
UIstring.D7 = "奖励已经领取"
UIstring.D8 = "货币不足"
UIstring.D9 = "小喇叭不足"

UIstring.F1 = "装备等级已满"
UIstring.F2 = "小喇叭不足"
UIstring.F3 = "今日已经领取过签到奖励"
UIstring.F4 = "声望不足"
UIstring.F5 = "存在屏蔽字"
UIstring.F6 = "名字已存在"
UIstring.F7 = "查询的玩家不存在"
UIstring.F8 = "当前技能等级已到顶"
UIstring.F9 = "角色等级不足"

UIstring.G1 = "品质已达到最高"
UIstring.G2 = "背包已满"
UIstring.G3 = "装备等级是主角等级的两倍"
UIstring.G4 = "无法将穿戴的装备当作材料"
UIstring.G5 = "装备不存在"
UIstring.G6 = "没有可以出售的装备了"
UIstring.G7 = "关卡未开启"
UIstring.G8 = "精力不足"
UIstring.G9 = "鼓舞已到上限次数"

UIstring.H1 = "鸡血石不足"
UIstring.H2 = "已申请过该好友"
UIstring.H3 = "已赠送过该好友"
UIstring.H4 = "已领取"
UIstring.H5 = "道具不存在"
UIstring.H6 = "碎片不足"
UIstring.H7 = "该位置没有宝宝 无法上阵"
UIstring.H8 = "无法下阵已经骑行的坐骑"
UIstring.H9 = "该宝宝已经在该位置上阵了"

UIstring.I1 = "无法下阵已经骑行的坐骑"
UIstring.I2 = "该位置没有宝宝 无法坐骑"
UIstring.I3 = "已赠送过该好友"
UIstring.I4 = "已领取"
UIstring.I5 = "道具不存在"
UIstring.I6 = "碎片不足"
UIstring.I7 = "该位置没有宝宝 无法上阵"
UIstring.I8 = "无法下阵已经骑行的坐骑"
UIstring.I9 = "位置已满"

UIstring.J1 = "该物品无法使用"
UIstring.J2 = "账号已被注册"
UIstring.J3 = "账号格式错误"
UIstring.J4 = "注册成功"
UIstring.J5 = "碎片不可出售"
UIstring.J6 = "无法挑战自己"
UIstring.J7 = "血石不足"
UIstring.J8 = "请选择需要分解的装备"
UIstring.J9 = "刷新次数不足"

UIstring.K1 = "超过限时时间无法领取"
UIstring.K2 = "账号已被注册"
UIstring.K3 = "账号格式错误"
UIstring.K4 = "注册成功"
UIstring.K5 = "碎片无法整理"
UIstring.K6 = "无需补签"
UIstring.K7 = "最近未登录"
UIstring.K8 = "请选择服务器"
UIstring.K9 = "无法扫荡非三星副本"

UIstring.L1 = "技能尚未激活"
UIstring.L2 = "任务尚未完成,无法领取"
UIstring.L3 = "技能还未激活"
UIstring.L4 = "请求邀请好友成功"
UIstring.L5 = "您尚未有排行"
UIstring.L6 = "含有非法字符"
UIstring.L7 = "您创建的名字过长"
UIstring.L8 = "领取成功"
UIstring.L9 = "补签成功"

UIstring.M1 = "购买成功"
UIstring.M2 = "Vip等级不足无法购买"
UIstring.M3 = "升级成功"
UIstring.M4 = "精炼成功"
UIstring.M5 = "出售成功"
UIstring.M6 = "赠送精力成功"
UIstring.M7 = "条件不足，无法领取"
UIstring.M8 = "已购买"
UIstring.M9 = "名字不能为空"

UIstring.N1 = "没有可以添加的材料"
UIstring.N2 = "副本暂未开放"
UIstring.N3 = "该玩家已经是好友"
UIstring.N4 = "您当前VIP等级下被限购"
UIstring.N5 = "星数未满"
UIstring.N6 = "已领取过该奖励"
UIstring.N7 = "未上榜"
UIstring.N8 = "敬请期待"
UIstring.N9 = "账户或密码不能为空"

UIstring.O1 = "每日可发送聊天消息次数已达上限"
UIstring.O2 = "发送聊天消息过快"
UIstring.O3 = "大师币不足"
UIstring.O4 = "宝宝等级不能超过主角等级"
UIstring.O5 = "Vip等级不足"
UIstring.O6 = "上次战斗还未结束"
UIstring.O7 = "大师赛15级开放"
UIstring.O8 = "竞技场10级开放"
UIstring.O9 = "特殊副本12级开放"

UIstring.P1 = "技能等级不能超过主角"
UIstring.P2 = "精炼等级已经到顶级"
UIstring.P3 = "战斗掉线 请稍后再匹配"
UIstring.P4 = "账号不存在"
UIstring.P5 = "主角技能升级成功"
UIstring.P6 = "当前VIP等级下购买次数已达上限"
UIstring.P7 = "没有可以分解的装备"
UIstring.P8 = "账号或密码不能为空"
UIstring.P9 = "注册失败"

UIstring.Q1 = "用户名最短5位，最长12位 , 只可使用英文字母、数字和下划线"
UIstring.Q2 = "密码名最短6位，最长16位 , 不可使用中文"
UIstring.Q3 = "通关本章后解锁"
UIstring.Q4 = "充值未开启"
UIstring.Q5 = "精力已满"
UIstring.Q6 = "体力已满"
UIstring.Q7 = "你没有权限开启次任务"
UIstring.Q8 = "你已经开启该特权任务"
UIstring.Q9 = "开启特权任务成功"

UIstring.R1 = "暂未开放"
UIstring.R2 = "Boss已死亡"

UIstring.nanzhujiao_2 = "男主角描述"
UIstring.nvzhujiao_2 = "女主角描述"
return UIstring