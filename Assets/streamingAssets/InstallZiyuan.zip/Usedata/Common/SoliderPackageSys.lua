SoliderPackageSys = {}
SoliderPackageSys.Soliders = {}

function SoliderPackageSys.Init()
    
    local Solider = RoleDataSys.CreateSolider(50011,1,1)
    SoliderPackageSys.Soliders[1] = Solider
    local Solider = RoleDataSys.CreateSolider(50021,1,1)
    SoliderPackageSys.Soliders[2] = Solider
    local Solider = RoleDataSys.CreateSolider(50031,1,1)
    SoliderPackageSys.Soliders[3] = Solider

end

function SoliderPackageSys.GetSoliders()
   return SoliderPackageSys.Soliders
end

function SoliderPackageSys.CreateSolider(_DBid , _Lvl , _QualityLvl , _IsActive)
   local _Solider = RoleDataSys.CreateSolider(_DBid , _Lvl , _QualityLvl , _IsActive)
   table.insert(SoliderPackageSys.Soliders , #SoliderPackageSys.Soliders + 1 , _Solider) 
end

function SoliderPackageSys.GetOneSolider(_DBid)
   for i = 1 , #SoliderPackageSys.Soliders , 1 do
       if SoliderPackageSys.Soliders[i].Dbid == _DBid then
          return SoliderPackageSys.Soliders[i]
       end
   end
   return nil
end

function SoliderPackageSys.ComminfoCallBack(_data)      
     for key , value in pairs(_data) do
        local ID = tonumber(key)
        if ID~=nil then
           local data = value
           local _DBid = tonumber(data["id"])
           local _QualityLvl = tonumber(data["qlv"])
           local _Lvl = tonumber(data["lv"])
           local _isActive = tonumber(data["_isActive"])
           SoliderPackageSys.CreateSolider(_DBid , _Lvl , _QualityLvl , _isActive)
        end
    end
end

return SoliderPackageSys