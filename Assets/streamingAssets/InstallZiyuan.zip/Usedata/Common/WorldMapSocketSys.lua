WorldMapSocketSys = {}

function WorldMapSocketSys.LoginSocketEvent()
   SocketClient.RegistMsgHandle(SocketClient.MsgID.ReceiveMove, WorldMapSocketSys.ReceiveMoveHandle)
   SocketClient.RegistMsgHandle(SocketClient.MsgID.ReceiveCityState, WorldMapSocketSys.ReceiveCityStateHandle)
   SocketClient.RegistMsgHandle(SocketClient.MsgID.ReceiveLogin, WorldMapSocketSys.ReceiveLoginHandle)
end

function WorldMapSocketSys.SendMoveSocketEvent(_Nodes)                                                --�����ƶ�·����
  

   local data = {
        intList = {},
    }
   

   local Count = #_Nodes
   data.intList[1] = Count

   for i = 1 , Count , 1 do
       data.intList[i + 1] = _Nodes[i].NodeId
   end

   GameMain.Print(data)
   SocketClient.SendNetEvent(SocketClient.MsgID.RequestMove, data);
end

function WorldMapSocketSys.ReceiveMoveHandle(_ReceiveMoveData)                                           --������������ƶ�·����
    GameMain.Print(_ReceiveMoveData , "_ReceiveMoveData")

    local intList = _ReceiveMoveData.intList
    local WorldId = tonumber(intList[1])
    local NodeCount = tonumber(intList[2])

    local floatList = _ReceiveMoveData.floatList
    
    local TempTime = floatList[2]
    --local CDTime = tonumber(intList[4])
    
    local NodesData = {}
    for i = 1 , NodeCount , 1 do
        NodesData[i] = intList[2 + i]
    end

    PlayerControl.CreateCharacter(WorldId ,NodesData , TempTime , NodeCount) 
end

function WorldMapSocketSys.ReceiveCityStateHandle(_ReceiveCityData)
   --GameMain.Print(_ReceiveCityData , "_ReceiveCityData")

   local intList = _ReceiveCityData.intList
   local _CityId = tonumber(intList[1])
   local _Owner = tonumber(intList[2])
   local _CityState = tonumber(intList[3])
   local _DefenceNum = tonumber(intList[4])
   local _AttackNum = tonumber(intList[5])

   local data =
   {
      CityId = _CityId,
      Owner = _Owner,
      CityState = _CityState,
      DefenceNum = _DefenceNum,
      AttackNum = _AttackNum,
   }

   WorldMapSys.SetNodeStates(data)
end

function WorldMapSocketSys.ReceiveLoginHandle(_ReceiveLoginData)
   GameMain.Print(_ReceiveLoginData , "_ReceiveLoginData")

   local intList = _ReceiveLoginData.intList
   local PlayerOwner = tonumber(intList[1])

   ClinetInfomation.MyOwner = PlayerOwner
   PlayerControl.TheMeCharacter:SetOwner(ClinetInfomation.MyOwner)

   local Home = WorldMapSys.GetHomeByOwner(ClinetInfomation.MyOwner)
   PlayerControl.TheMeCharacter:SetNodeInfo(Home)
   PlayerControl.TheMeCharacter:SetPos(Home.Pos)

end

return WorldMapSocketSys