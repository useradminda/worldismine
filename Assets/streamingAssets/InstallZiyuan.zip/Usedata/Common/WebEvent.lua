WebEvent = {}
local this = WebEvent


function WebEvent.SendPack(data , _luacname , cb)
	
	data.token = LoginData.token
	data.GameUrl = LoginData.ModelUrl
	data.playerId = LoginData.player_id
	data.luac = _luacname
	
    GameMain.Print(data)

	GameMain.SendPack(data , _luacname , cb)	
end

--创角
function WebEvent.RequirePlayerinfo(info , cbname , cb)												--请求某个玩家的信息

	local data = 
	{
		A = "init",
		M = "Player",	
	}
	
	WebEvent.SendPack(data , cbname , cb)	
	
end

function WebEvent.CreatePlayer(info , cbname , cb)														--创建角色

	local data = 
	{
		A = "create",
		M = "player",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)	

end


--行为树
function WebEvent.RouteNet(info , cbname , cb)														--发送自己的行为树
	
	local data = 
	{
		A = "addAndReturn",
		M = "Route",
		P = info,	
	}
	
	WebEvent.SendPack(data , cbname , cb)	

end

--上阵PVE英雄
function WebEvent.UpPveHero(info , cbname , cb)
    
    local data = 
	{
		A = "setTroop",
		M = "Troop",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)	

end


--整容模块
--[[function WebEvent.SaveTeamMsg(info , cbname , cb)														--保存整容

	local data = 
	{
		A = "setTroop",
		M = "Troop",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)	

end--]]

--宝宝模块
function WebEvent.RequireBabyList(info , cbname , cb)													--请求宝宝列表

	local data = 
	{
		A = "init",
		M = "Mount",
	}
	
	WebEvent.SendPack(data , cbname , cb)	
end

function WebEvent.UpLvl(info , cbname , cb)														     --宝宝升级

	local data = 
	{
		A = "levelUp",
		M = "mount",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)	

end

function WebEvent.UpQuality(info , cbname , cb)														--宝宝升阶

	local data = 
	{
		A = "qualityUp",
		M = "mount",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)	

end

function WebEvent.UpStar(info , cbname , cb)														--宝宝升星

	local data = 
	{
		A = "starUp",
		M = "mount",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)	

end



--装备模块
function WebEvent.UpEquip(info , cbname , cb)                                               --穿装备

    local data = 
	{
		A = "installEquip",
		M = "equip",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)	
end

function  WebEvent.DownEquip(info , cbname , cb)                                            --脱装备
    
    local data = 
	{
		A = "installEquip",
		M = "equip",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)

end

function  WebEvent.UpEquipLvl(info , cbname , cb)                                           --装备升级
    
    local data = 
	{
		A = "levelUp",
		M = "equip",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)
end

function  WebEvent.UpEquipQuality(info , cbname , cb)                                       --装备精炼
    
    local data = 
	{
		A = "refLevelUp",
		M = "equip",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)
end


function WebEvent.SellEquips(info , cbname , cb)                                             --出售装备

    local data = 
	{
		A = "sellEquip",
		M = "equip",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.DecomposeEquips(info , cbname , cb)                                             --出售装备

    local data = 
	{
		A = "splitEquip",
		M = "equip",
		P = info
	}
	
	WebEvent.SendPack(data , cbname , cb)

end

--道具工厂
function WebEvent.InitFactoryShop(info ,cbname , cb)            --道具工厂商店
    local data =
    {
        A = "init",
		M = "store",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.ReflashFactoryShop(info ,cbname , cb)         --刷新道具工厂商店
    local data =
    {
        A = "refresh",
		M = "store",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.BuyFactoryItem(info ,cbname , cb)         --购买道具工厂商店道具
    local data =
    {
        A = "buy",
		M = "store",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

--副本模块
function WebEvent.RequireMapInfo(info ,cbname , cb)

    local data = 
	{
		A = "init",
		M = "map",
	}
	
	WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.MapFight(info ,cbname , cb)               --副本战斗开始

    local data =
    {
        A = "start",
		M = "map",
        P = info
    }

    WebEvent.SendPack(data , cbname , cb)

end


function WebEvent.MapFightOver(info ,cbname , cb)           --副本战斗结束

    local data =
    {
        A = "over",
		M = "map",
        P = info
    }

    WebEvent.SendPack(data , cbname , cb)

end


function WebEvent.MapSweep(info ,cbname , cb)               --副本扫荡

     local data =
    {
        A = "sweep",
		M = "map",
        P = info
    }

    WebEvent.SendPack(data , cbname , cb)
    
end

function WebEvent.RankList(info ,cbname , cb)               --星级排行

    local data =
    {
        A = "starRank",
		M = "map",
        P = info
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.GetStarReward(info ,cbname , cb)               --星级排行

    local data =
    {
        A = "openBox",
		M = "map",
        P = info
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.FightGeneraMap(info ,cbname , cb)                      --通用副本
   
    local data =
    {
        A = "generalStart",
		M = "map",
        P = info
    }

    WebEvent.SendPack(data , cbname , cb)

end


function WebEvent.GeneraMapOver(info ,cbname , cb)                      --通用副本结束
   
    local data =
    {
        A = "generalOver",
		M = "map",
        P = info
    }

    WebEvent.SendPack(data , cbname , cb)

end

--天梯
function WebEvent.GetMasterRankList(info ,cbname , cb)               --请求天梯排行

    local data =
    {
        A = "init",
		M = "Ladder",
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.GetMyRankList(info ,cbname , cb)               --请求我的天梯排行

    local data =
    {
        A = "myRank",
		M = "Ladder",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.GetRankList(info ,cbname , cb)               --请求天梯排行 根据页数

    local data =
    {
        A = "ladderRank",
		M = "Ladder",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.MasterFight(info ,cbname , cb)               --天梯战开始

    local data =
    {
        A = "start",
		M = "Ladder",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.MasterOver(info ,cbname , cb)               --天梯战结束

    local data =
    {
        A = "ladderOver",
		M = "Ladder",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.MasterRobotOver(info ,cbname , cb)                       --天梯机器人结束
   local data =
    {
        A = "over",
		M = "Ladder",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.InitMasterShop(info ,cbname , cb)         --天梯商店
    local data =
    {
        A = "init",
		M = "store",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.ReflashMasterShop(info ,cbname , cb)         --刷新天梯商店
    local data =
    {
        A = "refresh",
		M = "store",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.BuyMasterItem(info ,cbname , cb)         --购买天梯商店道具
    local data =
    {
        A = "buy",
		M = "store",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end


--召唤
function WebEvent.InitSummon(info ,cbname , cb)               --扭蛋召唤

    local data =
    {
        A = "init",
		M = "summon",
        
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.EggCall(info ,cbname , cb)               --扭蛋召唤

    local data =
    {
        A = "summon",
		M = "summon",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

--邮件系统
function WebEvent.InitMail(info ,cbname , cb)               

    local data =
    {
        A = "init",
		M = "mail",
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.GetFujian(info ,cbname , cb)            --领取附件

     local data =
    {
        A = "receive",
		M = "mail",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.ReceiveAllFujian(info ,cbname , cb)            --领取所有附件

     local data =
    {
        A = "receiveAll",
		M = "mail",
    }

    WebEvent.SendPack(data , cbname , cb)

end
function WebEvent.DeleteAllMails(info ,cbname , cb)                --一键删除

     local data =
    {
        A = "deleteAll",
		M = "mail",
    }

    WebEvent.SendPack(data , cbname , cb)

end
function WebEvent.HaveSeeTheMails(info ,cbname , cb)            --标记查看过的邮件

     local data =
    {
        A = "view",
		M = "mail",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

--竞技场系统
function WebEvent.InitArenaInfo(info ,cbname , cb)

    local data =
    {
        A = "init",
		M = "arena",
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.RequestRankList(info ,cbname , cb)

   local data =
    {
        A = "arenaRank",
		M = "arena",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.RequestMyRank(info ,cbname , cb)
    
     local data =
    {
        A = "myRank",
		M = "arena",
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.ArenaFight(info ,cbname , cb)
    
    local data =
    {
        A = "start",
		M = "arena",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.ArenaOver(info ,cbname , cb)
    
    local data =
    {
        A = "over",
		M = "arena",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.InitArenaShop(info ,cbname , cb)         --竞技场商店
    local data =
    {
        A = "init",
		M = "store",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.ReflashArenaShop(info ,cbname , cb)         --刷新竞技场商店
    local data =
    {
        A = "refresh",
		M = "store",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.BuyArenaItem(info ,cbname , cb)         --购买竞技场商店道具
    local data =
    {
        A = "buy",
		M = "store",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end



--查询玩家
function WebEvent.SearchWorldPlayer(info ,cbname , cb)
    
    local data =
    {
        A = "playerInfo",
		M = "player",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end


--天天Boss系统
--初始化BOSS信息
function WebEvent.InitDailyBoss(info ,cbname , cb)
    local data =
    {
        A = "init",
		M = "boss",
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.DailyBossStart(info ,cbname , cb)
    local data =
    {
        A = "start",
		M = "boss",
    }

    WebEvent.SendPack(data , cbname , cb)
end

--天天Boss打完一局
function WebEvent.DailyBossOver(info ,cbname , cb)
    
     local data =
    {
        A = "over",
		M = "boss",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

--天天Boss伤害排行
function WebEvent.DailyBossDemageRank(info ,cbname , cb)
    
     local data =
    {
        A = "rank",
		M = "boss",
       -- P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

--天天BOSS鼓舞
function WebEvent.DailyBossInspire(info ,cbname , cb)
    
     local data =
    {
        A = "inspire",
		M = "boss",
       -- P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

--天天BOSS复活
function WebEvent.DailyBossRevive(info ,cbname , cb)
    
     local data =
    {
        A = "revive",
		M = "boss",
       -- P = info,
    }

    WebEvent.SendPack(data , cbname , cb)

end

--好友模块
function WebEvent.InitFriend(info ,cbname , cb)
    local data =
    {
        A = "init",
		M = "friend",
       -- P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.AddAllFriend(info ,cbname , cb)                                           --一键接受好友
    local data =
    {
        A = "addFriendAll",
		M = "friend",
       -- P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.AddFriend(info ,cbname , cb)                                               --同意拒绝接受好友
    local data =
    {
        A = "addFriend",
		M = "friend",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.ApplyFriend(info ,cbname , cb)                                               --请求添加好友
    local data =
    {
        A = "applyFriend",
		M = "friend",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.RecommendFriend(info ,cbname , cb)                                               --推荐好友
    local data =
    {
        A = "recommend",
		M = "friend",
       -- P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end


function WebEvent.SendEnergy(info ,cbname , cb)                                                 --赠送精力
    local data =
    {
        A = "give",
		M = "friend",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end


function WebEvent.ReceiveEnergy(info ,cbname , cb)                                                 --领取精力
    local data =
    {
        A = "receive",
		M = "friend",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.ReceiveAllEnergy(info ,cbname , cb)                                                 --一键领取精力
    local data =
    {
        A = "receiveAll",
		M = "friend",
       -- P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.DeleteFriend(info ,cbname , cb)                                                   --删除好友
    local data =
    {
        A = "delFriend",
		M = "friend",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.SearchFriend(info ,cbname , cb)                                                   --查找好友
    local data =
    {
        A = "searchFriend",
		M = "friend",
        P = info,
    }

    WebEvent.SendPack(data , cbname , cb)
end

--签到
function WebEvent.InitSignDailyReward(info ,cbname , cb)
   local data =
    {
        A = "init",
		M = "reward",
        --P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.GetSignReward(info ,cbname , cb)
    local data =
    {
        A = "receive",
		M = "reward",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.replenishSign(info ,cbname , cb)
   local data =
    {
        A = "replenishSign",
		M = "reward",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

--商城系统
function WebEvent.InitShop(info ,cbname , cb)                                               --商城初始化

     local data =
    {
        A = "init",
		M = "shop",
        --P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.BuyWelfareItem(info ,cbname , cb)                                               --购买福利道具

     local data =
    {
        A = "buyVipReward",
		M = "shop",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.BuyRechargeItem(info ,cbname , cb)                                               --购买充值道具

     local data =
    {
        A = "generateOrder",
		M = "shop",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.InitNormalItemShop(info ,cbname , cb)                                               --道具商店初始化

     local data =
    {
        A = "init",
		M = "store",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.RefreshNormalItemShop(info ,cbname , cb)                                               --刷新道具商店

     local data =
    {
        A = "refresh",
		M = "store",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.BuyShopNormalItem(info ,cbname , cb)                                               --购买道具商店道具

     local data =
    {
        A = "buy",
		M = "store",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end

--活动界面
function WebEvent.InitActivity(info ,cbname , cb)                           --初始化活动                                          

     local data =
    {
        A = "init",
		M = "activity",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.ReceiveAcitvity(info ,cbname , cb)                        --领取奖励                                              

     local data =
    {
        A = "receive",
		M = "activity",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end


--排行榜
function WebEvent.RequireRankList(info ,cbname , cb)                        --请求排行                                              

     local data =
    {
        A = "rank",
		M = "player",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end

--主角升级技能
function WebEvent.UpPlayerSkill(info ,cbname , cb)                        --主角升级技能                                         

     local data =
    {
        A = "skillUp",
		M = "player",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end

--主线任务
function WebEvent.InitPlayerGrow(info , cbname , cb)                                          --获取主线任务 日常任务
   local data =
    {
        A = "init",
		M = "reward",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end


--玩家账号操作
function WebEvent.ChangeName(info , cbname , cb)
    local data =
    {
        A = "changeName",
		M = "player",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

--发送小喇叭
function WebEvent.SendLaBa(info , cbname , cb)
   local data =
    {
        A = "playerMsg",
		M = "Broadcast",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

--道具使用
function WebEvent.UseItem(info , cbname , cb)

    local data =
    {
        A = "useItem",
		M = "package",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

--合成系统
function WebEvent.Combine(info , cbname , cb)
   local data =
    {
        A = "debrisSynthesis",
		M = "package",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

--心跳包
function WebEvent.HeartJump(info , cbname , cb)
    
    local data =
    {
        A = "synchronous",
		M = "player",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end

--引导提交
function WebEvent.SendGuide(info , cbname , cb)

     local data =
    {
        A = "updateGuide",
		M = "player",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)

end

function WebEvent.ActiveRight(info , cbname , cb)           --开启特权
   local data =
    {
        A = "specialRight",
		M = "special",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.SearchTeam(info , cbname , cb)
   local data =
    {
        A = "searchTeam",
		M = "special",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.FightDoubleDragon(info , cbname , cb)
   local data =
    {
        A = "start",
		M = "special",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.FightDoubleDragonOver(info , cbname , cb)
   local data =
    {
        A = "over",
		M = "special",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

function WebEvent.FightDoubleDragonInit(info , cbname , cb)
   local data =
    {
        A = "init",
		M = "special",
        P = info,
    }
    WebEvent.SendPack(data , cbname , cb)
end

return WebEvent