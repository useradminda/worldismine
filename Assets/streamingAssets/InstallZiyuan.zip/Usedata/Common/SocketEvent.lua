SocketEvent = {}



return SocketEvent