SocketClient = {}

SocketClient.MsgID = {
    RequestLogin = 1,
    RequestMove = 2,
    RequestCastSpell = 3,
    RequestBattleStart = 5,
    ReceiveLogin = 1001,
    ReceiveMove = 1002,
    ReceiveCastSpell = 1003,
    ReceiveCityState = 1004,
    ReceiveBattleEnd = 1006,

    ReceiveDebugMsg = 999,
    ReceiveAfterConnected = 998,
}

SocketClient["MsgHandleFun"] = {};

--[====[   注册网络收包回调函数   ]====]
function SocketClient.RegistMsgHandle(msgID, handle)
    SocketClient["MsgHandleFun"][msgID] = handle;
end

function SocketClient.GetPlayerId() -- 暂用数字模拟用户ID
    local uuid = PlayerPrefs.GetString("uuid");
    if (uuid == "") then
        uuid = os.date("1%M%H%S");
        PlayerPrefs.SetString("uuid", uuid);
    end

    return tonumber(uuid);
end

function SocketClient.CreateConnection(ip, port)
    DotNetClient.hzClient.Create(ip, port);
end


--[====[   向服务器发送数据   ]====]
--[[ 
    data = {
        intList = {},       --可选
        floatList = {},     --可选
        stringList = {},    --可选
        vectorList = {},    --可选
    };
]]
function SocketClient.SendNetEvent(msgID, data)
    if (data~= nil) then

        local event = {
            id = msgID,
            check = "0",
            dosome = { data },
        };

        local hzclient = DotNetClient.hzClient.GetPtr();
        if (hzclient ~= nil) then
            local world_id = tostring(SocketClient.GetPlayerId());
            local server_id = 0;
            GameMain.Print(event, "event to send");
            hzclient:SendNetEvent( world_id, server_id, event );
        else
            Debug.LogError("hzclient == nil");
        end
    end
end


--[====[  接收服务器发过来的数据   ]====]
function SocketClient.ReceiveNetEvent(e)
    local data = {
        intList = {},
        floatList = {},
        stringList = {},
        vectorList = {},
    };

    local temp =nil
    for i = 0, e.dosome.intList.Count - 1, 1 do 
        temp =  e.dosome.intList:getItem(i)
        data.intList[i + 1] = temp
    end
    for i = 0, e.dosome.floatList.Count - 1, 1 do 
        data.floatList[i + 1] = e.dosome.floatList[i]; 
    end
    for i = 0, e.dosome.stringList.Count - 1, 1 do
        data.stringList[i + 1] = e.dosome.stringList[i];
    end
    for i = 0, e.dosome.vectorList.Count - 1, 1 do 
        data.vectorList[i + 1] = e.dosome.vectorList[i] 
    end

    local type = tonumber(e.id);

    --GameMain.Print(data, "from server");

    if (SocketClient["MsgHandleFun"][type] ~= nil) then
        SocketClient["MsgHandleFun"][type](data);
    else
        Debug.LogError("Unknown msgID " .. tostring(type));
    end
end

function SocketClient.ReceiveBattleEndHandle(data)
    Debug.LogError("战斗结束:" .. data.stringList[1]);
end

function SocketClient.RequestBattleStart(data)
    local data = {
        intList = {},
    }

    SocketClient.SendNetEvent(SocketClient.MsgID.RequestBattleStart, data);
end

return SocketClient;
