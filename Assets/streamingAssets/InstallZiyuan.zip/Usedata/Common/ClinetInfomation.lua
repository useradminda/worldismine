ClinetInfomation = {}												--客户端信息

ClinetInfomation.World_id = nil										--主角
ClinetInfomation.Name = "nil"                                       
ClinetInfomation.MyOwner = 1                                        --1 ， 2 ，3 ，4 蜀 魏 吴 中立
ClinetInfomation.PlayerId = nil
ClinetInfomation.WorldTime = 0
function ClinetInfomation.GetPlayerInfo(data)  
	local info = data
	local nickname = info["nickname"]
	ClinetInfomation.PlayerName = nickname
    if ClinetInfomation.PlayerName~=nil then
       TalkingDataDemoScript.Ins:SetAccountName(ClinetInfomation.PlayerName)
    end
    local coin = tonumber(info["coin"])
	ClinetInfomation.Coin = coin
    local diamond = tonumber(info["diamond"])
    ClinetInfomation.Diamond = diamond
    local sta = tonumber(info["sta"])
    ClinetInfomation.Sta = sta
    local energy = tonumber(info["energy"])
    ClinetInfomation.Energy = energy
    local recharge = tonumber(info["recharge"])
    ClinetInfomation.CostRMB = recharge
    VipSys.CostRMB = recharge
    local vip = tonumber(info["vip"])
    ClinetInfomation.VipLevel = vip
    VipSys.VipLevel = vip
    local lvl = tonumber(info["level"])
    ClinetInfomation.Lvl = lvl

    if ClinetInfomation.Lvl~=nil then
       TalkingDataDemoScript.Ins:SetLevle(ClinetInfomation.Lvl)
    end

    local Exp = tonumber(info["exp"])
    ClinetInfomation.Exp = Exp
    local Credit = tonumber(info["credit"])
    ClinetInfomation.Credit = Credit
    local World_id = tostring(info["world_id"])
    ClinetInfomation.World_id = World_id
    local MasterCoin = tonumber(info["dsb"])
    ClinetInfomation.MasterCoin = MasterCoin
    local BloodStone = tonumber(info["bloodStone"])
    ClinetInfomation.BloodStone = BloodStone
    local RealId = tonumber(info["realID"])
    ClinetInfomation.RealId = RealId

    local FreeName = info["preName"]
    if FreeName~=nil then
       ClinetInfomation.FreeName = FreeName                                    
    else
       ClinetInfomation.FreeName = nil
    end

    local NextStaTime = tonumber(info["update_sta_time"])
    if ClinetInfomation.WorldTime - NextStaTime > 0 then
        ClinetInfomation.NextSta_Time = 480 - (ClinetInfomation.WorldTime - NextStaTime)
        TimeControl.LoginTime(ClinetInfomation.NextSta_Time , "NextSta_Time")
    end
    local NextEnergyTime = tonumber(info["update_energy_time"])
    if ClinetInfomation.WorldTime - NextStaTime > 0 then
       ClinetInfomation.NextEnergy_Time = 480 - (ClinetInfomation.WorldTime - NextEnergyTime)
       TimeControl.LoginTime(ClinetInfomation.NextEnergy_Time , "NextEnergy_Time")
    end
   
    local FightRank = info["rank"]["battleRank"]
    ClinetInfomation.FightRank = FightRank                                      --战斗力排行
    local StarRank = info["rank"]["mapRank"]
    ClinetInfomation.StarRank = StarRank                                       --星级排行
    local ArenaRank = info["rank"]["arenaRank"]
    ClinetInfomation.ArenaRank = ArenaRank                                      --竞技场排行

    local babyinfo =
    { 
        realID = tonumber(info["realID"]),
        star = tonumber(info["star"]),
	    isActivated = 1,
	    quality = tonumber(info["quality"]),
        qualityLvl = tonumber(info["q_level"]),
	    level = tonumber(info["level"]),
        skill = info["skill"],
     }
     local theme = roleDataSys.CreateOneRole(babyinfo)

     local EquipList = info["playerEquip"]                         --主角的穿戴装备
     local Count = #EquipList
     theme.PlayerEquip = {}
     for key , value in pairs(EquipList) do
        local Equip = EquipList[key]
        local uuid = tostring(Equip["uuid"])
        local pos = tonumber(Equip["pos"])
        theme.PlayerEquip[pos] = ItemPackageSys.FindItem(uuid) 
     end

     ClinetInfomation.theMe = theme
     local upRoles = TeamSys.GetPveTeamBaby()
     theme:TeamTotalProp(upRoles)                                           --计算主角属性
     
     local data =                                                   --刷新账号信息
     {  
        Name = nickname,
        Lvl = lvl,
        Coin = coin,
        Diamond = diamond,
        Sta = sta,
        Energy = energy,
        Vip = vip,
        RealId = RealId,
     }
     local ControlTar = MainGameUI.FindPanelTarget("UIControl")
     local ControlGob = MainGameUI.FindPanel("UIControl")
     if ControlTar~=nil and ControlGob~=nil then
        ControlTar:SetLeftTopPlayerInfo(data)       
        if ClinetInfomation.CostRMB==nil or ClinetInfomation.CostRMB==0 then
           --ControlTar:OpenFirstRecharge()
        end
        ControlTar:SetTopLeftFight()
     end 
 
end

function  ClinetInfomation.ComminfoCallBack(data) 
    local info = data
    ClinetInfomation.WorldTime = tonumber(data["worldTime"])
    --[[if info["nickname"]==nil then
       return
    end
	local nickname = info["nickname"]
	ClinetInfomation.PlayerName = nickname
    local coin = tonumber(info["coin"])
	ClinetInfomation.Coin = coin
    local diamond = tonumber(info["diamond"])
    ClinetInfomation.Diamond = diamond
    local worldtime = tonumber(info["worldTime"])
    ClinetInfomation.WorldTime = worldtime
    local sta = tonumber(info["sta"])
    ClinetInfomation.Sta = sta
    local energy = tonumber(info["energy"])
    ClinetInfomation.Energy = energy
    local recharge = tonumber(info["recharge"])
    ClinetInfomation.CostRMB = recharge
    VipSys.CostRMB = recharge
    local vip = tonumber(info["vip"])
    ClinetInfomation.VipLevel = vip
    VipSys.VipLevel = vip
    local lvl = tonumber(info["level"])                     --主角升级事件
    if lvl~=nil then
       if ClinetInfomation.Lvl~=lvl and ClinetInfomation.theMe~=nil then
          ClinetInfomation.Lvl = lvl
          ClinetInfomation.theMe.lvl = lvl
          ClinetInfomation.LvlUpEvent()  
          TalkingDataDemoScript.Ins:SetLevle(lvl)
       end
    end
    ClinetInfomation.Lvl = lvl
    local Exp = tonumber(info["exp"])
    ClinetInfomation.Exp = Exp
    local Credit = tonumber(info["credit"])
    ClinetInfomation.Credit = Credit
    local UIArenaTar = MainGameUI.FindPanelTarget("UIArena")
    if UIArenaTar~=nil then
       UIArenaTar:SetCredit()
    end
    local World_id = tostring(info["world_id"])
    ClinetInfomation.World_id = World_id
    local MasterCoin = tonumber(info["dsb"])
    ClinetInfomation.MasterCoin = MasterCoin
    local BloodStone = tonumber(info["bloodStone"])
    ClinetInfomation.BloodStone = BloodStone
    local RealId = tonumber(info["realID"])
    ClinetInfomation.RealId = RealId

    local NextStaTime = tonumber(info["update_sta_time"])
    if ClinetInfomation.WorldTime - NextStaTime > 0 then
        ClinetInfomation.NextSta_Time = 480 - (ClinetInfomation.WorldTime - NextStaTime)
        TimeControl.LoginTime(ClinetInfomation.NextSta_Time , "NextSta_Time")
    end
    local NextEnergyTime = tonumber(info["update_energy_time"])
    if ClinetInfomation.WorldTime - NextStaTime > 0 then
       ClinetInfomation.NextEnergy_Time = 480 - (ClinetInfomation.WorldTime - NextEnergyTime)
       TimeControl.LoginTime(ClinetInfomation.NextEnergy_Time , "NextEnergy_Time")
    end
    
    local FreeName = info["preName"]
    if FreeName~=nil then
       ClinetInfomation.FreeName = FreeName                                    
    else
       ClinetInfomation.FreeName = nil
    end

    local nowGuide = tonumber(info["guide"])
    GuideSys.NowBigStep = nowGuide + 1

    local _SkillInfo = info["skill"]
    if ClinetInfomation.theMe~=nil then
       ClinetInfomation.theMe:SetSkill(_SkillInfo)
      
    end

    local data = 
     {  
        Name = nickname,
        Lvl = lvl,
        Coin = coin,
        Diamond = diamond,
        Sta = sta,
        Energy = energy,
        Vip = vip,
        RealId = RealId,
     }
     
     local ControlTar = MainGameUI.FindPanelTarget("UIControl")
     local ControlGob = MainGameUI.FindPanel("UIControl")
     if ControlTar~=nil and ControlGob~=nil then
        ControlTar:SetLeftTopPlayerInfo(data)
        if ClinetInfomation.CostRMB==nil or ClinetInfomation.CostRMB==0 then
           ControlTar:OpenFirstRechargeButton()
        elseif ClinetInfomation.CostRMB~=nil and ClinetInfomation.CostRMB>0 then
           ControlTar:CloseFirstRechargeButton()
        end
        ControlTar:SetTopLeftFight()
     end 
     --]]
end

function ClinetInfomation.LvlUpEvent()
    if ClinetInfomation.theMe~=nil then
       local upRoles = TeamSys.GetPveTeamBaby()
       ClinetInfomation.theMe:TeamTotalProp(upRoles)
    end
end

function ClinetInfomation.GetCoin()
 
   return ClinetInfomation.Coin

end

function  ClinetInfomation.GetDiamond()
 
    return ClinetInfomation.Diamond

end

function ClinetInfomation.GetSta()

    return ClinetInfomation.Sta

end

return ClinetInfomation