ClinetSys = {}

function ClinetSys.CreatePlayer()  
   WebEvent.CreatePlayer("I AM"..tostring(LoginData.uuid) , "ClinetSys.CreatePlayerCallBack" , ClinetSys.CreatePlayerCallBack)
end

function ClinetSys.CreatePlayerCallBack(_data , _returnId)  
   GameMain.Print(_data)
end

return ClinetSys