--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
ItemPackageSys = {}                                                              

local this = ItemPackageSys

ItemPackageSys.ItemList =                                                        --背包物品列表
{

}

function ItemPackageSys.ComminfoResource(data)
	for key , value in pairs(data) do
        local ID = tonumber(key)
        if ID~=nil then
			local id=value["Id"]
			local num=value["qtt"]
			ItemPackageSys.AddItem(id,num)
        end
    end
end



function ItemPackageSys.AddItem(_Id, _Count)--增加或减少背包数据
--	if ItemPackageSys.ItemList[_Id]==nil and _Count==0 then
--		Debug.LogError("道具没发数量")
--        return
--	end

	local lua = GameMain.requireLuaFile("ItemInfo")
	local itemInfo = lua:new()
	local itemData=ItemDataConfig.GetItemDBConfig(_Id)
	itemInfo:InitSome(itemData, _Count)

	if #ItemPackageSys.ItemList==0 then
		if _Count>0 then
			ItemPackageSys.ItemList[1]=itemInfo
			return
		end
	end
	for i=#ItemPackageSys.ItemList ,1 ,-1
		do
		
			if ItemPackageSys.ItemList[i]~=nil and ItemPackageSys.ItemList[i].Id == _Id then
				
				if _Count==0 then
					ItemPackageSys.ItemList[i]=nil
					return
				end
				if _Count>0 then
					ItemPackageSys.ItemList[i]=itemInfo
					return
				end
			end
	end
	if _Count>0 then
		ItemPackageSys.ItemList[#ItemPackageSys.ItemList+1]=itemInfo
	end
	if _Count<=0 then
		Debug.LogError(tostring(_Id) .. "没发放数量")
	end
end


--endregion
return ItemPackageSys