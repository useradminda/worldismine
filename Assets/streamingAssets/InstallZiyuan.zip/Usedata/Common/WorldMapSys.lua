WorldMapSys = {}
WorldMapSys.CityNodes = {}
WorldMapSys.Player = nil
WorldMapSys.Stat = nil
WorldMapSys.End = nil
WorldMapSys.Lines = {}
WorldMapSys.MapCitys = {}
WorldMapSys.LineFather = nil
WorldMapSys.CityFather = nil
WorldMapSys.SmallMapFatehr = nil

function WorldMapSys.CreateCityNodes()                                              --�������еĳ��е�
   --if WorldMapSys.LineFather==nil then
      WorldMapSys.LineFather = GameObject.Find("LineFather")
   --end
   --if WorldMapSys.CityFather==nil then
      WorldMapSys.CityFather = GameObject.Find("CityFather")
  -- end
   --[[if WorldMapSys.SmallMapFatehr==nil then
      WorldMapSys.SmallMapFatehr = GameObject.Find("SmallMapFather")
   end--]]

   lgNoDelCsFun.Ins:CreateTexture()

   local WorldId = SocketClient.GetPlayerId()
   PlayerControl.WorldId = WorldId

   local CityNodesData = WorldMapDataSys.GetCityNodesData()
   if CityNodesData~=nil then
      for i = 1 , #CityNodesData , 1 do
          local NodeData = CityNodesData[i]

          local lua = GameMain.requireLuaFile("CityNode")
	      local CityNode = lua:new()
          CityNode:Init(NodeData)

          WorldMapSys.CityNodes[NodeData.CityId] = CityNode

          local data =
          {
              Pos = CityNode.Pos,
              CityId = CityNode.NodeId,
              CityNode = CityNode,
          }
          WorldMapSys.SetMapCityColor(CityNode.Pos , CityNode.OwnerShipNow)
          WorldMapSys.LoadAssetByObject(data , "Sphere" , WorldMapSys.CallBack)
          --WorldMapSys.LoadAssetByObject(data , "MapCity" , WorldMapSys.CallBackMapCity)               
      end
   end
   
   WorldMapSys.MakeMapColor()

   for key , value in pairs(WorldMapSys.CityNodes) do       
       for i = 1 , #value.NeighbourNodesId , 1 do           
           local NeNode = WorldMapSys.CityNodes[value.NeighbourNodesId[i]]
           if NeNode~=nil then
               local _StartPoint = value.Pos
               local _EndPoint = NeNode.Pos
              
               local _ID = tostring(value.NodeId).."_"..tostring(NeNode.NodeId)
               local _ChangeId = tostring(NeNode.NodeId).."_"..tostring(value.NodeId)
               if WorldMapSys.Lines[_ID]==nil and WorldMapSys.Lines[_ChangeId]==nil then
                  local data =
                  {                  
                     StartPoint = _StartPoint,
                     EndPoint = _EndPoint,
                     Froward = _Froward,
                     Id = _ID,
                  }
                  WorldMapSys.LoadAssetByObject(data , "Line" , WorldMapSys.CallBackLine)
               end
           end
       end      
   end
end

function WorldMapSys.CallBack(_Info , prefab)
   local Gob = GameObject.Instantiate(prefab,Vector3.zero,Quaternion.identity)
   Gob.transform.parent = WorldMapSys.CityFather.transform
   Gob.transform.localScale = Vector3(100 , 100 , 100)
   Gob.transform.localPosition = _Info.Pos
   Gob.name = tostring(_Info.CityId)  
   _Info.CityNode:GetCityGob(Gob)
   _Info.CityNode:SetNameMesh()
   _Info.CityNode:SetCitySprite()
end

--[[function WorldMapSys.CallBackMapCity(_Info , prefab)
   local Gob = GameObject.Instantiate(prefab,Vector3.zero,Quaternion.identity)
   Gob.transform.name = _Info.CityId
   Gob.transform.parent = WorldMapSys.SmallMapFatehr.transform
   Gob.transform.localScale = Vector3(3 , 3 , 0.3)
   Gob.transform.localEulerAngles = Vector3(90 , 0 , 0)
   Gob.transform.localPosition = Vector3((_Info.Pos.x/128)/2.5 , 0 , (_Info.Pos.z/128)/3.5)
   WorldMapSys.MapCitys[_Info.CityId] = {}
   WorldMapSys.MapCitys[_Info.CityId].Gob = Gob
   WorldMapSys.MapCitys[_Info.CityId].SpriteRenderer = Gob:GetComponent("SpriteRenderer")
   WorldMapSys.SetMapCityColor(WorldMapSys.MapCitys[_Info.CityId].SpriteRenderer , _Info.CityNode.OwnerShipNow)
end--]]

function WorldMapSys.CallBackLine(_Info , prefab)
   local Gob = GameObject.Instantiate(prefab,Vector3.zero,Quaternion.identity)
   Gob.transform.parent = WorldMapSys.LineFather.transform
   Gob:GetComponent("LineRenderer"):SetPosition(0 , Vector3(_Info.StartPoint.x , -10 , _Info.StartPoint.z))
   Gob:GetComponent("LineRenderer"):SetPosition(1 , Vector3(_Info.EndPoint.x ,-10 , _Info.EndPoint.z))
   WorldMapSys.Lines[_Info.Id] = _Info.Id
end

function WorldMapSys.AstarBegin(_StarNode , _EndNode)
   local Nodes = Astar.AstarBegin(_StarNode , _EndNode)
   if Nodes==nil then
      return nil
   end
   WorldMapSys.SaveNodes = {}
   for i = 1 , #Nodes , 1 do
       WorldMapSys.SaveNodes[i] = Nodes[#Nodes + 1 - i]
   end
   return WorldMapSys.SaveNodes
end



function WorldMapSys.FindCityNodeById(_CityId)
    if WorldMapSys.CityNodes[_CityId]~=nil then
       return WorldMapSys.CityNodes[_CityId]
    else
       Debug.LogError("δ��ѯ����,ID:")
       Debug.LogError(_CityId)
       return nil
    end
end

function WorldMapSys.SetNodeStates(_NodeData)
    local CityId = _NodeData.CityId
    local CityNode = WorldMapSys.FindCityNodeById(CityId)
    
    local OwnerShipNow = _NodeData.Owner
    local CityState = _NodeData.CityState
    local DefenceNum = _NodeData.DefenceNum
    local AttackNum = _NodeData.AttackNum

    if CityNode.OwnerShipNow ~= OwnerShipNow then
       CityNode:SetNowOwnerShip(OwnerShipNow)
       WorldMapSys.SetMapCityColor(CityNode.Pos  , OwnerShipNow)
       WorldMapSys.MakeMapColor()
       CityNode:SetNameMesh()
       CityNode:SetCitySprite()
    end
 
    CityNode:SetCityState(CityState)
    CityNode:SetDefenceNum(DefenceNum)
    CityNode:SetAttackNum(AttackNum)
       
end

function WorldMapSys.SetPlayerOwnerShip(_PlayerData)
    
end

function WorldMapSys.SetMapCityColor(_Pos , _OwnerShip)

   lgNoDelCsFun.Ins:SetTexture(_Pos.x/8 , _Pos.z/8 , _OwnerShip)
end

function WorldMapSys.MakeMapColor()
   lgNoDelCsFun.Ins:SetTexApply()
end

function WorldMapSys.GetHomeByOwner(_OwnerShip)             --�ҵ�ר��������
    for key , value in pairs(WorldMapSys.CityNodes) do
        if value.OwnerShip==_OwnerShip then
           if value.CityType == 2 then
              return WorldMapSys.CityNodes[key]
           end
        end
    end
    return nil
end

function WorldMapSys.LoadAssetByObject(info, prefabName, cb) 
	lgNoDelCsFun.Ins:LoadAssetByObject1(info, prefabName, cb, false)
end


function WorldMapSys.Release()
   WorldMapSys.Lines = {}
end

return WorldMapSys