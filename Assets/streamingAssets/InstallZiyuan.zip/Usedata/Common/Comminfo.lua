Comminfo = {}								--Comminfo 通用网络事件信息

local this = Comminfo

Comminfo["ComminfoCallBack"] =
{

}
function Comminfo.InitSome()
    --[[Comminfo["ComminfoCallBack"]["Mount"] = BabyPackSys.ComminfoCallBack
    Comminfo["ComminfoCallBack"]["Player"] = ClinetInfomation.ComminfoCallBack
    Comminfo["ComminfoCallBack"]["Equip"] = EquipMentSys.CommonInfoCallBack
    Comminfo["ComminfoCallBack"]["consumeEquip"] = EquipMentSys.ConsumeEquip
    Comminfo["ComminfoCallBack"]["Map"] = MapSys.CommonInfoCallBack
    Comminfo["ComminfoCallBack"]["Reward"] = ItemPackageSys.ComminfoReward
    Comminfo["ComminfoCallBack"]["Item"] = ItemPackageSys.ComminfoItems
    Comminfo["ComminfoCallBack"]["Resource"] = ItemPackageSys.ComminfoResource
    Comminfo["ComminfoCallBack"]["Debris"] = ItemPackageSys.ComminfoDebris
    Comminfo["ComminfoCallBack"]["Mail"] = MailSys.ComminfoMails
    Comminfo["ComminfoCallBack"]["LineReward"] = PlayerGrowSys.LineReward
    Comminfo["ComminfoCallBack"]["DailyReward"] = PlayerGrowSys.DailyRewardComminfo
    Comminfo["ComminfoCallBack"]["MainReward"] = PlayerGrowSys.PlayerGrowComminfo
    Comminfo["ComminfoCallBack"]["Store"] = ShopSys.StoneComminfo
    Comminfo["ComminfoCallBack"]["Vip"] = VipSys.VipComminfo
    Comminfo["ComminfoCallBack"]["Shop"] = ShopSys.ShopComminfo
    Comminfo["ComminfoCallBack"]["Activity"] = ActivitySys.ComminfoActivity
    Comminfo["ComminfoCallBack"]["Broad"] = XiaoLaBaSys.LabaComminfo--]]
    Comminfo["ComminfoCallBack"]["Player"] = ClinetInfomation.ComminfoCallBack
    Comminfo["ComminfoCallBack"]["Army"] = SoliderPackageSys.ComminfoCallBack
    Comminfo["ComminfoCallBack"]["Hero"] = HeroPackageSys.ComminfoCallBack
	Comminfo["ComminfoCallBack"]["Item"]=ItemPackageSys.ComminfoResource

end

function Comminfo.HandleCommon(_Comminfodata)
    local Comminfodata = GameMain.JsonDecode(_Comminfodata)
    local Count = #Comminfodata

    for i = 1 , Count , 1 do
        local ModelName = tostring(Comminfodata[i]["moduleName"])
        if Comminfo["ComminfoCallBack"][ModelName]~=nil then
          -- GameMain.Print(Comminfodata)
           Comminfo["ComminfoCallBack"][ModelName](Comminfodata[i])
        end
    end

end

function  Comminfo.Test(_data)
    for key , value in pairs(_data) do
        local ID = tonumber(key)
        if ID~=nil then
           Debug.LogError(ID)
        end
    end
   -- GameMain.Print(_data)
end

return Comminfo
