HeroPackageSys = {}
HeroPackageSys.Heros = {}

function HeroPackageSys.Init()
    
    local Hero = RoleDataSys.CreateHero(10011,1,1)
    HeroPackageSys.Heros[1] = Hero
    
end

function HeroPackageSys.GetHero()
    return HeroPackageSys.Heros
end

function HeroPackageSys.CreateHero(_DBid , _UUID , _Lvl)

    local _Hero = RoleDataSys.CreateHero(_DBid , _Lvl , _UUID)
    table.insert(HeroPackageSys.Heros , #HeroPackageSys.Heros + 1 , _Hero)

end

function HeroPackageSys.GetOneHeroBy_UUID(_UUID)    
    for i = 1 , #HeroPackageSys.Heros , 1 do       
        HeroPackageSys.Heros[i].UUID = _UUID
        return HeroPackageSys.Heros[i]       
    end
    return nil
end

function HeroPackageSys.ComminfoCallBack(_data)
    for key , value in pairs(_data) do
        local ID = tonumber(key)
        if ID~=nil then
           local data = value
           local _DBid = tonumber(data["id"])
           local _UUID = tostring(data["uuid"])
           local _Lvl = tonumber(data["lv"])
           HeroPackageSys.CreateHero(_DBid , _UUID , _Lvl)
        end
    end
end

return HeroPackageSys