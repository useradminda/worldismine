CityNode = {}                                                                      --�ǳ���
local this = CityNode
CityNode.__index = CityNode

function  CityNode:new(o)
    o=o or {}
    setmetatable(o,self)
    self.__index = self
    return o
end

CityNode.NodeId = 0                                                                  --����ID
CityNode.Pos = Vector3(0 , 0 , 0)                                                    --λ�õ�
CityNode.CityName = ""                                                               --����
CityNode.NameMesh = nil
CityNode.SpriteRenderer = nil
CityNode.CitySprites = nil
CityNode.Can_Go = true                                                               --�Ƿ����ͨ��
CityNode.Is_InCloseList = false                                                      --�Ƿ��ڿ����б�
CityNode.FatherNode = nil                                                            --���׵�
CityNode.NeighbourNodesId = nil                                                      --�������ھ�
CityNode.NeighbourPassTime = nil                                                     --ͨ�������ھӵ�ʱ��
--CityNode.CityNodeData = NodeData,                                                  --���е����ݿ���Ϣ
CityNode.CityStates = {"Fight" , "Idle"}
CityNode.CityState = "Idle"

CityNode.CityType = 1                                                                 -- 1�׶� 2���� 3�ذ� 4�ǳ� 5Ұ��
CityNode.OwnerShip = 1                                                                --1 , 2 , 3 �� κ�� �� ���� ��ʼ����
CityNode.OwnerShipName = "κ��������"

CityNode.OwnerShipNow = 1                                                             --��ǰ����
CityNode.OwnerShipNameNow = "κ��������"
CityNode.DefenceNum = 0                                                               --��������
CityNode.AttackNum = 0                                                                --��������

CityNode.CityGob = nil

function CityNode:Init(_NodeData)
   self.NodeId = _NodeData.CityId                                                 --����ID
   self.Pos = Vector3(_NodeData.PosX *128 , 0 , _NodeData.PosY * 128)                        --λ�õ�
   self.CityName = _NodeData.CityName                                             --����
   self.Can_Go = true                                                             --�Ƿ����ͨ��
   self.Is_InCloseList = false                                                    --�Ƿ��ڿ����б�
   self.FatherNode = nil                                                          --���׵�
   self.NeighbourNodesId = _NodeData.CityAround                                   --�������ھ�
   self.NeighbourPassTime = _NodeData.CityTime                                    --ͨ�������ھӵ�ʱ��

   self.CityState = "Idle"

   self.CityType = _NodeData.CityType
   self.OwnerShip = _NodeData.OwnerShip
   self.OwnerShipNow = _NodeData.OwnerShip
   self.OwnerShipName = UIstring.Ownerships[self.OwnerShip]
   self.OwnerShipNameNow = UIstring.Ownerships[self.OwnerShipNow]

   self.DefenceNum = 0                                                               --��������
   self.AttackNum = 0  
end

function CityNode:SetDefenceNum(_Num)
   self.DefenceNum = _Num
end

function CityNode:SetAttackNum(_Num)
   self.AttackNum = _Num
end

function CityNode:SetNowOwnerShip(_OwnerShip)
   self.OwnerShipNow = _OwnerShip
   self.OwnerShipNameNow = UIstring.Ownerships[self.OwnerShipNow]
end

function CityNode:GetCityGob(_Gob)
   self.NameMesh = _Gob.transform:FindChild("CityName"):GetComponent("TextMesh") 
   self.SpriteRenderer = _Gob.transform:FindChild("CitySprite"):GetComponent("SpriteRenderer") 
   self.CitySprites = _Gob.transform:GetComponent("ClickEvent").sprites
   self.CityGob = _Gob
end

function CityNode:SetNameMesh()
   self.NameMesh.text = self.OwnerShipNameNow..self.CityName
   if self.OwnerShipNow==1 then           --���
      lgNoDelCsFun.Ins:SetNameMeshColor(self.NameMesh , 255/255 , 0/255 , 0/255) 
   elseif self.OwnerShipNow==2 then       --κ��
      lgNoDelCsFun.Ins:SetNameMeshColor(self.NameMesh , 0/255 , 245/255 , 255/255)
   elseif self.OwnerShipNow==3 then       --���
      lgNoDelCsFun.Ins:SetNameMeshColor(self.NameMesh , 30/255 , 255/255 , 0/255)
   elseif self.OwnerShipNow==4 then       --����
      lgNoDelCsFun.Ins:SetNameMeshColor(self.NameMesh , 255/255 , 0/255 , 227/255)
   end
end

function CityNode:SetCitySprite()
   if self.CityType==1 or self.CityType==2 then
      self.SpriteRenderer.gameObject:SetActive(false)
   else
      self.SpriteRenderer.sprite  = self.CitySprites[self.OwnerShipNow - 1]
   end 
end


function CityNode:SetCityState(_CityState)
   if _CityState==0 then
      self.CityState = "Idle"
   elseif _CityState==1 then
      self.CityState = "Fight"
   end
end

return CityNode